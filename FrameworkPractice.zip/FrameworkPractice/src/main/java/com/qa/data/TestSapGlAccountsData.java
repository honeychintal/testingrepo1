package com.qa.data;

import java.util.List;

import com.qa.model.SapGlAccounts;

public class TestSapGlAccountsData {

	public static List<SapGlAccounts> getSapGlAccountsData()
	{
		return TestSapGlAccounts.SAP_GL_ACCOUNTS_DATA;
	}
}
