package com.basics.classes;

public class EnumClass {
	public static void main(String args[])
	{
		for(JavaEnumFile enm: JavaEnumFile.values())
		System.out.println(enm+" : "+enm.legendLevel);
	}
}
