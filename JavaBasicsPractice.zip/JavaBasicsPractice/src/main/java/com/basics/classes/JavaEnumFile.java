package com.basics.classes;

public enum JavaEnumFile {
	ONE("Death note"),
	TWO("Fullmetal Alchemist"),
	THREE("Stein's Gate"),
	FOUR("Erased"),
	FIVE("Promised Neverland- s1"),
	SIX("One punch man"),
	SEVEN("Assasination classroom"),
	EIGHT("Mushuku tensei- A jobless reincarnation"),
	NINE("Future Diary"),
	TEN("Paranoia Agent"),
	ELEVEN("Dororo"),
	TWELVE("Seven deadly sins"),
	THIRTEEN("Cowboy bebop"),
	FORTEEN("Baki"),
	FIFTEEN("Kengan ashura"),
	SIXTEEN("GTO: great teacher onizuka"),
	SEVENTEEN("Another"),
	EIGHTEEN("Demon slayer"),
	NINETEEN("Attack on titan"),
	TWENTY("JOJO's bizzare advantures");
	
	String legendLevel;
	
	private JavaEnumFile(String legendLevel) {
		this.legendLevel=legendLevel;
	}
}
