package com.qa.builder;

public class TestUser {
	public static void main(String args[]){
		User u1 = User.builder()
				.name("Rajaram")
				.age(20)
				.employed(false)
				.build(); 

		User u2 = User.builder()
				.age(30)
				.name("Sitaram")
				.employed(true)
				.build();

		System.out.println(u1.getName()+" "+u1.getAge()+" "+u1.isEmployed());		
		System.out.println(u2.getName()+" "+u2.getAge()+" "+u2.isEmployed());	
	}
}
