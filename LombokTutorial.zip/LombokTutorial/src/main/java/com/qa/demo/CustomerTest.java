package com.qa.demo;

public class CustomerTest {
	public static void main(String args[])
	{
		Customer c1 =new Customer("Tom", 30, "Rajasthan", false, "01-01-2000");
		System.out.println(c1);
		
		System.out.println(c1.getName()+" "+c1.getDob());
		c1.setActive(true);
		System.out.println(c1);
	}
}
