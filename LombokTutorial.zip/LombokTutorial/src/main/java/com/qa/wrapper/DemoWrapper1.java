package com.qa.wrapper;

public class DemoWrapper1 {

	public static void main(String[] args) {
		int a =100;
		System.out.println("Primitive int ="+a);
		
		Integer b=200;
		System.out.println("Wrapper Integer ="+b);

	}

}
