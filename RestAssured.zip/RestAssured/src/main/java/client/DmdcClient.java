package client;

import constant.ResponseCode;
import factory.CreateUserResponseFactory;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import model.ListCreateUserResponse;
import model.ListRegisterResponse;
import org.testng.Assert;

public class DmdcClient {
    public static final String LIST_USER_GET_PATH="https://reqres.in/api/users?page={no}";
    public static final String CREATE_USER_POST_PATH="https://reqres.in/api/users";
    public static final String USER_REGISTER="https://reqres.in/api/register";
    public static Response getListUser(int pageno)
    {

        Response response = RestAssured.
                given().
                pathParam("no",pageno).
                contentType(ContentType.JSON).
                accept(ContentType.JSON).
                when().
                get(DmdcClient.LIST_USER_GET_PATH);
        return response;
    }
    public static Response postCreateUser(String requestBody)
    {

        Response response = RestAssured.
                given().
                contentType(ContentType.JSON).
                accept(ContentType.JSON).
                body(requestBody).
                when().
                post(DmdcClient.CREATE_USER_POST_PATH);
        return response;
    }
    public static Response postRegisterResponse(String requestBody)
    {

        Response response = RestAssured.
                given().
                contentType(ContentType.JSON).
                accept(ContentType.JSON).
                body(requestBody).
                when().
                post(DmdcClient.USER_REGISTER);
        return response;
    }
    public static void validateResponseBodyTest(Response actualResponse, ListCreateUserResponse expectedResponse)
    {

        Assert.assertEquals(actualResponse.path("name"),expectedResponse.getName());
        Assert.assertEquals(actualResponse.path("job"),expectedResponse.getJob());
    }
    public static void validRegisterResponseTest(Response actualResponse, ListRegisterResponse expectedResponse)
    {

        Assert.assertEquals(actualResponse.path("id"),expectedResponse.getId());
        Assert.assertEquals(actualResponse.path("token"),expectedResponse.getToken());
    }
    public static void invalidRegisterResponseTest(Response actualResponse)
    {

        Assert.assertEquals(actualResponse.statusCode(), ResponseCode.BAD_REQUEST_RESPONSE);
    }
}
