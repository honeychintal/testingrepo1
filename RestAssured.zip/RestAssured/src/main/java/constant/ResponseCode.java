package constant;

public class ResponseCode {

    public static final int BAD_REQUEST_RESPONSE = 400;
    public static final int INVALID_DMDSTATS_RESPONSE =  401;
    public static final int FORBIDDEN_RESPONSE = 403;
}
