package data;

import com.google.common.collect.ImmutableList;
import factory.ListUserDataFactory;
import model.ListUserData;
import model.ListUserSupport;

import java.util.List;

public class TestListUserData {
    public static final List<ListUserData> LIST_USER_DATA_LIST = ImmutableList.of(
            /*ListUserData.builder().id(7).email("michael.lawson@reqres.in").first_name("Michael")
                            .last_name("Lowson").avatar("https://reqres.in/img/faces/7-image.jpg"),
            */

            ListUserDataFactory.CreateListUserData(
                    7,
                    "michael.lawson@reqres.in",
                    "Michael",
                    "Lawson",
                    "https://reqres.in/img/faces/7-image.jpg"),
            ListUserDataFactory.CreateListUserData(
                    8,
                    "lindsay.ferguson@reqres.in",
                    "Lindsay","Ferguson",
                    "https://reqres.in/img/faces/8-image.jpg"),
            ListUserDataFactory.CreateListUserData(
                    9,
                    "tobias.funke@reqres.in",
                    "Tobias",
                    "Funke",
                    "https://reqres.in/img/faces/9-image.jpg"),
            ListUserDataFactory.CreateListUserData(
                    10,
                    "byron.fields@reqres.in",
                    "Byron",
                    "Fields",
                    "https://reqres.in/img/faces/10-image.jpg"),
            ListUserDataFactory.CreateListUserData(
                    11,
                    "george.edwards@reqres.in",
                    "George",
                    "Edwards",
                    "https://reqres.in/img/faces/11-image.jpg"),
            ListUserDataFactory.CreateListUserData(
                    12,
                    "rachel.howell@reqres.in",
                    "Rachel",
                    "Howell",
                    "https://reqres.in/img/faces/12-image.jpg")
    );
    public static final ListUserSupport LIST_USER_SUPPORT = ListUserSupport.builder()
            .url("https://reqres.in/#support-heading")
            .text("To keep ReqRes free, contributions towards server costs are appreciated!")
            .build();
}
