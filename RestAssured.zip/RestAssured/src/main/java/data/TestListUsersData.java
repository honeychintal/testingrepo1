package data;

import model.ListUserData;
import model.ListUserSupport;

import java.util.List;

public class TestListUsersData {

    public static List<ListUserData> getAdminListUserData() {

        return TestListUserData.LIST_USER_DATA_LIST;
    }

    public static ListUserSupport getAdminListUserSupport(){

        return TestListUserData.LIST_USER_SUPPORT;
    }
}
