package factory;

import model.ListCreateUserRequest;

public class CreateUserRequestFactory {
    public static ListCreateUserRequest createUserRequest(String name,String job) {

        return ListCreateUserRequest.builder()
                .name(name)
                .job(job)
                .build();
    }
    public static ListCreateUserRequest createExpectedUserRequest() {

        return createUserRequest(
                "morpheus",
                "leader"
        );
    }
}
