package factory;

import model.ListCreateUserRequest;
import model.ListCreateUserResponse;

public class CreateUserResponseFactory {
    public static ListCreateUserResponse createUserResponse(String name,String job,String id,String createdAt)
    {

        return ListCreateUserResponse.builder()
                .name(name)
                .job(job)
                .id(id)
                .createdAt(createdAt)
                .build();
    }
    public static ListCreateUserResponse createExpectedUserResponse()
    {

        return createUserResponse(
                "morpheus",
                "leader",
                "929",
                "2021-10-07T12:04:22.821Z"
        );
    }
}