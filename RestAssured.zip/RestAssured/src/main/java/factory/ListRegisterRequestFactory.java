package factory;

import model.ListRegisterRequest;

public class ListRegisterRequestFactory {
    public static ListRegisterRequest createListRegisterRequest(String emailid,String password)
    {

        return ListRegisterRequest.builder()
                .email(emailid)
                .password(password)
                .build();
    }
    public static ListRegisterRequest createExpectedRegRequest()
    {

        return createListRegisterRequest(
                "eve.holt@reqres.in",
                "pistol"
        );
    }
    public static ListRegisterRequest createExpectedInvalidRegRequest()
    {

        return createListRegisterRequest(
                "eve.holt@reqres.in",
                ""
        );
    }
}
