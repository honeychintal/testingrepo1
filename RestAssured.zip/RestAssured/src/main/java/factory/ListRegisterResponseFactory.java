package factory;

import model.ListRegisterResponse;

public class ListRegisterResponseFactory {
    public static ListRegisterResponse createRegResponse(Integer id,String token)
    {

        return ListRegisterResponse.builder()
                .id(id)
                .token(token)
                .build();
    }
    public static ListRegisterResponse createExceptedRegResponse()
    {

        return createRegResponse(
                4,
                "QpwL5tke4Pnpja7X4"
        );
    }
}
