package factory;

import model.ListUserData;

public class ListUserDataFactory {
    public static ListUserData CreateListUserData(Integer id,String email,String firstName,
                                                  String lastName,String avatar)
    {
        return ListUserData.builder()
                .id(id)
                .email(email)
                .first_name(firstName)
                .last_name(lastName)
                .avatar(avatar)
                .build();
    }
}