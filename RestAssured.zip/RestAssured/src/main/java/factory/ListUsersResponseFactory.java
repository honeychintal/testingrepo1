package factory;

import data.TestListUsersData;
import model.ListUserData;
import model.ListUserSupport;
import model.ListUsersResponse;

import java.util.List;

public class ListUsersResponseFactory {
    public static ListUsersResponse createListUsersResponse(Integer page, Integer PerPage, Integer total, Integer totalPage,
                                                            List<ListUserData> data, ListUserSupport support)
    {
        return ListUsersResponse.builder()
                .page(page)
                .per_page(PerPage)
                .total(total)
                .total_pages(totalPage)
                .data(data)
                .support(support)
                .build();
    }
    public static ListUsersResponse createExceptedListUserResponse()
    {
        return createListUsersResponse(
                2,
                6,
                12,
                2,
                TestListUsersData.getAdminListUserData(),
                TestListUsersData.getAdminListUserSupport()
                );
    }
}

