package Admin;

import client.DmdcClient;
import com.google.gson.Gson;
import factory.CreateUserRequestFactory;
import factory.CreateUserResponseFactory;
import io.restassured.response.Response;
import model.ListCreateUserRequest;
import model.ListCreateUserResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;


public class DMDCCreateUserTest {

    Logger log = LoggerFactory.getLogger(DMDCCreateUserTest.class);
    @Test
    public void testCreateUserRequest()
    {

        log.info("Retrieve user Register request details");
        ListCreateUserRequest body=CreateUserRequestFactory.createExpectedUserRequest();
        String requestBody=new Gson().toJson(body);
        //System.out.println("requestBody="+requestBody);
        //Actual response Body
        log.info("Retrieve Create User actual response details");
        Response actualResponse= DmdcClient.postCreateUser(requestBody);
        //expected response Body
        log.info("Retrieve Create User expected response details");
        ListCreateUserResponse expectedResponse= CreateUserResponseFactory.createExpectedUserResponse();
        //Validate Expected Response Body and Actual Response Body
        /*//actual response body convert
        ResponseBody responseBody= actualResponse.getBody();
        String actualResponse1 =responseBody.asString();
        System.out.println("ActualResponse:"+actualResponse1);
        //excepted response body convert
        String expectedResponse1 = new Gson().toJson(expectedresponse);
        System.out.println("expectedResponse:"+ expectedResponse1);
        DmdcClient.validateResponseBody(actualResponse1,expectedResponse1);
        */
        log.info("Validating actual and expected response details");
        DmdcClient.validateResponseBodyTest(actualResponse,expectedResponse);
        log.info("Test case Successful");
    }
}
