package Admin;

import client.DmdcClient;
import com.google.gson.Gson;
import factory.ListRegisterRequestFactory;
import factory.ListRegisterResponseFactory;
import io.restassured.response.Response;
import model.ListRegisterRequest;
import model.ListRegisterResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

public class DMDCListRegisterTest {

    Logger log = LoggerFactory.getLogger(DMDCListRegisterTest.class);
    @Test
    public void testRegisterSuccessful()
    {

        log.info("User Register Successful TestCase Start");
        log.info("Retrieve user Register request details");
        ListRegisterRequest body = ListRegisterRequestFactory.createExpectedRegRequest();
        String requestBody=new Gson().toJson(body);
        //System.out.println("requestBody="+requestBody);
        //Actual response Body
        log.info("Retrieve user Register Actual response details");
        Response actualResponse= DmdcClient.postRegisterResponse(requestBody);
        //expected response Body
        log.info("Retrieve user Register Excepted response details");
        ListRegisterResponse expectedResponse= ListRegisterResponseFactory.createExceptedRegResponse();
        log.info("Validating actual and expected response");
        DmdcClient.validRegisterResponseTest(actualResponse,expectedResponse);
        log.info("TestCase successful");
    }
    @Test
    public void testRegisterUnsuccessful()
    {

        log.info("User Register UnSuccessful TestCase Start");
        log.info("Retrieve user Register request details");
        ListRegisterRequest body = ListRegisterRequestFactory.createExpectedInvalidRegRequest();
        String requestBody=new Gson().toJson(body);
        //System.out.println("requestBody="+requestBody);
        log.info("Retrieve user Register Actual response details");
        Response actualResponse= DmdcClient.postRegisterResponse(requestBody);
        log.info("InValidating actual and expected response");
        DmdcClient.invalidRegisterResponseTest(actualResponse);
        log.info("TestCase successful");
    }
}
