package Admin;


import client.DmdcClient;
import com.google.gson.Gson;
import factory.ListUsersResponseFactory;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import model.ListUsersResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

public class DMDCListUserTest {

    Logger log = LoggerFactory.getLogger(DMDCListUserTest.class);
    @Test
    public void testListUser()  {

        log.info("Start Testing");
        int pageNo = 2;
        log.info("Retrieve user actual response details");
        Response response = DmdcClient.getListUser(pageNo);
        ResponseBody<?> responseBody= response.getBody();
        String actualResponse =responseBody.asString();
        log.info("Retrieve user Expected response details");
        ListUsersResponse expectedResponseBody = ListUsersResponseFactory.createExceptedListUserResponse();
        String expectedResponse=new Gson().toJson(expectedResponseBody);
        //validating response body
        log.info("Validating actual and expected response");
        Assert.assertEquals(actualResponse,expectedResponse);
        log.info("TestCase successful");
    }
}
