package base;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import io.github.bonigarcia.wdm.WebDriverManager;
import utilities.CookiesGetter;

public class TestBase {
	public static WebDriver driver;
	public static Properties prop = new Properties();
	public static Properties loc = new Properties();
	public static Alert simpleAlert;
	
	@BeforeMethod
	public void setup() throws IOException
	{
		System.out.println("current Directory:"+System.getProperty("user.dir"));
		if(driver==null){
			FileReader fr= new FileReader(System.getProperty("user.dir")+"\\src\\test\\resources\\configFiles\\config.properties");
			FileReader fr1= new FileReader(System.getProperty("user.dir")+"\\src\\test\\resources\\configFiles\\locators.properties");			
			prop.load(fr);
			loc.load(fr1);
		}
		
		if(prop.getProperty("browser").equalsIgnoreCase("chrome")){
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
//			driver.get(prop.getProperty("testUrl"));
		}
		else if(prop.getProperty("browser").equalsIgnoreCase("edge")){
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
//			driver.get(prop.getProperty("testUrl"));
		}
		driver.get(prop.getProperty("testUrl"));
		driver.manage().window().maximize();
		CookiesGetter.saveCookies();
	}
	@AfterMethod
	public void teardown()
	{
		driver.quit();
	}
}
