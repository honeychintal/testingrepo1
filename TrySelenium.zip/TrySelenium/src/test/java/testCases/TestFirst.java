package testCases;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;
import base.TestBase;
import utilities.CookiesGetter;
import utilities.ReadXls;
import utilities.UtilMethods;

public class TestFirst extends TestBase{
	
	@Test(dataProviderClass = ReadXls.class,dataProvider = "logindata")
	void loginTest(String username,String password) throws InterruptedException
	{
		UtilMethods.findElementbyNameSendKeys(loc.getProperty("Uid_input"),username);
		UtilMethods.findElementbyNameSendKeys(loc.getProperty("Upass_input"),password);
		UtilMethods.findElementbyNameandClick(loc.getProperty("Login_btn"));
		Thread.sleep(3000);
		Assert.assertEquals(driver.getCurrentUrl(), "https://demo.guru99.com/V4/manager/Managerhomepage.php");
	}
	
	@Test
	void newCustomerTest() throws InterruptedException
	{
		driver.get("https://demo.guru99.com/V4/manager/addcustomerpage.php");
		CookiesGetter.passCookies();
		Thread.sleep(4000);
		UtilMethods.findElementbyNameSendKeys("name","RAkeshhh");
		UtilMethods.findElementbyXpathandClick("/html/body/table/tbody/tr/td/table/tbody/tr[5]/td[2]/input[2]");
		UtilMethods.findElementbyNameSendKeys("dob","26042022");
		UtilMethods.findElementbyNameSendKeys("addr","My  new Addresss");
		UtilMethods.findElementbyNameSendKeys("city","Miyapur");
		UtilMethods.findElementbyNameSendKeys("state","Hyderabad");
		UtilMethods.findElementbyNameSendKeys("pinno","982556");
		UtilMethods.findElementbyNameSendKeys("telephoneno","9826865874");
		UtilMethods.findElementbyNameSendKeys("emailid","rakesh.ranjan@mail.col");
		UtilMethods.findElementbyNameSendKeys("password","Xyz@1234");
		Thread.sleep(2000);
		UtilMethods.findElementbyNameandClick("sub");
		Thread.sleep(2000);
		//Customer Id: 78991
	}
//	@Test
	void deleteCustomerTest() throws InterruptedException
	{
		Thread.sleep(5000);
//		driver.get("https://demo.guru99.com/V4/manager/DeleteCustomerInput.php");
//		driver.manage().
		driver.findElement(By.xpath("//a[@href=\"DeleteCustomerInput.php\"]")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("dismiss-button")).click();
		Thread.sleep(4000);
		UtilMethods.findElementbyNameSendKeys("cusid", "11701");
		UtilMethods.findElementbyNameandClick("AccSubmit");
		Thread.sleep(2000);
		simpleAlert = driver.switchTo().alert();
	    simpleAlert.accept();
		Thread.sleep(4000);
	}
}
