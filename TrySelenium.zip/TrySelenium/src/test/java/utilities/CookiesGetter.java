package utilities;

import java.util.Date;
import org.openqa.selenium.Cookie;
import base.TestBase;

public class CookiesGetter extends TestBase{
	static String name;
    static String value;	
    static String domain;				
    static String path;
    static Date expiry = null;
    static Boolean isSecure;

	public static void cookieSetting(){
		saveCookies();
		passCookies();
	}
	
	public static void saveCookies()
	{
		for(Cookie ck : driver.manage().getCookies())							
        {			
			name= ck.getName();
			value= ck.getValue();
			domain= ck.getDomain();
			path=ck.getPath();
			expiry= ck.getExpiry();
			isSecure = ck.isSecure();
            System.out.println(ck.getName()+";"+ck.getValue()+";"+ck.getDomain()+";"+ck.getPath()+";"+ck.getExpiry()+";"+ck.isSecure());
            
            System.out.println(name+" {{{}}} "+value+" {{{}}} "+domain+" {{{}}} "+path+" {{{}}} "+expiry+" {{{}}} "+isSecure);
        }	
	}
	public static void passCookies()
	{
		Cookie cookie= new Cookie(name,value,domain,path,expiry,isSecure);
		driver.manage().addCookie(cookie);
	}
}
