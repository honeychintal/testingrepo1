package utilities;

import org.openqa.selenium.By;
import base.TestBase;

public class UtilMethods extends TestBase {
	public static void findElementbyNameSendKeys(String element,String keys){
		driver.findElement(By.name(element)).sendKeys(keys);	
	}
	public static void findElementbyXpathSendKeys(String element,String keys){
		driver.findElement(By.xpath(element)).sendKeys(keys);	
	}
	public static void findElementbyXpathandClick(String element){
		driver.findElement(By.xpath(element)).click();	
	}
	public static void findElementbyNameandClick(String element){
		driver.findElement(By.name(element)).click();	
	}
}
