package com.disney.qa;

import com.microsoft.sqlserver.jdbc.SQLServerDataSource;
import com.typesafe.config.Config;

public class AzureMgr extends SqlDbMgr {
    private static final String URL_CONFIG_KEY = "url";
    private static final String DATABASE_CONFIG_KEY = "database";
    private static final String USER_CONFIG_KEY = "user";
    private static final String PASSWORD_CONFIG_KEY = "password";
    private static final String AUTHENTICATION_CONFIG_KEY = "authentication";

    public AzureMgr(Config config) {
        this(config.getString(URL_CONFIG_KEY),
                config.getString(DATABASE_CONFIG_KEY),
                config.getString(USER_CONFIG_KEY),
                config.getString(PASSWORD_CONFIG_KEY),
                config.getString(AUTHENTICATION_CONFIG_KEY));
    }

    public AzureMgr(String url, String database, String user, String password, String authentication) {
        super(new SQLServerDataSource());
        ((SQLServerDataSource) dataSource).setServerName(url);
        ((SQLServerDataSource) dataSource).setDatabaseName(database);
        ((SQLServerDataSource) dataSource).setUser(user);
        ((SQLServerDataSource) dataSource).setPassword(password);
        ((SQLServerDataSource) dataSource).setAuthentication(authentication);
    }
}
