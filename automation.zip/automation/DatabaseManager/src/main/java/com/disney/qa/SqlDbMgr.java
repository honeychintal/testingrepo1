package com.disney.qa;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public abstract class SqlDbMgr {
    DataSource dataSource;

    protected SqlDbMgr(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public <T> T executeToObject(String query, Class<T> type, Object... params) throws SQLException {
        QueryRunner run = new QueryRunner(dataSource);
        ResultSetHandler<T> h = new BeanHandler<T>(type);
        return run.query(query, h, params);
    }

    public <T> List<T> executeToList(String query, Class<T> type, Object... params) throws SQLException {
        QueryRunner run = new QueryRunner(dataSource);
        ResultSetHandler<List<T>> h = new BeanListHandler<T>(type);
        return run.query(query, h, params);
    }

    public <T> T executeSpToObject(String sp, Class<T> type, Object... params) throws SQLException {
        return executeToObject(sp, type, params);
    }

    public <T> List<T> executeSpToList(String sp, Class<T> type, Object... params) throws SQLException {
        return executeToList(sp, type, params);
    }

    public List<List<Map<String, Object>>> executeMultiTableSp(String sp, Object... params) throws SQLException {
        List<List<Map<String, Object>>> tables;

        try (Connection conn = dataSource.getConnection()) {
            try (PreparedStatement stmt = conn.prepareStatement(sp)) {
                setStatementParameters(stmt, params);
                tables = executeStatementToMapLists(stmt);
            }
        }

        return tables;
    }

    private void setStatementParameters(PreparedStatement stmt, Object... params) throws SQLException {
        for (int i = 0; i < params.length; i++)
            stmt.setObject(i + 1, params[i]);
    }

    private List<List<Map<String, Object>>> executeStatementToMapLists(PreparedStatement stmt) throws SQLException {
        ResultSet rs = stmt.executeQuery();

        if (rs == null)
            throw new SQLException("No results were returned from the statement execution.");

        List<List<Map<String, Object>>> tables = new ArrayList<List<Map<String, Object>>>();

        while (!rs.isClosed()) {
            tables.add(createTableFromResultSet(rs));
            rs.close();
            rs = getMoreResults(stmt);
        }

        return tables;
    }

    private List<Map<String, Object>> createTableFromResultSet(ResultSet rs) throws SQLException {
        List<Map<String, Object>> table = new ArrayList<Map<String, Object>>();

        while (rs.next())
            table.add(createRowFromResultSet(rs));

        return table;
    }

    private Map<String, Object> createRowFromResultSet(ResultSet rs) throws SQLException {
        Map<String, Object> row = new HashMap<String, Object>();
        ResultSetMetaData md = rs.getMetaData();

        for (int i = 1; i <= md.getColumnCount(); i++) {
            row.put(md.getColumnName(i), rs.getObject(i));
        }

        return row;
    }

    /***
     * Managing a JDBC behavior.
     * Calls the .getResultSet() method once, to return the result set at index 1 (after 0)
     * For the next calls, .getResultSet() will return the result set at the current index.
     * Checking for isClosed() and .getMoreResults() will move the cursor to the next index,
     * Then .getResultSet() will return the result set at the current index.
     * @param stmt - A statement that has already been executed
     * @return the current result set
     * @throws SQLException
     */
    private ResultSet getMoreResults(PreparedStatement stmt) throws SQLException {
        ResultSet rs = stmt.getResultSet();

        if (rs.isClosed() && stmt.getMoreResults())
            rs = stmt.getResultSet();

        return rs;
    }
}
