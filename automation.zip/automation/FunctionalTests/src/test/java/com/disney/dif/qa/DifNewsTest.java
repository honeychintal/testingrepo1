package com.disney.dif.qa;

import com.disney.dmdc.qa.client.DifMarketingClient;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.groups.TestGroups;
import org.testng.annotations.Test;

public class DifNewsTest {

    @Test(
            groups = {DmdcGroups.NEWS, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[News][/api/portal/news] Test News without Header Cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-205")})
    public void testNewsWithoutCookie() {

        DifMarketingClient.getNews()
                .dmdstatsContractsAndNoAuth()
                .execute();
    }

    @Test(
            groups = {DmdcGroups.NEWS, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[News][/api/portal/news] Test News with invalid Header Cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-279")})
    public void testNewsWithInvalidCookie() {

        DifMarketingClient.getNews()
                .invalidDmdStatsAuthAndContracts(TestUser.INVALID_DMDSTATS)
                .execute();
    }
}