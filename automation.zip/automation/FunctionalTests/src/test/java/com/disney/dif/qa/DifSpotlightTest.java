package com.disney.dif.qa;

import com.disney.dmdc.qa.client.DifMarketingClient;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.groups.TestGroups;
import org.testng.annotations.Test;

public class DifSpotlightTest {
    @Test(
            groups = {DmdcGroups.SPOTLIGHT, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Spotlight][/api/portal/spotlight] Test Spotlight without Header Cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-543")})
    public void testSpotlightWithoutCookie() {

        DifMarketingClient.getSpotlight()
                .dmdstatsContractsAndNoAuth()
                .execute();
    }

    @Test(
            groups = {DmdcGroups.SPOTLIGHT, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Spotlight][/api/portal/spotlight] Test Spotlight with Invalid Header Cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-545")})
    public void testSpotlightWithInvalidCookie() {

        DifMarketingClient.getSpotlight()
                .invalidDmdStatsAuthAndContracts(TestUser.INVALID_DMDSTATS)
                .execute();
    }
}
