package com.disney.dif.qa;

import com.disney.dmdc.qa.client.DifMarketingClient;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.factory.TitleAdditionalDataGetResponseFactory;
import com.disney.dmdc.qa.model.TitleAdditionalDataGetResponse;
import com.disney.dmdc.qa.request.MarketingDifRequest;
import com.disney.dmdc.qa.util.TestServicesConfig;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.dmdc.qa.util.data.TitlesData;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.groups.TestGroups;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

public class DmdcTitleAdditionalDataTest {

    private static final Logger log = LoggerFactory.getLogger(DmdcTitleAdditionalDataTest.class);

    private static final TestUserCache testUserCache = new TestUserCache();
    private static final TestUser marketingDifUser = testUserCache.getTestUserFromConfig(TestUserCache.MARKETING_DIF_USER_KEY);

    boolean dbValidationFlag = TestServicesConfig.shouldCompareResponseToBackendDatabase();

    @Test(
            groups = {
                    DmdcGroups.TITLES,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Title][/api/portal/title/<title id>/additionaldata] Test title additionaldata Details"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-595")})
    public void testTitleAdditionalData() {

        log.info("Retrieve Title details when title is associated with DU 1 (TVD) and 2 (HE)");
        String appTitleGuid = TitlesData.getDifTvdHeTitleGuid();

        log.info(String.format("Creating request object with status, headers, json schema contracts of " +
                "title GUID %s", appTitleGuid));
        MarketingDifRequest titleAdditionalDataRequest = DifMarketingClient
                .getAdditionalData(appTitleGuid)
                .authenticationDmdStatsOnly(marketingDifUser.getDmdstats());

        if (dbValidationFlag) {
            log.info("As dbValidationFlag is true, generating expected response and adding body contract");
            TitleAdditionalDataGetResponse expectedResponse = TitleAdditionalDataGetResponseFactory
                    .createAdditionalDataResponse(appTitleGuid);

            titleAdditionalDataRequest.contract(
                    ContractBody.builder()
                            .jsonEquals(expectedResponse)
                            .build()
            );
        }

        log.info("Hitting the request and validating contracts");
        titleAdditionalDataRequest
                .execute()
                .as(TitleAdditionalDataGetResponse.class);

    }

    @Test(
            groups = {
                    DmdcGroups.TITLES,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Title][/api/portal/title/<title id>/additionaldata] Test title additionaldata without Header Cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-599")})
    public void testAdditionalDataWithoutCookie() {

        log.info("Retrieve Title details when title is associated with DU 1 (TVD) and 2 (HE)");
        String appTitleGuid = TitlesData.getDifTvdHeTitleGuid();

        DifMarketingClient.getAdditionalData(appTitleGuid)
                .dmdstatsContractsAndNoAuth()
                .execute();
    }

    @Test(
            groups = {
                    DmdcGroups.TITLES,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Title][/api/portal/title/<title id>/additionaldata] Test title additionaldata with invalid Header Cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-602")})
    public void testAdditionalDataWithInvalidCookie() {

        log.info("Retrieve Title details when title is associated with DU 1 (TVD) and 2 (HE)");
        String appTitleGuid = TitlesData.getDifTvdHeTitleGuid();

        DifMarketingClient.getAdditionalData(appTitleGuid)
                .invalidDmdStatsAuthAndContracts(TestUser.INVALID_DMDSTATS)
                .execute();
    }
}
