package com.disney.dmdc.qa;

import com.disney.dmdc.qa.client.DmdcMarketingClient;
import com.disney.dmdc.qa.constant.DistributionUnitIds;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.data.TestTitleData;
import com.disney.dmdc.qa.data.TestTitles;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.factory.TitleAwardsResponseFactory;
import com.disney.dmdc.qa.model.TitleAwardsGetResponse;
import com.disney.dmdc.qa.request.MarketingDmdcRequest;
import com.disney.dmdc.qa.util.TestServicesConfig;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.dmdc.qa.util.data.DistributionUnitData;
import com.disney.dmdc.qa.util.data.TitlesData;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.groups.TestGroups;
import net.javacrumbs.jsonunit.core.Option;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

public class DMDCTitleAwardsTest {

    private static final Logger log = LoggerFactory.getLogger(DMDCTitleAwardsTest.class);

    private static final TestUserCache testUserCache = new TestUserCache();
    private static final TestUser marketingTvdHeUser = testUserCache.getTestUserFromConfig(TestUserCache
            .MARKETING_TVD_HE_USER_KEY);

    boolean dbValidationFlag = TestServicesConfig.shouldCompareResponseToBackendDatabase();

    @Test(
            groups = {
                    DmdcGroups.TITLES,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleid>/awards] Test To Retrieve title Award Details"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-340")})
    public void testAwards() {

        log.info("Retrieve Title details when title is associated with DU 1 (TVD) and 2 (HE)");
        String appTitleGuid = TitlesData.getTvdHeAwardGuid();

        int distId = DistributionUnitData.getTvd();

        log.info(String.format("Creating request object with status, headers, json schema contracts of " +
                "title GUID %s", appTitleGuid));
        MarketingDmdcRequest titleAwardGetRequest = DmdcMarketingClient
                .getTitleAwards(appTitleGuid, distId)
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats());

        if (dbValidationFlag) {
            log.info("As dbValidationFlag is true, generating expected response and adding body contract");
            TitleAwardsGetResponse expectedResponse = TitleAwardsResponseFactory.createAwardsResponse(appTitleGuid, distId);

            titleAwardGetRequest.contract(
                    ContractBody.builder()
                            .jsonEquals(expectedResponse)
                            // Since the json has multi array items, it is checking with order, so added the option 'IGNORING_ARRAY_ORDER'.
                            .option(Option.IGNORING_ARRAY_ORDER)
                            .build()
            );
        }

        log.info("Hitting the request and validating contracts");
        titleAwardGetRequest
                .execute()
                .as(TitleAwardsGetResponse.class);
    }

    @Test(
            groups = {
                    DmdcGroups.TITLES,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleid>/awards] Test title Award Details without Header Cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-354")})
    public void testAwardsWithoutDmdstats() {

        // retrieve Title details when title is associated with DU 1 (TVD) and DU 2 (HE) and passing DU 2 as query param
        TestTitles testTitle = TestTitleData.getTitleDUTvdHe();

        //Get 401 when dmdstats cookie is not provided
        DmdcMarketingClient.getTitleAwards(testTitle.getTitleId(),
                DistributionUnitIds.HOME_ENTERTAINMENT)
                .dmdstatsContractsAndNoAuth()
                .execute();
    }

    @Test(
            groups = {
                    DmdcGroups.TITLES,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleid>/awards] Test title Award Details with invalid header cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-356")})
    public void testAwardsWithInvalidDmdstats() {

        // retrieve Title details when title is associated with DU 1 (TVD) and DU 2 (HE) and passing DU 2 as query param
        TestTitles testTitle = TestTitleData.getTitleDUTvdHe();

        //Get 401 when invalid dmdstats cookie is provided
        DmdcMarketingClient.getTitleAwards(testTitle.getTitleId(),
                DistributionUnitIds.HOME_ENTERTAINMENT)
                .invalidDmdStatsAuthAndContracts(TestUser.INVALID_DMDSTATS)
                .execute();
    }
}
