package com.disney.dmdc.qa;

import com.disney.dmdc.qa.client.DmdcMarketingClient;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.factory.AssetAudioChannelsResponseFactory;
import com.disney.dmdc.qa.model.AssetAudioChannelsResponse;
import com.disney.dmdc.qa.request.MarketingDmdcRequest;
import com.disney.dmdc.qa.util.TestServicesConfig;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.dmdc.qa.util.data.AssetsData;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.groups.TestGroups;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

public class DmdcAssetAudioChannelsTest {

    private static final TestUserCache testUserCache = new TestUserCache();
    private static final TestUser marketingTvdHeUser = testUserCache.getTestUserFromConfig(TestUserCache.MARKETING_TVD_HE_USER_KEY);
    private static final Logger log = LoggerFactory.getLogger(DmdcAssetAudioChannelsTest.class);
    boolean dbValidationFlag = TestServicesConfig.shouldCompareResponseToBackendDatabase();

    @Test(
            groups = {DmdcGroups.ASSETS, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Asset][/api/portal/asset/<assetId>/quickview/audiochannels] Test Asset Audiochannels"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-158")})
    public void testAssetAudioChannels() {

        log.info("Getting the asset id from the config file");
        Integer testAssetId = AssetsData.getAssetId();

        log.info("Creating request object with status, headers and json schema contract");
        MarketingDmdcRequest titleAssetAudioChannelsGetRequest = DmdcMarketingClient.getAssetAudioChannels(testAssetId)
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats());

        if (dbValidationFlag) {
            log.info("As dbValidationFlag is true, generating expected response and adding body contract");
            AssetAudioChannelsResponse expectedResponse = AssetAudioChannelsResponseFactory
                    .createExpectedAssetAudioChannelsResponse(testAssetId);

            titleAssetAudioChannelsGetRequest.contract(
                    ContractBody.builder()
                            .jsonEquals(expectedResponse)
                            .build()
            );
        }

        log.info("Hitting the request and validating contracts");
        titleAssetAudioChannelsGetRequest
                .execute()
                .as(AssetAudioChannelsResponse.class);

    }

    @Test(
            groups = {DmdcGroups.ASSETS, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Asset][/api/portal/asset/<assetId>/quickview/audiochannels] " +
                    "Test Asset Audiochannels without header cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-827")})
    public void testAssetAudioChannelsWithoutCookie() {

        Integer testAssetId = AssetsData.getAssetId();

        DmdcMarketingClient.getAssetAudioChannels(testAssetId)
                .dmdstatsContractsAndNoAuth()
                .execute();
    }

    @Test(
            groups = {DmdcGroups.ASSETS, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Asset][/api/portal/asset/<assetId>/quickview/audiochannels] " +
                    "Test Asset Audiochannels with invalid header cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-828")})
    public void testAssetAudioChannelsWithInvalidCookie() {

        Integer testAssetId = AssetsData.getAssetId();

        DmdcMarketingClient.getAssetAudioChannels(testAssetId)
                .invalidDmdStatsAuthAndContracts(TestUser.INVALID_DMDSTATS)
                .execute();
    }
}