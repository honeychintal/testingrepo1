package com.disney.dmdc.qa;

import com.disney.dmdc.qa.client.DmdcMarketingClient;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.data.TestAssetAudioChannelsData;
import com.disney.dmdc.qa.data.TestAssetInfoResultData;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.factory.AssetInfoResponseFactory;
import com.disney.dmdc.qa.model.AssetInfoResponse;
import com.disney.dmdc.qa.model.AssetInfoResult;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.groups.TestGroups;
import net.javacrumbs.jsonunit.core.Option;
import org.testng.annotations.Test;

public class DmdcAssetInfoTest {

    private static final TestUserCache testUserCache = new TestUserCache();
    private static final TestUser marketingTvdHeUser = testUserCache.getTestUserFromConfig(TestUserCache.MARKETING_TVD_HE_USER_KEY);

    /**
     * We are validating API response with static data as there is an open issue
     * while retrieving data through Stored Proc for this endpoint
     * Jira ticket to track issue- https://jira.disney.com/browse/PPBPE-2652
     */
    @Test(
            groups = {DmdcGroups.ASSETS, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Asset][/api/portal/asset/<assetId>/quickview/info] Test Asset quickview Info"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-188")})
    public void testAssetQuickViewInfo() {

        String testAssetId = TestAssetAudioChannelsData.getAssetId();
        AssetInfoResult assetInfoResult = TestAssetInfoResultData.getAssetInfoResultData();

        AssetInfoResponse expectedResponse = AssetInfoResponseFactory
                .createDefaultAssetInfoResponse(assetInfoResult);

        DmdcMarketingClient.getAssetInfo(testAssetId)
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats())
                .contract(
                        ContractBody.builder()
                                .jsonEquals(expectedResponse)
                                // Option will be removed once DB implementation is in place
                                .option(Option.IGNORING_EXTRA_ARRAY_ITEMS)
                                .build())
                .execute();
    }

    @Test(
            groups = {DmdcGroups.ASSETS, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Asset][/api/portal/asset/<assetId>/quickview/info] Test Asset Info without " +
                    "the 'Cookie' as header"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-195")})
    public void testAssetInfoWithoutCookie() {

        String testAssetId = TestAssetAudioChannelsData.getAssetId();

        DmdcMarketingClient.getAssetInfo(testAssetId)
                .dmdstatsContractsAndNoAuth()
                .execute();
    }

    @Test(
            groups = {DmdcGroups.ASSETS, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Asset][/api/portal/asset/<assetId>/quickview/info] Test Asset Info with " +
                    "Invalid dmdstats In Cookie as header"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-290")})
    public void testAssetInfoWithInvalidCookie() {

        String testAssetId = TestAssetAudioChannelsData.getAssetId();

        DmdcMarketingClient.getAssetInfo(testAssetId)
                .invalidDmdStatsAuthAndContracts(TestUser.INVALID_DMDSTATS)
                .execute();
    }

}
