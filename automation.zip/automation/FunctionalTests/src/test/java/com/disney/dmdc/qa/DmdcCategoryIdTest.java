package com.disney.dmdc.qa;

import com.disney.dmdc.qa.client.DmdcMarketingClient;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.factory.CategoryIdResponseFactory;
import com.disney.dmdc.qa.model.CategoryIdResponse;
import com.disney.dmdc.qa.request.MarketingDmdcRequest;
import com.disney.dmdc.qa.util.TestServicesConfig;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.dmdc.qa.util.data.CategoryData;
import com.disney.dmdc.qa.util.data.TitlesData;
import com.disney.dmdc.qa.util.data.UsersData;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.groups.TestGroups;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

public class DmdcCategoryIdTest {

    private static final Logger log = LoggerFactory.getLogger(DmdcCategoryIdTest.class);

    private static final TestUserCache testUserCache = new TestUserCache();
    private static final TestUser marketingTvdHeUser = testUserCache.getTestUserFromConfig(TestUserCache.MARKETING_TVD_HE_USER_KEY);

    boolean dbValidationFlag = TestServicesConfig.shouldCompareResponseToBackendDatabase();

    @Test(
            groups = {DmdcGroups.CATEGORIES, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Category][/api/portal/category/<category-id>] Test Category"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-380")})
    public void testCategoryId() {

        log.info("Retrieving the TitleGUID and userId to get the data from DB");
        String appTitleGuid = TitlesData.getTvdHeGuid();
        int userId = UsersData.getTvdHeId();

        log.info("Retrieving the categoryId");
        String categoryId = CategoryData.getCategoryId();

        log.info("Creating request object with status, headers, json schema contracts");
        MarketingDmdcRequest categoryIdRequest = DmdcMarketingClient.getCategoryId(categoryId)
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats());


        if (dbValidationFlag) {
            log.info("As dbValidationFlag is true, generating expected response and adding body contract");
            CategoryIdResponse expectedResponse = CategoryIdResponseFactory
                    .createDefaultCategoryIdResponseFromDB(appTitleGuid, userId, null, categoryId);

            categoryIdRequest.contract(
                    ContractBody.builder()
                            .jsonEquals(expectedResponse)
                            .build()
            );
        }

        log.info("Hitting the request and validating contracts");
        CategoryIdResponse categoryIdResponse = categoryIdRequest
                .execute()
                .as(CategoryIdResponse.class);

    }

    @Test(
            groups = {DmdcGroups.CATEGORIES, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Category][/api/portal/category/<category-id>] Test Category without header cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-384")})
    public void testCategoryIdWithoutCookie() {

        log.info("Retrieving the categoryId");
        String categoryId = CategoryData.getCategoryId();

        DmdcMarketingClient.getCategoryId(categoryId)
                .dmdstatsContractsAndNoAuth()
                .execute();

    }

    @Test(
            groups = {DmdcGroups.CATEGORIES, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Category][/api/portal/category/<category-id>] Test Category with invalid header cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-390")})
    public void testCategoryIdWithInvalidCookie() {

        log.info("Retrieving the categoryId");
        String categoryId = CategoryData.getCategoryId();

        DmdcMarketingClient.getCategoryId(categoryId)
                .invalidDmdStatsAuthAndContracts(TestUser.INVALID_DMDSTATS)
                .execute();

    }
}