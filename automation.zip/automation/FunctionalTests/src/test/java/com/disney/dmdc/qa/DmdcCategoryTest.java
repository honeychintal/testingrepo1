package com.disney.dmdc.qa;

import com.disney.dmdc.qa.client.DmdcMarketingClient;
import com.disney.dmdc.qa.constant.CategoryModes;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.factory.CategoryResponseFactory;
import com.disney.dmdc.qa.model.CategoryResponse;
import com.disney.dmdc.qa.request.MarketingDmdcRequest;
import com.disney.dmdc.qa.util.TestServicesConfig;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.dmdc.qa.util.data.TitlesData;
import com.disney.dmdc.qa.util.data.UsersData;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.groups.TestGroups;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

public class DmdcCategoryTest {

    private static final Logger log = LoggerFactory.getLogger(DmdcCategoryIdTest.class);

    private static final TestUserCache testUserCache = new TestUserCache();
    private static final TestUser marketingTvdHeUser = testUserCache
            .getTestUserFromConfig(TestUserCache.MARKETING_TVD_HE_USER_KEY);

    boolean dbValidationFlag = TestServicesConfig.shouldCompareResponseToBackendDatabase();

    @Test(
            groups = {DmdcGroups.CATEGORIES, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Category][/api/portal/category] Test Category with mode value as system"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-385")})
    public void testCategoryWithSystemMode() {

        log.info("Retrieving the TitleGUID and userId to get the data from DB");
        String appTitleGuid = TitlesData.getTvdHeGuid();
        int userId = UsersData.getTvdHeId();

        log.info("Creating request object with status, headers, json schema contracts");
        MarketingDmdcRequest categoryUserRequest = DmdcMarketingClient.getCategory(
                CategoryModes.SYSTEM)
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats());

        if (dbValidationFlag) {
            log.info("As dbValidationFlag is true, generating expected response and adding body contract");
            CategoryResponse expectedResponse = CategoryResponseFactory
                    .createDefaultCategoryResponseFromDB(appTitleGuid, userId, CategoryModes.SYSTEM, null);

            categoryUserRequest.contract(
                    ContractBody.builder()
                            .jsonEquals(expectedResponse)
                            .build()
            );
        }

        log.info("Hitting the request and validating contracts");
        CategoryResponse categoryResponse = categoryUserRequest
                .execute()
                .as(CategoryResponse.class);

    }

    @Test(
            groups = {DmdcGroups.CATEGORIES, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Category][/api/portal/category] Test Category with mode value as user"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-382")})
    public void testCategoryWithUserMode() {

        log.info("Retrieving the TitleGUID and userId to get the data from DB");
        String appTitleGuid = TitlesData.getTvdHeGuid();
        int userId = UsersData.getTvdHeId();

        log.info("Creating request object with status, headers, json schema contracts");
        MarketingDmdcRequest categoryUserRequest = DmdcMarketingClient.getCategory(
                CategoryModes.USER)
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats());

        if (dbValidationFlag) {
            log.info("As dbValidationFlag is true, generating expected response and adding body contract");
            CategoryResponse expectedResponse = CategoryResponseFactory
                    .createDefaultCategoryResponseFromDB(appTitleGuid, userId, CategoryModes.USER, null);

            categoryUserRequest.contract(
                    ContractBody.builder()
                            .jsonEquals(expectedResponse)
                            .build()
            );
        }

        log.info("Hitting the request and validating contracts");
        CategoryResponse categoryResponse = categoryUserRequest
                .execute()
                .as(CategoryResponse.class);

    }

    @Test(
            groups = {DmdcGroups.CATEGORIES, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Category][/api/portal/category] Test Category without header cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-389")})
    public void testCategoryWithoutCookie() {

        DmdcMarketingClient.getCategory(CategoryModes.SYSTEM)
                .dmdstatsContractsAndNoAuth()
                .execute();
    }

    @Test(
            groups = {DmdcGroups.CATEGORIES, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Category][/api/portal/category] Test Category with invalid header cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-394")})
    public void testCategoryWithInvalidCookie() {

        DmdcMarketingClient.getCategory(CategoryModes.SYSTEM)
                .invalidDmdStatsAuthAndContracts(TestUser.INVALID_DMDSTATS)
                .execute();
    }
}
