package com.disney.dmdc.qa;

import com.disney.dmdc.qa.client.DmdcMarketingClient;
import com.disney.dmdc.qa.constant.DistributionUnitIds;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.constant.LocaleIds;
import com.disney.dmdc.qa.constant.ProductTypeIds;
import com.disney.dmdc.qa.data.TestTitles;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.factory.GetTitleAvailabilityResponseFactory;
import com.disney.dmdc.qa.model.GetTitleAvailabilityResponse;
import com.disney.dmdc.qa.request.MarketingDmdcRequest;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.groups.TestGroups;
import net.javacrumbs.jsonunit.core.Option;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

public class DmdcGetTitleAvailabilityTest {
    private static final TestUserCache testUserCache = new TestUserCache();
    private static final TestUser marketingTvdHeUser = testUserCache.getTestUserFromConfig(
            TestUserCache.MARKETING_TVD_HE_USER_KEY
    );
    private static final Logger log = LoggerFactory.getLogger(DmdcGetTitleAvailabilityTest.class);

    @Test(
            groups = { DmdcGroups.TITLES,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1
            },
            description = "[Title][/api/portal/title/<titleId>/availability] Test Title Availability Details"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-162")})
    public void testTitleAvailabilityDetails() {

        TestTitles titles = TestTitles.ALIEN_VS_PREDATOR_DU_TVD_HE;

        MarketingDmdcRequest request = DmdcMarketingClient.getTitleAvailability(
                titles.getTitleId(),
                titles.getTitleId(),
                DistributionUnitIds.TELEVISION_DISTRIBUTION,
                LocaleIds.ENG_US,
                ProductTypeIds.FEATURE
        )
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats());

        GetTitleAvailabilityResponse expectedResponse = GetTitleAvailabilityResponseFactory
                .createDefaultGetTitleAvailabiltyResponse();

        request.contract(
                ContractBody.builder()
                        .jsonEquals(expectedResponse)
                        //As response is getting too many values at present we are validating only 2 array
                        //items until DB is implemented
                        .option(Option.IGNORING_EXTRA_ARRAY_ITEMS)
                        .build()
        );

        log.info("Hitting the request and validating contracts");
        GetTitleAvailabilityResponse response = request
                .execute()
                .as(GetTitleAvailabilityResponse.class);
    }

    @Test(
            groups = {
                    DmdcGroups.TITLES,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1
            },
            description = "[Title][/api/portal/title/<titleId>/availability] " +
                    "Test Title Availability Details with out header cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-257")})
    public void getTitleAvailabilityWithoutCookie() {

        TestTitles titles = TestTitles.ALIEN_VS_PREDATOR_DU_TVD_HE;

        DmdcMarketingClient.getTitleAvailability(
                titles.getTitleId(),
                titles.getTitleId(),
                DistributionUnitIds.TELEVISION_DISTRIBUTION,
                LocaleIds.ENG_US,
                ProductTypeIds.FEATURE
        )
                .dmdstatsContractsAndNoAuth()
                .execute();
    }

    @Test(
            groups = {
                    DmdcGroups.TITLES,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1
            },
            description = "[Title][/api/portal/title/<titleId>/availability] " +
                    "Test Title Availability Details with invalid header cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-294")})
    public void getTitleAvailabilityWithInvalidCookie() {

        TestTitles titles = TestTitles.ALIEN_VS_PREDATOR_DU_TVD_HE;

        DmdcMarketingClient.getTitleAvailability(
                titles.getTitleId(),
                titles.getTitleId(),
                DistributionUnitIds.TELEVISION_DISTRIBUTION,
                LocaleIds.ENG_US,
                ProductTypeIds.FEATURE
        )
                .invalidDmdStatsAuthAndContracts(TestUser.INVALID_DMDSTATS)
                .execute();
    }

    @Test(
            groups = {
                    DmdcGroups.TITLES,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1
            },
            description = "[Title][/api/portal/title/<titleId>/availability] Test Title Availability Details with valid " +
                    "titleId where titleId as TV season"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-301")})
    public void testTitleAvailabilityDetailsSeason() {

        TestTitles titles = TestTitles.NEW_GIRL;

        MarketingDmdcRequest request = DmdcMarketingClient.getTitleAvailability(
                titles.getTitleId(),
                titles.getTitleId(),
                DistributionUnitIds.TELEVISION_DISTRIBUTION,
                LocaleIds.ENG_US,
                ProductTypeIds.EPISODE,
                true
        )
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats());

        GetTitleAvailabilityResponse response = GetTitleAvailabilityResponseFactory
                .createDefaultGetTitleAvailabiltyResponseSeason();

        request.contract(
                ContractBody.builder()
                        .jsonEquals(response)
                        //As response is getting too many values at present we are validating only 2 array
                        //items until DB is implemented
                        .option(Option.IGNORING_EXTRA_ARRAY_ITEMS)
                        .build()
        );

        log.info("Hitting the request and validating contracts");
        GetTitleAvailabilityResponse responseSeason =request
                .execute()
                .as(GetTitleAvailabilityResponse.class);
    }
}