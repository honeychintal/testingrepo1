package com.disney.dmdc.qa;

import com.disney.dmdc.qa.client.DmdcMarketingClient;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.factory.PlaybackSessionResponseFactory;
import com.disney.dmdc.qa.model.PlaybackSessionGetResponse;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.groups.TestGroups;
import net.javacrumbs.jsonunit.core.Option;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

public class DmdcPlaybackSessionTest {

    private static final TestUserCache testUserCache = new TestUserCache();
    private static final TestUser marketingTvdHeUser = testUserCache
            .getTestUserFromConfig(TestUserCache.MARKETING_TVD_HE_USER_KEY);
    private static final Logger log = LoggerFactory.getLogger(DmdcPlaybackSessionTest.class);

    @Test(
            groups = {DmdcGroups.SESSION, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[portal playback][/api/portal/playback/session] Test the Session information"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-529")})
    public void testPlaybackSessionDetails() {

        PlaybackSessionGetResponse expectedPlaybackSessionResponse = PlaybackSessionResponseFactory
                .createSuccessfulPlaybackSessionResponse();

        log.info("Creating request object with status, headers, json schema contracts");
        DmdcMarketingClient.getPlaybackSessionDetails()
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats())
                .contract(ContractBody.builder()
                        .jsonEquals(expectedPlaybackSessionResponse)
                        // As we are getting dynamic session id in the response, Ignoring the Values
                        // Once DB approach is finalized will be updating this test
                        .option(Option.IGNORING_VALUES)
                        .build()
                )
                .execute()
                .as(PlaybackSessionGetResponse.class);
    }

    @Test(
            groups = {DmdcGroups.SESSION, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[portal playback][/api/portal/playback/session] Test Playback session without header cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-532")})
    public void testPlaybackSessionDetailsWithoutCookie() {

        DmdcMarketingClient
                .getPlaybackSessionDetails()
                .dmdstatsContractsAndNoAuth()
                .execute();
    }

    @Test(
            groups = {DmdcGroups.SESSION, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[portal playback][/api/portal/playback/session] " +
                    "Test Playback session with invalid header cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-534")})
    public void testPlaybackSessionDetailsWithInvalidCookie() {

        DmdcMarketingClient
                .getPlaybackSessionDetails()
                .invalidDmdStatsAuthAndContracts(TestUser.INVALID_DMDSTATS)
                .execute();
    }
}
