package com.disney.dmdc.qa;

import com.disney.dmdc.qa.client.DmdcMarketingClient;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.factory.PortalNavMenuResponsefactory;
import com.disney.dmdc.qa.model.PortalNavMenuGetResponse;
import com.disney.dmdc.qa.request.MarketingDmdcRequest;
import com.disney.dmdc.qa.util.TestServicesConfig;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.dmdc.qa.util.TestUserUtil;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.groups.TestGroups;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

public class DmdcPortalNavMenuTest {

    private static final Logger log = LoggerFactory.getLogger(DmdcPortalNavMenuTest.class);

    private static final TestUserCache testUserCache = new TestUserCache();
    private static final TestUser marketingTvdHeUser = testUserCache.getTestUserFromConfig(TestUserCache.MARKETING_TVD_HE_USER_KEY);
    private static final TestUser adminUser = testUserCache.getTestUserFromConfig(TestUserCache.ADMIN_DMDC_API_AUTOMATION_USER_KEY);

    boolean dbValidationFlag = TestServicesConfig.shouldCompareResponseToBackendDatabase();

    /** This endpoint "/api/portal/nav/menu" is a GET request and response will be w.r.t user authentication.
     * <p> DB refactor is not done for this, since there is no SP mapped w.r.t to the endpoint,
     * as it is a dynamic data w.r.t user permissions
     * Added the JSON Schema validation which checks the format of the API response/
     */
    @Test(
            groups = {
                    DmdcGroups.PORTAL_NAV_MENU,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Nav menu][/api/portal/nav/menu] Test nav menu"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-201")})
    public void testPortalNavMenuForMarketingUser() {

        log.info(String.format("creating expected response for the marketing user %s",
                TestUserUtil.getTestAccountTvdHeMarketingUser().getEmail()));
        PortalNavMenuGetResponse expectedResponse = PortalNavMenuResponsefactory
                .createPortalNavMenuResponse(TestUserUtil.getTestAccountTvdHeMarketingUser());

        log.info("Creating request object with status, headers, json schema contracts");
        DmdcMarketingClient.getPortalNavMenu()
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats())
                .contract(ContractBody.builder()
                        .jsonEquals(expectedResponse)
                        .build())
                .execute()
                .as(PortalNavMenuGetResponse.class);
    }

    /** This endpoint "/api/portal/nav/menu" is a GET request and response will be w.r.t user authentication.
     * <p> DB refactor is not done for this, since there is no SP mapped w.r.t to the endpoint,
     * as it is a dynamic data w.r.t user permissions
     * Added the JSON Schema validation which checks the format of the API response/
     */
    @Test(
            groups = {
                    DmdcGroups.PORTAL_NAV_MENU,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Nav menu][/api/portal/nav/menu] Test nav menu for AdminUser"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-915")})
    public void testPortalNavMenuForAdminUser() {

        log.info(String.format("creating expected response for the admin user %s",
                TestUserUtil.getTestAccountDmdcApiAutomationAdminUser().getEmail()));
        PortalNavMenuGetResponse expectedResponse = PortalNavMenuResponsefactory
                .createPortalNavMenuResponse(TestUserUtil.getTestAccountDmdcApiAutomationAdminUser());

        log.info("Creating request object with status, headers, json schema contracts");
        DmdcMarketingClient.getPortalNavMenu()
                .authenticationDmdStatsOnly(adminUser.getDmdstats())
                .contract(
                        ContractBody.builder()
                                .jsonEquals(expectedResponse)
                                .build()
                )
                .execute()
                .as(PortalNavMenuGetResponse.class);
    }

    @Test(
            groups = {
                    DmdcGroups.PORTAL_NAV_MENU,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Nav menu][/api/portal/nav/menu] Test nav menu without Header Cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-202")})
    public void testPortalNavMenuWithoutCookie() {

        DmdcMarketingClient.getPortalNavMenu()
                .dmdstatsContractsAndNoAuth()
                .execute();
    }

    @Test(
            groups = {
                    DmdcGroups.PORTAL_NAV_MENU,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Nav menu][/api/portal/nav/menu] Test nav menu with invalid header cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-288")})
    public void testPortalNavMenuWithInvalidCookie() {

        DmdcMarketingClient.getPortalNavMenu()
                .invalidDmdStatsAuthAndContracts(TestUser.INVALID_DMDSTATS)
                .execute();
    }
}
