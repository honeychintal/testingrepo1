package com.disney.dmdc.qa;

import com.disney.dmdc.qa.client.DmdcMarketingClient;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.groups.TestGroups;
import org.testng.annotations.Test;

public class DmdcPortalSearchGetTest {

    @Test(
            groups = {DmdcGroups.SEARCH, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Portal Search][/api/portal/search/get] Test to get the information on " +
                    "search Page without Header Cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-577")})
    public void testPortalSearchGetWithoutCookie() {

        DmdcMarketingClient.getPortalSearchGet()
                .dmdstatsContractsAndNoAuth()
                .execute();
    }

    @Test(
            groups = {DmdcGroups.SEARCH, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Portal Search][/api/portal/search/get] Test to get the information on " +
                    "search Page empty cookie in header"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-580")})
    public void testPortalSearchGetEmptyCookie() {

        DmdcMarketingClient.getPortalSearchGet()
                .invalidDmdStatsAuthAndContracts("")
                .execute();
    }

    @Test(
            groups = {DmdcGroups.SEARCH, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Portal Search][/api/portal/search/get] Test to get the information on " +
                    "search Page with invalid header cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-579")})
    public void testPortalSearchGetInvalidCookie() {

        DmdcMarketingClient.getPortalSearchGet()
                .invalidDmdStatsAuthAndContracts(TestUser.INVALID_DMDSTATS)
                .execute();
    }

}
