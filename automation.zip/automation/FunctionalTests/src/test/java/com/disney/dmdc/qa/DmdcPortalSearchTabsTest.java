package com.disney.dmdc.qa;

import com.disney.dmdc.qa.client.DmdcMarketingClient;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.factory.PortalSearchTabsItemsFactory;
import com.disney.dmdc.qa.factory.PortalSearchTabsResponseFactory;
import com.disney.dmdc.qa.model.PortalSearchTabsGetResponse;
import com.disney.dmdc.qa.model.PortalSearchTabsItems;
import com.disney.dmdc.qa.request.MarketingDmdcRequest;
import com.disney.dmdc.qa.util.TestServicesConfig;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.dmdc.qa.util.data.TitlesData;
import com.disney.dmdc.qa.util.data.UsersData;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.groups.TestGroups;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

public class DmdcPortalSearchTabsTest {

    private static final TestUserCache testUserCache = new TestUserCache();
    private static final TestUser marketingTvdHeUser = testUserCache.getTestUserFromConfig(
            TestUserCache.MARKETING_TVD_HE_USER_KEY
    );
    private static final Logger log = LoggerFactory.getLogger(DmdcPortalSearchTabsTest.class);
    boolean dbValidationFlag = TestServicesConfig.shouldCompareResponseToBackendDatabase();

    @Test(groups = { DmdcGroups.PORTAL_SEARCH_TABS, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
          description = "[Portal Search][/api/portal/search/tabs] Test to get Tab details when search is performed"
    )
    @TestDoc(externalIds = { @ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-581") })
    public void testPortalSearchTabs() {
        String appTitleGuid = TitlesData.getTvdHeGuid();
        int userId = UsersData.getTvdHeId();
        String searchMode = "Asset Search";

        log.info("Creating request object with status, headers, json schema contracts");
        MarketingDmdcRequest portalSearchTabsGetRequest = DmdcMarketingClient.getPortalSearchTabs()
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats());

        if(dbValidationFlag){
            log.info("As dbValidationFlag is true, generating expected response");
            List<PortalSearchTabsItems> portalSearchTabsItems = PortalSearchTabsItemsFactory
                    .createPortalSearchTabItemsResponse(userId,appTitleGuid,searchMode);

            PortalSearchTabsGetResponse expectedResponse = PortalSearchTabsResponseFactory.
                    createExpectedPortalSearchTabsResponse(portalSearchTabsItems);

            portalSearchTabsGetRequest.contract(
                    ContractBody.builder()
                            .jsonEquals(expectedResponse)
                            .build()
            );
        }

        log.info("Hitting the request and validating contracts");
        portalSearchTabsGetRequest
                .execute()
                .as(PortalSearchTabsGetResponse.class);
    }

    @Test(groups = { DmdcGroups.PORTAL_SEARCH_TABS, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Portal Search][/api/portal/search/tabs] " +
                    "Test to get Tab details when search is performed without Header Cookie"
    )
    @TestDoc(externalIds = { @ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-582") })
    public void testPortalSearchTabsWithoutCookie(){

        DmdcMarketingClient.getPortalSearchTabs()
                .dmdstatsContractsAndNoAuth()
                .execute();
    }

    @Test(groups = { DmdcGroups.PORTAL_SEARCH_TABS, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Portal Search][/api/portal/search/tabs] " +
                    "Test to get Tab details when search is performed with invalid Header Cookie"
    )
    @TestDoc(externalIds = { @ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-585") })
    public void testPortalSearchTabsWithInvalidCookie(){

        DmdcMarketingClient.getPortalSearchTabs()
                .invalidDmdStatsAuthAndContracts(TestUser.INVALID_DMDSTATS)
                .execute();
    }
}
