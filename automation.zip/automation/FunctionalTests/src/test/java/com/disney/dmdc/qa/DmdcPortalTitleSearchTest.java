package com.disney.dmdc.qa;

import com.disney.dmdc.qa.client.DmdcMarketingClient;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.data.TestTitleSearch;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.factory.TitleSearchRequestFactory;
import com.disney.dmdc.qa.model.TitleSearchRequest;
import com.disney.dmdc.qa.model.TitleSearchResponse;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.dmdc.qa.util.data.TitleNameData;
import com.disney.dmdc.qa.util.data.WprData;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.groups.TestGroups;
import net.javacrumbs.jsonunit.core.Option;
import org.testng.annotations.Test;

public class DmdcPortalTitleSearchTest {

    private static final TestUserCache testUserCache = new TestUserCache();
    private static final TestUser marketingTvdHeUser = testUserCache
            .getTestUserFromConfig(TestUserCache.MARKETING_TVD_HE_USER_KEY);
    private static final String titleName = TitleNameData.getTitleName();

    @Test(
            groups = {DmdcGroups.PORTAL_TITLE_SEARCH, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Portal Title][/api/portal/title/search] " +
                    "Test title search by providing title name as the search key"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-425")})
    public void testPortalTitleSearchWithTitleNameAsKeyword(){

        TitleSearchRequest requestBody = TitleSearchRequestFactory.createRequestWithKeyword(titleName);
        TitleSearchResponse expectedResponse = TestTitleSearch.getTitleSearchResponseForValidTitleName();

        DmdcMarketingClient.postTitleSearchResults(requestBody)
                .authenticationWithAntiforgery(marketingTvdHeUser)
                .contract(
                        ContractBody.builder()
                                .jsonEquals(expectedResponse)
                                // As the response contains more number of array items validating only 1 or 2 items
                                // Once the DB approach is finalized will add validations for all the array items
                                .option(Option.IGNORING_EXTRA_ARRAY_ITEMS)
                                .build()
                )
                .execute()
                .as(TitleSearchResponse.class);
    }

    @Test(
            groups = {DmdcGroups.PORTAL_TITLE_SEARCH, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Portal Title][/api/portal/title/search] " +
                    "Title search with valid keyword"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-637")})
    public void testPortalTitleSearchByProvidingValidKeyword(){

        String keyword = "ALIEN";
        TitleSearchRequest requestBody = TitleSearchRequestFactory.createRequestWithKeyword(keyword);
        TitleSearchResponse expectedResponse = TestTitleSearch.getTitleSearchResponseForValidKeyword();

        DmdcMarketingClient.postTitleSearchResults(requestBody)
                .authenticationWithAntiforgery(marketingTvdHeUser)
                .contract(
                        ContractBody.builder()
                                .jsonEquals(expectedResponse)
                                // As the response contains more number of array items validating only 1 or 2 items
                                // Once the DB approach is finalized will add validations for all the array items
                                .option(Option.IGNORING_EXTRA_ARRAY_ITEMS)
                                .build()
                )
                .execute()
                .as(TitleSearchResponse.class);
    }

    @Test(
            groups = {DmdcGroups.PORTAL_TITLE_SEARCH, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Portal Title][/api/portal/title/search] " +
                    "Test title search (default search) by providing keyword value as TitleID"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-460")})
    public void testPortalTitleSearchByProvidingValidTitleIdAsKeyword() {

        //API response WprId is shown as TitleID in the UI
        String titleId = WprData.getWprID();
        TitleSearchRequest requestBody = TitleSearchRequestFactory.createRequestWithTitleID(titleId);
        TitleSearchResponse expectedResponse = TestTitleSearch.getTitleSearchResponseForValidTitleID();

        DmdcMarketingClient.postTitleSearchResults(requestBody)
                .authenticationWithAntiforgery(marketingTvdHeUser)
                .contract(
                        ContractBody.builder()
                                .jsonEquals(expectedResponse)
                                .build()
                )
                .execute()
                .as(TitleSearchResponse.class);
    }

    @Test(
            groups = {DmdcGroups.PORTAL_TITLE_SEARCH, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Portal Title][/api/portal/title/search] All TV series title search with default filters"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-633")})
    public void testPortalTitleSearchWithAllTvSeasons(){

        TitleSearchRequest requestBody = TitleSearchRequestFactory.createRequestWithAllTvSeasons();
        TitleSearchResponse expectedResponse = TestTitleSearch.getTitleSearchResponseForAllTvSeasons();

        DmdcMarketingClient.postTitleSearchResults(requestBody)
                .authenticationWithAntiforgery(marketingTvdHeUser)
                .contract(
                        ContractBody.builder()
                                .jsonEquals(expectedResponse)
                                // As the search response is dynamic ignoring array order
                                .option(Option.IGNORING_ARRAY_ORDER)
                                // As the response contains more number of array items validating only 1 or 2 items
                                // Once the DB approach is finalized will add validations for all the array items
                                .option(Option.IGNORING_EXTRA_ARRAY_ITEMS)
                                .build()
                )
                .execute()
                .as(TitleSearchResponse.class);
    }

    @Test(
            groups = {DmdcGroups.PORTAL_TITLE_SEARCH, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Portal Title][/api/portal/title/search] Title search with invalid keyword"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-638")})
    public void testPortalTitleSearchWithInvalidKeyword(){

        String invalidTitleName = TitleNameData.getInvalidTitleName();
        TitleSearchRequest requestBody = TitleSearchRequestFactory.createRequestWithKeyword(invalidTitleName);
        TitleSearchResponse expectedResponse = TestTitleSearch.getTitleSearchResponseForInvalidKeyword();

        DmdcMarketingClient.postTitleSearchResults(requestBody)
                .authenticationWithAntiforgery(marketingTvdHeUser)
                .contract(
                        ContractBody.builder()
                                .jsonEquals(expectedResponse)
                                .build()
                )
                .execute()
                .as(TitleSearchResponse.class);
    }

    @Test(
            groups = {DmdcGroups.PORTAL_TITLE_SEARCH, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Portal Title][/api/portal/title/search] " +
                    "Test title search (default search) with an empty keyword"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-453")})
    public void testPortalTitleSearchWithEmptyKeyword(){

        TitleSearchRequest requestBody = TitleSearchRequestFactory.createRequestWithKeyword("");
        TitleSearchResponse expectedResponse = TestTitleSearch.getTitleSearchResponseForInvalidKeyword();

        DmdcMarketingClient.postTitleSearchResults(requestBody)
                .authenticationWithAntiforgery(marketingTvdHeUser)
                .contract(
                        ContractBody.builder()
                                .jsonEquals(expectedResponse)
                                .build()
                )
                .execute()
                .as(TitleSearchResponse.class);
    }

    @Test(
            groups = {DmdcGroups.PORTAL_TITLE_SEARCH, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Portal Title][/api/portal/title/search] " +
                    "Title search with invalid X-XSRF-TOKEN header (valid dmdstats &.Antiforgery cookie header)"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-715")})
    public void testPortalTitleSearchWithInvalidXSRFHeader(){

        TitleSearchRequest requestBody = TitleSearchRequestFactory.createRequestWithKeyword(titleName);

        DmdcMarketingClient.postTitleSearchResults(requestBody)
                .antiforgeryAuthAndNoXsrfContracts(marketingTvdHeUser)
                .xsrf(TestUser.INVALID_XSRF)
                .execute();
    }

    @Test(
            groups = {DmdcGroups.PORTAL_TITLE_SEARCH, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Portal Title][/api/portal/title/search] " +
                    "Test title search without providing the X-XSRF-TOKEN header "
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-452")})
    public void testPortalTitleSearchWithoutXSRFHeader(){

        TitleSearchRequest requestBody = TitleSearchRequestFactory.createRequestWithKeyword(titleName);

        DmdcMarketingClient.postTitleSearchResults(requestBody)
                .antiforgeryAuthAndNoXsrfContracts(marketingTvdHeUser)
                .execute();
    }

    @Test(
            groups = {DmdcGroups.PORTAL_TITLE_SEARCH, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[/api/portal/title/search] " +
                    "Title search with invalid .Antiforgery header cookie (valid dmdstats & X-XSRF-TOKEN)"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-714")})
    public void testPortalTitleSearchWithInvalidAntiforgeryCookie(){

        TitleSearchRequest requestBody = TitleSearchRequestFactory.createRequestWithKeyword(titleName);

        DmdcMarketingClient.postTitleSearchResults(requestBody)
                .xsrfAuthAndNoAntiforgeryContracts(marketingTvdHeUser)
                .antiforgery(TestUser.INVALID_ANTIFORGERY)
                .execute();
    }

    @Test(
            groups = {DmdcGroups.PORTAL_TITLE_SEARCH, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[/api/portal/title/search] " +
                    "Title search with empty .Antiforgery header cookie (valid dmdstats & X-XSRF-TOKEN)"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-717")})
    public void testPortalTitleSearchWithoutAntiforgeryCookie(){

        TitleSearchRequest requestBody = TitleSearchRequestFactory.createRequestWithKeyword(titleName);

        DmdcMarketingClient.postTitleSearchResults(requestBody)
                .xsrfAuthAndNoAntiforgeryContracts(marketingTvdHeUser)
                .execute();
    }
}
