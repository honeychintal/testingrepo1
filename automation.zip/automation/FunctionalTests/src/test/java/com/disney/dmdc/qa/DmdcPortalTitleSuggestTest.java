package com.disney.dmdc.qa;

import com.amazonaws.util.json.Jackson;
import com.disney.dmdc.qa.client.DmdcMarketingClient;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.factory.PortalTitleSuggestPostResponseFactory;
import com.disney.dmdc.qa.factory.PortalTitleSuggestRequestFactory;
import com.disney.dmdc.qa.model.PortalTitleSuggestPostResponse;
import com.disney.dmdc.qa.model.PortalTitleSuggestRequest;
import com.disney.dmdc.qa.request.MarketingDmdcRequest;
import com.disney.dmdc.qa.util.TestServicesConfig;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.dmdc.qa.util.data.TitleNameData;
import com.disney.dmdc.qa.util.data.TitlesData;
import com.disney.dmdc.qa.util.data.UsersData;
import com.disney.dmdc.qa.util.data.WprData;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.groups.TestGroups;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import java.sql.SQLException;

public class DmdcPortalTitleSuggestTest {
    private static final TestUserCache testUserCache = new TestUserCache();
    private static final TestUser marketingUser = testUserCache.getTestUserFromConfig(TestUserCache.MARKETING_TVD_HE_USER_KEY);
    private static final Logger log = LoggerFactory.getLogger(DmdcPortalTitleSuggestTest.class);
    boolean dbValidationFlag = TestServicesConfig.shouldCompareResponseToBackendDatabase();

    @Test(groups = { DmdcGroups.TITLE_SUGGEST, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Portal Title][/api/portal/title/suggest] " +
                    "Test title suggest with keyword value as valid title id ,hierarchytypeid as TVD Hierarchy and IncludeEpisodesFlag value as true")
    @TestDoc(externalIds = { @ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-145") })
    public void testPortalTitleSuggestPost() throws SQLException {

        String appGuidId = TitlesData.getTvdHeGuid();
        int userID = UsersData.getTvdHeId();
        //API response WprId is shown as TitleID in the UI
        String validTitleId = WprData.getWprID();

        PortalTitleSuggestRequest requestBody= PortalTitleSuggestRequestFactory.createEpisodesPortalTitleSuggestRequest(validTitleId,false);

        MarketingDmdcRequest request = DmdcMarketingClient.postPortalTitleSuggest(requestBody)
                .authenticationWithAntiforgery(marketingUser);

        if (dbValidationFlag) {
            String searchDataArg = Jackson.toJsonPrettyString(requestBody);
            log.info("As dbValidationFlag is true, generating expected response and adding body contract");
            PortalTitleSuggestPostResponse responseBody= PortalTitleSuggestPostResponseFactory.createDefaultPortalTitleSuggestPostResponse(
                    appGuidId, userID, searchDataArg);

            request.contract(
                    ContractBody.builder()
                            .jsonEquals(responseBody)
                            .build()
            );
        }

        log.info("Hitting the request and validating contracts");
        PortalTitleSuggestPostResponse postResponse = request
                .execute()
                .as(PortalTitleSuggestPostResponse.class);

    }

    @Test(groups = { DmdcGroups.TITLE_SUGGEST, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Portal Title][/api/portal/title/suggest] " +
                    " Test title suggest with keyword value as invalid title id ,hierarchytypeid as TVD Hierarchy ")
    @TestDoc(externalIds = { @ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-147") })
    public void testPortalTitleSuggestPostWithInvalidTitleId() throws SQLException {

        String appGuidId = TitlesData.getTvdHeGuid();
        int userID = UsersData.getTvdHeId();
        //API response WprId is shown as TitleID in the UI
        String inValidTitleId = WprData.getInvalidWprID();

        PortalTitleSuggestRequest requestBody = PortalTitleSuggestRequestFactory.createEpisodesPortalTitleSuggestRequest(inValidTitleId,false);

        MarketingDmdcRequest request = DmdcMarketingClient.postPortalTitleSuggest(requestBody)
                .authenticationWithAntiforgery(marketingUser);

        if (dbValidationFlag) {
            String searchDataArg = Jackson.toJsonPrettyString(requestBody);
            log.info("As dbValidationFlag is true, generating expected response and adding body contract");
            PortalTitleSuggestPostResponse responseBody= PortalTitleSuggestPostResponseFactory.createDefaultPortalTitleSuggestPostResponse(
                    appGuidId, userID, searchDataArg);

            request.contract(
                    ContractBody.builder()
                            .jsonEquals(responseBody)
                            .build()
            );
        }

        log.info("Hitting the request and validating contracts");
        PortalTitleSuggestPostResponse postResponse = request
                .execute()
                .as(PortalTitleSuggestPostResponse.class);
    }

    //This test is having issue with storedProc raised an issue and added needclarification label
    @Test(enabled = false, groups = { DmdcGroups.TITLE_SUGGEST, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Portal Title][/api/portal/title/suggest] Test title suggest with valid TitleName")
    @TestDoc(externalIds = { @ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-253") })
    public void testPortalTitleSuggestPostWithTitleName() throws SQLException {

        String appGuidId = TitlesData.getTvdHeGuid();
        int userID = UsersData.getTvdHeId();
        String titleName = TitleNameData.getTitleName();

        PortalTitleSuggestRequest requestBody = PortalTitleSuggestRequestFactory
                .createEpisodesPortalTitleSuggestRequest(titleName,true);

        MarketingDmdcRequest request = DmdcMarketingClient.postPortalTitleSuggest(requestBody)
                .authenticationWithAntiforgery(marketingUser);

        if (dbValidationFlag) {
            String searchDataArg = Jackson.toJsonPrettyString(requestBody);
            log.info("As dbValidationFlag is true, generating expected response and adding body contract");
            PortalTitleSuggestPostResponse responseBody= PortalTitleSuggestPostResponseFactory.createDefaultPortalTitleSuggestPostResponse(
                    appGuidId, userID, searchDataArg);

            request.contract(
                    ContractBody.builder()
                            .jsonEquals(responseBody)
                            .build()
            );
        }

        log.info("Hitting the request and validating contracts");
        PortalTitleSuggestPostResponse postResponse = request
                .execute()
                .as(PortalTitleSuggestPostResponse.class);
    }

    //This test is having issue with storedProc raised an issue and added needclarification label
    @Test(enabled = false, groups = { DmdcGroups.TITLE_SUGGEST, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Portal Title][/api/portal/title/suggest] " +
                    "Test title suggest with IncludeEpisodesFlag value as false")
    @TestDoc(externalIds = { @ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-254") })
    public void testPortalTitleSuggestPostWithIncludeEpisodesFlagValueAsFalse() throws SQLException {

        String appGuidId = TitlesData.getTvdHeGuid();
        int userID = UsersData.getTvdHeId();
        String titleName = TitleNameData.getTitleName();

        PortalTitleSuggestRequest requestBody= PortalTitleSuggestRequestFactory
                .createEpisodesPortalTitleSuggestRequest(titleName,false);

        MarketingDmdcRequest request = DmdcMarketingClient.postPortalTitleSuggest(requestBody)
                .authenticationWithAntiforgery(marketingUser);

        if (dbValidationFlag) {

            String searchDataArg = Jackson.toJsonPrettyString(requestBody);
            log.info("As dbValidationFlag is true, generating expected response and adding body contract");
            PortalTitleSuggestPostResponse responseBody= PortalTitleSuggestPostResponseFactory.createDefaultPortalTitleSuggestPostResponse(
                    appGuidId, userID, searchDataArg);

            request.contract(
                    ContractBody.builder()
                            .jsonEquals(responseBody)
                            .build()
            );
        }

        log.info("Hitting the request and validating contracts");
        PortalTitleSuggestPostResponse postResponse = request
                .execute()
                .as(PortalTitleSuggestPostResponse.class);
    }

    @Test(groups = { DmdcGroups.TITLE_SUGGEST, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Portal Title][/api/portal/title/suggest] Test title suggest with invalid Antiforgery cookie header")
    @TestDoc(externalIds = { @ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-611") })
    public void testPortalTitleSuggestPostWithInvalidAntiforgery() {

        String titleName = TitleNameData.getTitleName();

        PortalTitleSuggestRequest requestBody = PortalTitleSuggestRequestFactory.createEpisodesPortalTitleSuggestRequest(titleName,false);

        DmdcMarketingClient.postPortalTitleSuggest(requestBody)
                .xsrfAuthAndNoAntiforgeryContracts(marketingUser)
                .antiforgery(TestUser.INVALID_ANTIFORGERY)
                .execute();
    }

    @Test(groups = { DmdcGroups.TITLE_SUGGEST, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Portal Title][/api/portal/title/suggest] Admin title suggest without .Antiforgery cookie header")
    @TestDoc(externalIds = { @ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-608") })
    public void testPortalTitleSuggestPostWithOutAntiforgery() {

        String titleName = TitleNameData.getTitleName();

        PortalTitleSuggestRequest requestBody = PortalTitleSuggestRequestFactory.createEpisodesPortalTitleSuggestRequest(titleName,false);

        DmdcMarketingClient.postPortalTitleSuggest(requestBody)
                .xsrfAuthAndNoAntiforgeryContracts(marketingUser)
                .execute();
    }

    @Test(groups = { DmdcGroups.TITLE_SUGGEST, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Portal Title][/api/portal/title/suggest] Test title suggest without X-XSRF-TOKEN header")
    @TestDoc(externalIds = { @ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-566") })
    public void testPortalTitleSuggestPostWithOutXsrfHeader() {

        String titleName = TitleNameData.getTitleName();

        PortalTitleSuggestRequest requestBody = PortalTitleSuggestRequestFactory.createEpisodesPortalTitleSuggestRequest(titleName,false);

        DmdcMarketingClient.postPortalTitleSuggest(requestBody)
                .antiforgeryAuthAndNoXsrfContracts(marketingUser)
                .execute();
    }

    @Test(groups = { DmdcGroups.TITLE_SUGGEST, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Portal Title][/api/portal/title/suggest] Test title suggest with invalid X-XSRF-TOKEN header")
    @TestDoc(externalIds = { @ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-568") })
    public void testPortalTitleSuggestPostWithInvalidXsrfHeader() {

        String titleName = TitleNameData.getTitleName();

        PortalTitleSuggestRequest requestBody = PortalTitleSuggestRequestFactory.createEpisodesPortalTitleSuggestRequest(titleName,false);

        DmdcMarketingClient.postPortalTitleSuggest(requestBody)
                .antiforgeryAuthAndNoXsrfContracts(marketingUser)
                .xsrf(TestUser.INVALID_XSRF)
                .execute();
    }
}