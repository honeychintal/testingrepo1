package com.disney.dmdc.qa;

import com.disney.dmdc.qa.client.DmdcMarketingClient;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.constant.LocaleIds;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.factory.TitleQuickViewResponseFactory;
import com.disney.dmdc.qa.model.TitleQuickViewResponse;
import com.disney.dmdc.qa.request.MarketingDmdcRequest;
import com.disney.dmdc.qa.util.TestServicesConfig;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.dmdc.qa.util.data.TitlesData;
import com.disney.dmdc.qa.util.data.UsersData;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.groups.TestGroups;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

public class DmdcQuickViewTest {

    private static final TestUserCache testUserCache = new TestUserCache();
    private static final TestUser marketingTvdHeUser = testUserCache.getTestUserFromConfig(TestUserCache.MARKETING_TVD_HE_USER_KEY);
    private static final Logger log = LoggerFactory.getLogger(DmdcQuickViewTest.class);
    boolean dbValidationFlag = TestServicesConfig.shouldCompareResponseToBackendDatabase();

    @Test(
            groups = {DmdcGroups.TITLES, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleid>/quickview] Test Title Quickview"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-182")})
    public void testTitleQuickView() {

        String appTitleGuid = TitlesData.getTvdHeGuid();

        log.info("Creating request object with status, headers, json schema contracts");
        MarketingDmdcRequest titleQuickviewGetRequest = DmdcMarketingClient.getTitleQuickView(appTitleGuid)
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats());

        if (dbValidationFlag) {
            log.info("As dbValidationFlag is true, generating expected response and adding body contract");
            int userId = UsersData.getTvdHeId();

            TitleQuickViewResponse expectedResponse = TitleQuickViewResponseFactory
                    .createExpectedTitleQuickViewResponse(appTitleGuid, userId, LocaleIds.ENG_US);

            titleQuickviewGetRequest.contract(
                    ContractBody.builder()
                            .jsonEquals(expectedResponse)
                            .build()
            );
        }

        log.info("Hitting the request and validating contracts");
        titleQuickviewGetRequest
                .execute()
                .as(TitleQuickViewResponse.class);
    }

    @Test(
            groups = {DmdcGroups.TITLES, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleid>/quickview] Test Title Quickview without Header Cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-187")})
    public void testTitleQuickViewWithoutCookie() {

        String appTitleGuid = TitlesData.getTvdHeGuid();

        DmdcMarketingClient.getTitleQuickView(appTitleGuid)
                .dmdstatsContractsAndNoAuth()
                .execute();
    }

    @Test(
            groups = {DmdcGroups.TITLES, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleid>/quickview] " +
                    "Test Title Quickview with invalid header cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-1231")})
    public void testTitleQuickViewWithInvalidCookie() {

        String appTitleGuid = TitlesData.getTvdHeGuid();

        DmdcMarketingClient.getTitleQuickView(appTitleGuid)
                .invalidDmdStatsAuthAndContracts(TestUser.INVALID_DMDSTATS)
                .execute();
    }
}