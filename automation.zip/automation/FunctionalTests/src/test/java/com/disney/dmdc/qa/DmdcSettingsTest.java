package com.disney.dmdc.qa;

import com.disney.dmdc.qa.client.DmdcMarketingClient;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.data.TestSettingsData;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.model.SettingsResponse;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.groups.TestGroups;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

public class DmdcSettingsTest {

	private static final TestUserCache testUserCache = new TestUserCache();
	private static final TestUser marketingTvdHeUser = testUserCache
			.getTestUserFromConfig(TestUserCache.MARKETING_TVD_HE_USER_KEY);
	private static final TestUser adminUser = testUserCache
			.getTestUserFromConfig(TestUserCache.ADMIN_DMDC_API_AUTOMATION_USER_KEY);
	private static final Logger log = LoggerFactory.getLogger(DmdcSettingsTest.class);

	@Test(
			groups = {DmdcGroups.SETTINGS, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
			description = "[Settings] [/api/settings] " +
					"Test To get Dmdc Central Home page settings by providing admin user cookie"
	)
	@TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-1233")})
	public void testSettingsWithAdminUser() {

		SettingsResponse expectedResponse = TestSettingsData.getAdminSettingsData();

		log.info("Creating request object with status, headers, json schema contracts");
		DmdcMarketingClient.getSettings()
				.authenticationDmdStatsOnly(adminUser.getDmdstats())
				.contract(ContractBody.builder()
						.jsonEquals(expectedResponse)
						.build()
				)
				.execute()
				.as(SettingsResponse.class);
	}

	@Test(
			groups = {DmdcGroups.SETTINGS, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
			description = "[Settings] [/api/settings] Test To get the information about Dmdc Central Home page settings"
	)
	@TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-522")})
	public void testSettingsWithMarketingUser() {

		SettingsResponse expectedResponse = TestSettingsData.getMarketingSettingsData();

		log.info("Creating request object with status, headers, json schema contracts");
		DmdcMarketingClient.getSettings()
				.authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats())
				.contract(ContractBody.builder()
						.jsonEquals(expectedResponse)
						.build()
				)
				.execute()
				.as(SettingsResponse.class);
	}

	@Test(
			groups = {DmdcGroups.SETTINGS, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
			description = "[Settings] [/api/settings] To get Dmdc Central Home page settings without header cookie"
	)
	@TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-523")})
	public void testSettingsWithoutCookie(){

		DmdcMarketingClient.getSettings()
				.dmdstatsContractsAndNoAuth()
				.execute();
	}

	@Test(
			groups = {DmdcGroups.SETTINGS, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
			description = "[Settings] [/api/settings] To get Dmdc Central Home page settings without header cookie"
	)
	@TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-525")})
	public void testSettingsWithInvalidCookie(){

		DmdcMarketingClient.getSettings()
				.invalidDmdStatsAuthAndContracts(TestUser.INVALID_DMDSTATS)
				.execute();
	}
}