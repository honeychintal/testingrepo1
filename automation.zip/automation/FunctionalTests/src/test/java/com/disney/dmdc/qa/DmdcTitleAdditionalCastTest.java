package com.disney.dmdc.qa;

import com.disney.dmdc.qa.client.DmdcMarketingClient;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.constant.LocaleIds;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.factory.TitleAdditionalCastResponseFactory;
import com.disney.dmdc.qa.model.TitleAdditionalCastResponse;
import com.disney.dmdc.qa.request.MarketingDmdcRequest;
import com.disney.dmdc.qa.type.Locals;
import com.disney.dmdc.qa.util.TestServicesConfig;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.dmdc.qa.util.data.TitlesData;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.groups.TestGroups;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

public class DmdcTitleAdditionalCastTest {

    private static final TestUserCache testUserCache = new TestUserCache();
    private static final TestUser marketingTvdHeUser = testUserCache.getTestUserFromConfig
            (TestUserCache.MARKETING_TVD_HE_USER_KEY);
    private static final Logger log = LoggerFactory.getLogger(DmdcTitleAdditionalCastTest.class);
    boolean dbValidationFlag = TestServicesConfig.shouldCompareResponseToBackendDatabase();

    @Test(
            groups = {
                    DmdcGroups.TITLES,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleid>/additionalcast] Test title additional cast"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-143")})
    public void testTitleAdditionalCast() {

        log.info("Retrieve Title Additional cast details");
        String appTitleGuid = TitlesData.getTvdHeGuid();
        int localId = Locals.ENG_USA.getId();

        log.info("Creating request object with status, headers, json schema contracts");
        MarketingDmdcRequest additionalCastGetRequest = DmdcMarketingClient.getTitleAdditionalCast(
                appTitleGuid,
                localId
        )
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats());

        if (dbValidationFlag){
            log.info("Generating expected response from DB and adding body contract");
            TitleAdditionalCastResponse expectedResponse = TitleAdditionalCastResponseFactory
                    .createExpectedAdditionalCastResponse(appTitleGuid, localId, "cast");

            additionalCastGetRequest.contract(
                    ContractBody.builder()
                    .jsonEquals(expectedResponse)
                    .build()
            );
        }
        additionalCastGetRequest
                .execute()
                .as(TitleAdditionalCastResponse.class);
    }

    @Test(
            groups = {
                    DmdcGroups.TITLES,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleid>/additionalcast] Test title additional cast without cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-171")})
    public void testTitleAdditionalCastwithoutCookie() {

        log.info("Retrieve Title Additional cast details");
        String appTitleGuid = TitlesData.getTvdHeGuid();

        log.info("Get 401 when dmdstats cookie is not provided");
        DmdcMarketingClient.getTitleAdditionalCast(
                appTitleGuid,
                LocaleIds.ENG_US
        )
                .dmdstatsContractsAndNoAuth()
                .execute();
    }

    @Test(
            groups = {
                    DmdcGroups.TITLES,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleid>/additionalcast] Test title additional cast with Invalid Header cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-280")})
    public void testTitleAdditionalCastwithInvlaidHeaderCookie() {

        log.info("Retrieve Title Additional cast details");
        String appTitleGuid = TitlesData.getTvdHeGuid();

        log.info("Get 401 when invalid dmdstats cookie is provided");
        DmdcMarketingClient.getTitleAdditionalCast(
                appTitleGuid,
                LocaleIds.ENG_US
        )
                .invalidDmdStatsAuthAndContracts(TestUser.INVALID_DMDSTATS)
                .execute();
    }

    @Test(
            groups = {
                    DmdcGroups.TITLES,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleid>/additionalcast] Test title additional cast details with TitleId associated with only TVD"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-528")})
    public void testTitleAdditionalCast_TVD_User() {

        log.info("Retrieve Title Additional cast details for only TVD user");
        String appTitleGuid = TitlesData.getAdditionalcastTvd();
        int localId = Locals.ENG_USA.getId();

        log.info("Creating request object with status, headers, json schema contracts");
        MarketingDmdcRequest additionalCastGetRequest = DmdcMarketingClient.getTitleAdditionalCast(
                appTitleGuid,
                LocaleIds.ENG_US
        )
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats());

        if (dbValidationFlag) {
            log.info("Generating expected response from DB and adding body contract");
            TitleAdditionalCastResponse expectedResponse = TitleAdditionalCastResponseFactory
                    .createExpectedAdditionalCastResponse(appTitleGuid, localId, "cast");

            additionalCastGetRequest.contract(
                    ContractBody.builder()
                            .jsonEquals(expectedResponse)
                            .build()
            );
        }
        additionalCastGetRequest
                .execute()
                .as(TitleAdditionalCastResponse.class);
    }

    @Test(
            groups = {
                    DmdcGroups.TITLES,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleid>/additionalcast] Test title additional cast details with TitleId associated with only HE"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-527")})
    public void testTitleAdditionalCast_HE_User() {

        log.info("Retrieve Title Additional cast details for only HE user");
        String appTitleGuid = TitlesData.getAdditionalcastHe();
        int localId = Locals.ENG_USA.getId();

        log.info("Creating request object with status, headers, json schema contracts");
        MarketingDmdcRequest additionalCastGetRequest = DmdcMarketingClient.getTitleAdditionalCast(
                appTitleGuid,
                LocaleIds.ENG_US
        )
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats());

        if (dbValidationFlag) {
            log.info("Generating expected response from DB and adding body contract");
            TitleAdditionalCastResponse expectedResponse = TitleAdditionalCastResponseFactory
                    .createExpectedAdditionalCastResponse(appTitleGuid, localId, "cast");

            additionalCastGetRequest.contract(
                    ContractBody.builder()
                            .jsonEquals(expectedResponse)
                            .build()
            );
        }
        additionalCastGetRequest
                .execute()
                .as(TitleAdditionalCastResponse.class);
    }
}