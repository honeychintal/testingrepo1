package com.disney.dmdc.qa;

import com.disney.dmdc.qa.client.DmdcMarketingClient;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.factory.TitleAdditionalCastResponseFactoryMahender;
import com.disney.dmdc.qa.model.TitleAdditionalCastResponseMahender;
import com.disney.dmdc.qa.request.MarketingDmdcRequest;
import com.disney.dmdc.qa.type.Locals;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.dmdc.qa.util.data.TitlesData;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.groups.TestGroups;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

public class DmdcTitleAdditionalCastTestMahender {

    private static final TestUserCache testUserCache = new TestUserCache();
    private static final TestUser marketingTvdHeUser = testUserCache.getTestUserFromConfig
            (TestUserCache.MARKETING_TVD_HE_USER_KEY);

    private static final Logger log = LoggerFactory.getLogger(DmdcTitleAdditionalCastTest.class);
    @Test(
            groups = {
                    DmdcGroups.TITLES,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleid>/additionalcast] Test title additional cast"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-141")})
    public void testTitleAdditionalCast() {
        log.info("Retrieve Title Additional cast details");
        String appTitleGuid = TitlesData.getTvdHeGuid();
        int localId = Locals.ENG_USA.getId();

        log.info("Creating request object with status, headers, json schema contracts");
        MarketingDmdcRequest additionalCastGetRequest = DmdcMarketingClient.getTitleAdditionalCast(
                        appTitleGuid,
                        localId
                )
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats());

        log.info("Generating expected response from Fixed values and adding body contract");
        TitleAdditionalCastResponseMahender expectedResponse = TitleAdditionalCastResponseFactoryMahender
                    .createExpectedAdditionalCastResponse();

            //comparing actual and expected Response data
            additionalCastGetRequest.contract(
                    ContractBody.builder()
                            .jsonEquals(expectedResponse)
                            .build())
                            .execute()  //execute returning with respect to modal class
                            .as(TitleAdditionalCastResponseMahender.class);
    }
    //Testing using withoutCookie
    @Test(
            groups = {
                    DmdcGroups.TITLES,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleid>/additionalcast] Test title additional cast"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-142")})
    public void testTitleAdditionalCastWithoutCookie() {
        String appTitleGuid = TitlesData.getTvdHeGuid();
        int localId = Locals.ENG_USA.getId();

        log.info("Generating expected response status code is 401,when cookie is not Given");
        DmdcMarketingClient.getTitleAdditionalCast(appTitleGuid,localId)
                .dmdstatsContractsAndNoAuth()
                .execute();
    }
    //Testing using with invalid Cookie
    @Test(
            groups = {
                    DmdcGroups.TITLES,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleid>/additionalcast] Test title additional cast"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-142")})
    public void testTitleAdditionalCastWithInvalidCookie() {
        String appTitleGuid = TitlesData.getTvdHeGuid();
        int localId = Locals.ENG_USA.getId();

        log.info("Generating expected response status code is 401,when cookie is invalid Given");
        DmdcMarketingClient.getTitleAdditionalCast(appTitleGuid,localId)
                .invalidDmdStatsAuthAndContracts(TestUser.INVALID_DMDSTATS)
                .execute();
    }



}
