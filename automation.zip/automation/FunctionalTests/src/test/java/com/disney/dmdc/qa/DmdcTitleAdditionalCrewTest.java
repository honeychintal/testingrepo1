package com.disney.dmdc.qa;

import com.disney.dmdc.qa.client.DmdcMarketingClient;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.constant.LocaleIds;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.factory.TitleAdditionalCrewResponseFactory;
import com.disney.dmdc.qa.model.TitleAdditionalCrewResponse;
import com.disney.dmdc.qa.request.MarketingDmdcRequest;
import com.disney.dmdc.qa.type.Locals;
import com.disney.dmdc.qa.util.TestServicesConfig;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.dmdc.qa.util.data.TitlesData;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.groups.TestGroups;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

public class DmdcTitleAdditionalCrewTest {

    private static final TestUserCache testUserCache = new TestUserCache();
    private static final TestUser marketingTvdHeUser = testUserCache
            .getTestUserFromConfig(TestUserCache.MARKETING_TVD_HE_USER_KEY);
    private static final Logger log = LoggerFactory.getLogger(DmdcTitleAdditionalCrewTest.class);
    boolean dbValidationFlag = TestServicesConfig.shouldCompareResponseToBackendDatabase();

    @Test(groups = { DmdcGroups.TITLES, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P2},
            description = "[Title][/api/portal/title/<title id>/additionalcrew] " +
                    "Test title Additionalcrew for title associated with DU-1 and DU-2 and with available localId param set to true "
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-272")})
    public void testTitleAdditionalCrew() {

        log.info("Retrieve Title Additional crew details");
        String appTitleGuid = TitlesData.getTvdHeGuid();
        int localId = Locals.ENG_USA.getId();

        log.info("Creating request object with status, headers, json schema contracts");
        MarketingDmdcRequest additionalCrewGetRequest = DmdcMarketingClient.getTitleAdditionalCrew(
                appTitleGuid,
                LocaleIds.ENG_US)
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats());

        if (dbValidationFlag) {
            log.info("Generating expected response from DB and adding body contract");
            TitleAdditionalCrewResponse expectedResponse = TitleAdditionalCrewResponseFactory
                    .createDefaultAdditionalCrewResponse(appTitleGuid, localId, "crew");
            additionalCrewGetRequest.contract(
                    ContractBody.builder()
                            .jsonEquals(expectedResponse)
                            .build()
            );
        }
        additionalCrewGetRequest.execute()
                .as(TitleAdditionalCrewResponse.class);
    }

    @Test(
            groups = { DmdcGroups.TITLES, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Title][/api/portal/title/<title id>/additionalcrew] " +
                    "Test title Additionalcrew for title associated with DU-1 and DU-2 and with available localId param set to true with out dmdstats header cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-270")})
    public void testTitleAdditionalCrewWithoutCookie() {

        log.info("Retrieve Title Additional crew details with out cookie");
        String appTitleGuid = TitlesData.getTvdHeGuid();

        log.info("Get 401 when dmdstats cookie is not provided");
        DmdcMarketingClient.getTitleAdditionalCrew(
                appTitleGuid,
                LocaleIds.ENG_US
        )
                .dmdstatsContractsAndNoAuth()
                .execute();
    }

    @Test(
            groups = { DmdcGroups.TITLES, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Title][/api/portal/title/<title id>/additionalcrew] " +
                    "Test title Additionalcrew for title associated with DU-1 and DU-2 and with available localId param set to true with invalid dmdstats header cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-344")})
    public void testTitleAdditionalCrewWithInvlaidHeaderCookie() {

        log.info("Retrieve Title Additional crew details with InvalidHeader cookie");
        String appTitleGuid = TitlesData.getTvdHeGuid();

        log.info("Get 401 when dmdstats cookie is not provided");
        DmdcMarketingClient.getTitleAdditionalCrew(
                appTitleGuid,
                LocaleIds.ENG_US
        )
                .invalidDmdStatsAuthAndContracts(TestUser.INVALID_DMDSTATS)
                .execute();
    }
}
