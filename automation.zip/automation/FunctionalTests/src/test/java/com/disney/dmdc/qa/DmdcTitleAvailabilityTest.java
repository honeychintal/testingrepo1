package com.disney.dmdc.qa;

import com.disney.dmdc.qa.client.DmdcAdminClient;
import com.disney.dmdc.qa.constant.DistributionUnitIds;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.constant.LocaleIds;
import com.disney.dmdc.qa.constant.ProductTypeIds;
import com.disney.dmdc.qa.data.SampleTitleAvailabilityRequest;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.factory.TitleAvailabilityResponseFactory;
import com.disney.dmdc.qa.model.TitleAvailabilityDataElement;
import com.disney.dmdc.qa.model.TitleAvailabilityGetResponse;
import com.disney.dmdc.qa.model.TitleAvailabilityPostResponse;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.groups.TestGroups;
import com.google.common.collect.ImmutableList;
import org.testng.annotations.Test;

public class DmdcTitleAvailabilityTest {

	private static final TestUserCache testUserCache = new TestUserCache();
	private static final TestUser adminUser = testUserCache.getTestUserFromConfig(TestUserCache.ADMIN_DMDC_API_AUTOMATION_USER_KEY);

	@Test(groups = { DmdcGroups.TITLES, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1})
	@TestDoc(externalIds = { @ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-277") })
	public void testTitleAvailabilityPost() {

		TitleAvailabilityDataElement testTitle = SampleTitleAvailabilityRequest.TEST1.getValue();

		//Get availability
		TitleAvailabilityGetResponse titleAvailabilityGetResponse = DmdcAdminClient.getTitleAvailability(
				testTitle.getApplicationTitleGuid(),
				DistributionUnitIds.TELEVISION_DISTRIBUTION,
				LocaleIds.ENG_US,
				ProductTypeIds.FEATURE
		)
				.authenticationDmdStatsOnly(adminUser.getDmdstats())
				.execute()
				.as(TitleAvailabilityGetResponse.class);

		TitleAvailabilityPostResponse expectedResponse = TitleAvailabilityResponseFactory.CreateSuccessTitleAvailabilityResponse();

		//Post availability (default reset)
		DmdcAdminClient.postTitleAvailability(DistributionUnitIds.TELEVISION_DISTRIBUTION, ImmutableList.of(testTitle))
				.authenticationWithAntiforgery(adminUser)
				.contract(
						ContractBody.builder()
								.jsonEquals(expectedResponse)
								.build()
				)
				.execute();
	}
}
