package com.disney.dmdc.qa;

import com.disney.dmdc.qa.client.DmdcMarketingClient;
import com.disney.dmdc.qa.constant.DistributionUnitIds;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.constant.LocaleIds;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.factory.TitleHeaderResponseFactory;
import com.disney.dmdc.qa.model.TitleHeaderResponse;
import com.disney.dmdc.qa.request.MarketingDmdcRequest;
import com.disney.dmdc.qa.util.TestServicesConfig;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.dmdc.qa.util.data.DistributionUnitData;
import com.disney.dmdc.qa.util.data.TitlesData;
import com.disney.dmdc.qa.util.data.UsersData;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.groups.TestGroups;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

public class DmdcTitleHeaderTest {

    private static final TestUserCache testUserCache = new TestUserCache();
    private static final TestUser marketingTvdHeUser = testUserCache.getTestUserFromConfig(TestUserCache.MARKETING_TVD_HE_USER_KEY);
    private static final Logger log = LoggerFactory.getLogger(DmdcTitleHeaderTest.class);
    boolean dbValidationFlag = TestServicesConfig.shouldCompareResponseToBackendDatabase();

    @Test(
            groups = {DmdcGroups.TITLES, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleid>/header] " +
                    "Test Title Header with the localId which is associated with distributionUnitId 1"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-206")})
    public void testTitleHeaderWithTVD() {

        log.info("Retrieve Title details when title is associated with both DU 1 (TVD) and DU 2 (HE) and passing DU 1 as query param");
        String appTitleGuid = TitlesData.getTvdHeGuid();

        log.info("Creating request object with status, headers, json schema contracts");
        MarketingDmdcRequest titleHeaderGetRequest = DmdcMarketingClient.getTitleHeader(
                appTitleGuid,
                DistributionUnitIds.TELEVISION_DISTRIBUTION,
                LocaleIds.ENG_US
        )
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats());

        if (dbValidationFlag) {
            int userId = UsersData.getTvdHeId();
            int distId = DistributionUnitData.getTvd();

            log.info("As dbValidationFlag is true, generating expected response and adding body contract");
            TitleHeaderResponse expectedResponse = TitleHeaderResponseFactory
                    .createExpectedTitleHeaderResponse(appTitleGuid, userId, distId, LocaleIds.ENG_US);

            titleHeaderGetRequest.contract(
                    ContractBody.builder()
                            .jsonEquals(expectedResponse)
                            .build());
        }

        log.info("Hitting the request and validating contracts");
        TitleHeaderResponse titleHeaderResponse = titleHeaderGetRequest
                .execute()
                .as(TitleHeaderResponse.class);

    }

    @Test(
            groups = {DmdcGroups.TITLES, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleid>/header] " +
                    "Test Title Header with the localId which is associated with distributionUnitId 2"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-213")})
    public void testTitleHeaderWithHE() {

        log.info("Retrieve Title details when title is associated with both DU 1 (TVD) and DU 2 (HE) and passing DU 2 as query param");
        String appTitleGuid = TitlesData.getTvdHeGuid();

        log.info("Creating request object with status, headers, json schema contracts");
        MarketingDmdcRequest titleHeaderGetRequest = DmdcMarketingClient.getTitleHeader(
                appTitleGuid,
                DistributionUnitIds.HOME_ENTERTAINMENT,
                LocaleIds.ENG_US
        )
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats());

        if (dbValidationFlag) {
            int userId = UsersData.getTvdHeId();
            int distId = DistributionUnitData.getHe();

            log.info("As dbValidationFlag is true, generating expected response and adding body contract");
            TitleHeaderResponse expectedResponse = TitleHeaderResponseFactory
                    .createExpectedTitleHeaderResponse(appTitleGuid, userId, distId, LocaleIds.ENG_US);

            titleHeaderGetRequest.contract(
                    ContractBody.builder()
                            .jsonEquals(expectedResponse)
                            .build());
        }

        log.info("Hitting the request and validating contracts");
        TitleHeaderResponse titleHeaderResponse = titleHeaderGetRequest
                .execute()
                .as(TitleHeaderResponse.class);

    }

    @Test(
            groups = {DmdcGroups.TITLES, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleid>/header] Test Title Header without header cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-149")})
    public void testTitleHeaderWithoutCookie() {

        String appTitleGuid = TitlesData.getTvdHeGuid();;

        DmdcMarketingClient.getTitleHeader(
                appTitleGuid,
                DistributionUnitIds.TELEVISION_DISTRIBUTION,
                LocaleIds.ENG_US
        )
                .dmdstatsContractsAndNoAuth()
                .execute();

    }

    @Test(
            groups = {DmdcGroups.TITLES, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleid>/header] Test Title Header with invalid header cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-286")})
    public void testTitleHeaderWithInvalidCookie() {

        String appTitleGuid = TitlesData.getTvdHeGuid();;

        DmdcMarketingClient.getTitleHeader(
                appTitleGuid,
                DistributionUnitIds.TELEVISION_DISTRIBUTION,
                LocaleIds.ENG_US
        )
                .invalidDmdStatsAuthAndContracts(TestUser.INVALID_DMDSTATS)
                .execute();

    }
}
