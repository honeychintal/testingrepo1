package com.disney.dmdc.qa;

import com.disney.dmdc.qa.client.DmdcMarketingClient;
import com.disney.dmdc.qa.constant.DistributionUnitIds;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.factory.TitleIdHierarchyResponseFactory;
import com.disney.dmdc.qa.factory.TitleIdHierarchyResultFactory;
import com.disney.dmdc.qa.model.TitleIdHierarchyResponse;
import com.disney.dmdc.qa.model.TitleIdHierarchyResult;
import com.disney.dmdc.qa.request.MarketingDmdcRequest;
import com.disney.dmdc.qa.util.TestServicesConfig;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.dmdc.qa.util.data.DistributionUnitData;
import com.disney.dmdc.qa.util.data.TitlesData;
import com.disney.dmdc.qa.util.data.UsersData;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.contract.ContractJsonSchema;
import com.disney.qa.groups.TestGroups;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

public class DmdcTitleIdHierarchyTest {

    private static final TestUserCache testUserCache = new TestUserCache();
    private static final TestUser marketingTvdHeUser = testUserCache.getTestUserFromConfig(TestUserCache.MARKETING_TVD_HE_USER_KEY);
    private static final Logger log = LoggerFactory.getLogger(DmdcTitleIdHierarchyTest.class);
    boolean dbValidationFlag = TestServicesConfig.shouldCompareResponseToBackendDatabase();

    @Test(
            groups = {DmdcGroups.TITLES, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleid>/Hierarchy] Test title Hierarchy Details " +
                    "with distributionUnitId value as 1"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-548")})
    public void testTitleIdHierarchyWithTVD() {

        String appTitleGuid = TitlesData.getSeasonTitleGuid();
        int userId = UsersData.getTvdHeId();
        int distId = DistributionUnitData.getTvd();

        MarketingDmdcRequest titleHierarchyRequest = DmdcMarketingClient
                .getTitleHierarchy(appTitleGuid, distId)
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats());
        if (dbValidationFlag) {
            log.info("As dbValidationFlag is true, generating expected response.");
            TitleIdHierarchyResult testTitleIdHierarchyResult = TitleIdHierarchyResultFactory
                    .createTitleHierarchyResult(appTitleGuid, userId, distId);
            TitleIdHierarchyResponse expectedResponse = TitleIdHierarchyResponseFactory
                    .createDefaultTitleHierarchyResponse(testTitleIdHierarchyResult);
            titleHierarchyRequest.contract(
                    ContractBody.builder()
                            .jsonEquals(expectedResponse)
                            .build()
            );
        }
        titleHierarchyRequest.execute()
                .as(TitleIdHierarchyResponse.class);
    }

    @Test(
            groups = {DmdcGroups.TITLES, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleid>/Hierarchy] Test title Hierarchy Details " +
                    "with distributionUnitId value as 2"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-550")})
    public void testTitleIdHierarchyWithHE() {

        String appTitleGuid = TitlesData.getSeasonTitleGuid();
        int userId = UsersData.getTvdHeId();
        int distId = DistributionUnitData.getHe();

        MarketingDmdcRequest titleHierarchyRequest = DmdcMarketingClient
                .getTitleHierarchy(appTitleGuid, distId)
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats());
        if (dbValidationFlag) {
            log.info("As dbValidationFlag is true, generating expected response.");
            TitleIdHierarchyResult testTitleIdHierarchyResult = TitleIdHierarchyResultFactory
                    .createTitleHierarchyResult(appTitleGuid, userId, distId);
            TitleIdHierarchyResponse expectedResponse = TitleIdHierarchyResponseFactory
                    .createDefaultTitleHierarchyResponse(testTitleIdHierarchyResult);
            titleHierarchyRequest.contract(
                    ContractBody.builder()
                            .jsonEquals(expectedResponse)
                            .build()
            );
        }
        titleHierarchyRequest.execute()
                .as(TitleIdHierarchyResponse.class);
    }

    @Test(
            groups = {DmdcGroups.TITLES, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleid>/hierarchy] Test title hierarchy Details " +
                    "with invalid header cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-553")})
    public void testTitleIdHierarchyInvalidCookie() {

        String appTitleGuid = TitlesData.getSeasonTitleGuid();
        DmdcMarketingClient.getTitleHierarchy(appTitleGuid, DistributionUnitIds.TELEVISION_DISTRIBUTION)
                .invalidDmdStatsAuthAndContracts(TestUser.INVALID_DMDSTATS)
                .execute();
    }

    @Test(
            groups = {DmdcGroups.TITLES, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleid>/hierarchy] Test title hierarchy Details " +
                    "without cookie in header"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-554")})
    public void testTitleIdHierarchyWithoutCookie() {

        String appTitleGuid = TitlesData.getSeasonTitleGuid();
        DmdcMarketingClient.getTitleHierarchy(appTitleGuid, DistributionUnitIds.TELEVISION_DISTRIBUTION)
                .dmdstatsContractsAndNoAuth()
                .execute();
    }

    @Test(
            groups = {DmdcGroups.TITLES, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleid>/hierarchy] Test title hierarchy Details " +
                    "with invalid distributionUnitId"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-557")})
    public void testTitleIdHierarchyWithInvalidDU() {

        String appTitleGuid = TitlesData.getSeasonTitleGuid();
        int userId = UsersData.getTvdHeId();
        int distId = DistributionUnitData.getDif();

        MarketingDmdcRequest titleHierarchyRequest = DmdcMarketingClient
                .getTitleHierarchy(appTitleGuid, distId)
                .removeContract(ContractJsonSchema.class)
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats());
        if (dbValidationFlag) {
            log.info("As dbValidationFlag is true, generating expected response.");
            TitleIdHierarchyResult testTitleIdHierarchyResult = TitleIdHierarchyResultFactory
                    .createTitleHierarchyResult(appTitleGuid, userId, distId);
            TitleIdHierarchyResponse expectedResponse = TitleIdHierarchyResponseFactory
                    .createDefaultTitleHierarchyResponse(testTitleIdHierarchyResult);
            titleHierarchyRequest.contract(
                    ContractBody.builder()
                            .jsonEquals(expectedResponse)
                            .build()
            );
        }
        titleHierarchyRequest.execute()
                .as(TitleIdHierarchyResponse.class);
    }

}