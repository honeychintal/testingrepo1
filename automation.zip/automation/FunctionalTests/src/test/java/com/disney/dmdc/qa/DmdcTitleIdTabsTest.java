package com.disney.dmdc.qa;

import com.disney.dmdc.qa.client.DmdcMarketingClient;
import com.disney.dmdc.qa.constant.DistributionUnitIds;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.factory.TitleIdTabsItemsFactory;
import com.disney.dmdc.qa.factory.TitleIdTabsResponseFactory;
import com.disney.dmdc.qa.model.TitleIdTabsItems;
import com.disney.dmdc.qa.model.TitleIdTabsResponse;
import com.disney.dmdc.qa.request.MarketingDmdcRequest;
import com.disney.dmdc.qa.util.TestServicesConfig;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.dmdc.qa.util.data.DistributionUnitData;
import com.disney.dmdc.qa.util.data.TitleSearchModeData;
import com.disney.dmdc.qa.util.data.TitlesData;
import com.disney.dmdc.qa.util.data.UsersData;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.groups.TestGroups;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import java.util.List;

public class DmdcTitleIdTabsTest {

    private static final TestUserCache testUserCache = new TestUserCache();
    private static final TestUser marketingTvdHeUser = testUserCache.getTestUserFromConfig(TestUserCache.MARKETING_TVD_HE_USER_KEY);
    private static final Logger log = LoggerFactory.getLogger(DmdcTitleIdTabsTest.class);
    boolean dbValidationFlag = TestServicesConfig.shouldCompareResponseToBackendDatabase();

    @Test(
            groups = {DmdcGroups.TITLES, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Title][api/portal/title/<titleId>/tabs] Test title tab Details"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-402")})
    public void testTitleIdTabDetails() {

        String appTitleGuid = TitlesData.getTvdHeGuid();
        int userId = UsersData.getTvdHeId();
        int distId = DistributionUnitData.getTvd();
        String searchMode = TitleSearchModeData.getProductPage();

        MarketingDmdcRequest request = DmdcMarketingClient.getTitleTabs(
                appTitleGuid,
                appTitleGuid,
                distId
        )
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats());

        if (dbValidationFlag) {
            log.info("As dbValidationFlag is true, generating expected response.");
            List<TitleIdTabsItems> titleIdTabsItems = TitleIdTabsItemsFactory
                    .createTitleIdTabsItems(userId, distId, appTitleGuid, searchMode);
            TitleIdTabsResponse expectedResponse = TitleIdTabsResponseFactory
                    .createDefaultTitleIdTabsResponse(titleIdTabsItems);
            request.contract(
                    ContractBody.builder()
                            .jsonEquals(expectedResponse)
                            .build()
            );
        }
        request.execute()
                .as(TitleIdTabsResponse.class);
    }

    @Test(
            groups = {DmdcGroups.TITLES, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleId>/tabs]Test Title Tab details " +
                    "by taking a title having only few tabs"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-422")})
    public void testFewTabsTitleIdTabDetails() {

        String appTitleGuid = TitlesData.getFewTabsTitleGuid();
        int userId = UsersData.getTvdHeId();
        int distId = DistributionUnitData.getTvd();
        String searchMode = TitleSearchModeData.getProductPage();

        MarketingDmdcRequest request = DmdcMarketingClient.getTitleTabs(
                appTitleGuid,
                appTitleGuid,
                distId
        )
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats());

        if (dbValidationFlag) {
            log.info("As dbValidationFlag is true, generating expected response.");
            List<TitleIdTabsItems> titleIdTabsItems = TitleIdTabsItemsFactory
                    .createTitleIdTabsItems(userId, distId, appTitleGuid, searchMode);
            TitleIdTabsResponse expectedResponse = TitleIdTabsResponseFactory
                    .createDefaultTitleIdTabsResponse(titleIdTabsItems);
            request.contract(
                    ContractBody.builder()
                            .jsonEquals(expectedResponse)
                            .build()
            );
        }
        request.execute()
                .as(TitleIdTabsResponse.class);
    }

    @Test(
            groups = {DmdcGroups.TITLES, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleId>/tabs]Test Title Tab Details by " +
                    "providing seasons titleId"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-415")})
    public void testSeasonsTitleIdTabDetails() {

        String appTitleGuid = TitlesData.getSeasonTitleGuid();
        int userId = UsersData.getTvdHeId();
        int distId = DistributionUnitData.getTvd();
        String searchMode = TitleSearchModeData.getProductPage();

        MarketingDmdcRequest request = DmdcMarketingClient.getTitleTabs(
                appTitleGuid,
                appTitleGuid,
                distId
        )
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats());

        if (dbValidationFlag) {
            log.info("As dbValidationFlag is true, generating expected response.");
            List<TitleIdTabsItems> titleIdTabsItems = TitleIdTabsItemsFactory
                    .createTitleIdTabsItems(userId, distId, appTitleGuid, searchMode);
            TitleIdTabsResponse expectedResponse = TitleIdTabsResponseFactory
                    .createDefaultTitleIdTabsResponse(titleIdTabsItems);
            request.contract(
                    ContractBody.builder()
                            .jsonEquals(expectedResponse)
                            .build()
            );
        }
        request.execute()
                .as(TitleIdTabsResponse.class);
    }

    @Test(
            groups = {DmdcGroups.TITLES, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleId>/tabs]Test Title Tab without header cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-405")})
    public void testTitleIdTabsWithoutCookie() {

        String titleId = TitlesData.getTvdHeGuid();

        DmdcMarketingClient.getTitleTabs(
                titleId,
                titleId,
                DistributionUnitIds.TELEVISION_DISTRIBUTION
        )
                .dmdstatsContractsAndNoAuth()
                .execute();
    }

    @Test(
            groups = {DmdcGroups.TITLES, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Title][/api/portal/title/<title id>/tabs]Test Title Tab without dmdstats cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-406")})
    public void testTitleIdTabsEmptyCookie() {

        String titleId = TitlesData.getTvdHeGuid();

        DmdcMarketingClient.getTitleTabs(
                titleId,
                titleId,
                DistributionUnitIds.TELEVISION_DISTRIBUTION
        )
                .invalidDmdStatsAuthAndContracts(TestUser.EMPTY_DMDSTATS)
                .execute();
    }

}
