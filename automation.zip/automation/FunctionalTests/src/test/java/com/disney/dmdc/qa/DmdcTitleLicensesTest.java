package com.disney.dmdc.qa;

import com.disney.dmdc.qa.client.DmdcMarketingClient;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.data.TestTitleData;
import com.disney.dmdc.qa.data.TestTitles;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.factory.TitleLicenseResponseFactory;
import com.disney.dmdc.qa.model.TitleLicenseGetResponse;
import com.disney.dmdc.qa.request.MarketingDmdcRequest;
import com.disney.dmdc.qa.util.TestServicesConfig;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.dmdc.qa.util.data.DistributionUnitData;
import com.disney.dmdc.qa.util.data.TitlesData;
import com.disney.dmdc.qa.util.data.UsersData;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.groups.TestGroups;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

public class DmdcTitleLicensesTest {

    private static final Logger log = LoggerFactory.getLogger(DmdcTitleLicensesTest.class);

    private static final TestUserCache testUserCache = new TestUserCache();
    private static final TestUser marketingTvdHeUser = testUserCache.getTestUserFromConfig(TestUserCache.MARKETING_TVD_HE_USER_KEY);
    private static final TestUser marketingHeUser = testUserCache.getTestUserFromConfig(TestUserCache.MARKETING_HE_USER_KEY);
    private static final TestUser marketingTvdUser = testUserCache.getTestUserFromConfig(TestUserCache.MARKETING_TVD_USER_KEY);

    boolean dbValidationFlag = TestServicesConfig.shouldCompareResponseToBackendDatabase();

    @Test(
            groups = {
                    DmdcGroups.TITLES,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleId>/licenses] Test Title License Details with " +
                    "User and titleId which has both distributionUnitIds 1 and 2"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-643")})
    public void testLicenseForTvdHeUserWithTvdHeTitle() {

        log.info("Retrieve Title details when title is associated with DU 1 (TVD) and 2 (HE)");
        String appTitleGuid = TitlesData.getTvdHeGuid();

        log.info("Retrieve User details who is associated with DU 1 (TVD) and 2 (HE)");
        int userId = UsersData.getTvdHeId();

        int distId = DistributionUnitData.getTvd();

        log.info(String.format("Creating request object with status, headers, json schema contracts of " +
                        "title GUID %s for user %s", appTitleGuid, userId));
        MarketingDmdcRequest titleLicenseGetRequest = DmdcMarketingClient
                .getTitleLicenses(appTitleGuid)
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats());

        if (dbValidationFlag) {
            log.info("As dbValidationFlag is true, generating expected response and adding body contract");
            TitleLicenseGetResponse expectedResponse = TitleLicenseResponseFactory
                    .createLicenseResponse(userId, distId, appTitleGuid);

            titleLicenseGetRequest.contract(
                    ContractBody.builder()
                            .jsonEquals(expectedResponse)
                            .build()
            );
        }

        log.info("Hitting the request and validating contracts");
        titleLicenseGetRequest
                .execute()
                .as(TitleLicenseGetResponse.class);
    }

    @Test(
            groups = {
                    DmdcGroups.TITLES,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleId>/licenses] Test Title License Details with User " +
                    "Having Access to DU1 and TitleId Associated with DU1 and DU2"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-647")})
    public void testLicensesForTvdUserWithTvdHeTitle() {

        log.info("Retrieve Title details when title is associated with DU 1 (TVD) and 2 (HE)");
        String appTitleGuid = TitlesData.getTvdHeGuid();

        log.info("Retrieve User details who is associated with DU 1 (TVD)");
        int userId = UsersData.getTvdId();

        int distId = DistributionUnitData.getTvd();

        log.info(String.format("Creating request object with status, headers, json schema contracts of " +
                "title GUID %s for user %s", appTitleGuid, userId));
        MarketingDmdcRequest titleLicenseGetRequest = DmdcMarketingClient
                .getTitleLicenses(appTitleGuid)
                .authenticationDmdStatsOnly(marketingTvdUser.getDmdstats());

        if (dbValidationFlag) {
            log.info("As dbValidationFlag is true, generating expected response and adding body contract");
            TitleLicenseGetResponse expectedResponse = TitleLicenseResponseFactory
                    .createLicenseResponse(userId, distId, appTitleGuid);

            titleLicenseGetRequest.contract(
                    ContractBody.builder()
                            .jsonEquals(expectedResponse)
                            .build()
            );
        }

        log.info("Hitting the request and validating contracts");
        titleLicenseGetRequest
                .execute()
                .as(TitleLicenseGetResponse.class);
    }

    @Test(
            groups = {
                    DmdcGroups.TITLES,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleId>/licenses] Test Title License Details with User " +
                    "Having Access to DU2 and TitleId Associated with DU1 and DU2"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-648")})
    public void testLicensesForHeUserWithTvdHeTitle() {

        log.info("Retrieve Title details when title is associated with DU 1 (TVD) and 2 (HE)");
        String appTitleGuid = TitlesData.getTvdHeGuid();

        log.info("Retrieve User details who is associated with DU 2 (HE)");
        int userId = UsersData.getHeId();

        int distId = DistributionUnitData.getHe();

        log.info(String.format("Creating request object with status, headers, json schema contracts of " +
                "title GUID %s for user %s", appTitleGuid, userId));
        MarketingDmdcRequest titleLicenseGetRequest = DmdcMarketingClient
                .getTitleLicenses(appTitleGuid)
                .authenticationDmdStatsOnly(marketingHeUser.getDmdstats());

        if (dbValidationFlag) {
            log.info("As dbValidationFlag is true, generating expected response and adding body contract");
            TitleLicenseGetResponse expectedResponse = TitleLicenseResponseFactory
                    .createLicenseResponse(userId, distId, appTitleGuid);

            titleLicenseGetRequest.contract(
                    ContractBody.builder()
                            .jsonEquals(expectedResponse)
                            .build()
            );
        }

        log.info("Hitting the request and validating contracts");
        titleLicenseGetRequest
                .execute()
                .as(TitleLicenseGetResponse.class);
    }

    @Test(
            groups = {
                    DmdcGroups.TITLES,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleId>/licenses] Test Title License Details with User " +
                    "Having Access to DU1 and TitleId Associated with DU1"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-649")})
    public void testLicensesForTvdUserWithTvdTitle() {

        log.info("Retrieve Title details when title is associated with DU 1 (TVD)");
        String appTitleGuid = TitlesData.getTvdTitleGuid();

        log.info("Retrieve User details who is associated with DU 1 (TVD)");
        int userId = UsersData.getTvdId();

        int distId = DistributionUnitData.getTvd();

        log.info(String.format("Creating request object with status, headers, json schema contracts of " +
                "title GUID %s for user %s", appTitleGuid, userId));
        MarketingDmdcRequest titleLicenseGetRequest = DmdcMarketingClient
                .getTitleLicenses(appTitleGuid)
                .authenticationDmdStatsOnly(marketingTvdUser.getDmdstats());

        if (dbValidationFlag) {
            log.info("As dbValidationFlag is true, generating expected response and adding body contract");
            TitleLicenseGetResponse expectedResponse = TitleLicenseResponseFactory
                    .createLicenseResponse(userId, distId, appTitleGuid);

            titleLicenseGetRequest.contract(
                    ContractBody.builder()
                            .jsonEquals(expectedResponse)
                            .build()
            );
        }

        log.info("Hitting the request and validating contracts");
        titleLicenseGetRequest
                .execute()
                .as(TitleLicenseGetResponse.class);
    }

    @Test(
            groups = {
                    DmdcGroups.TITLES,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleId>/licenses] Test Title License Details with " +
                    "User Having Access to DU1 and TitleId Associated with DU2"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-650")})
    public void testLicensesForTvdUserWithHeTitle() {

        log.info("Retrieve Title details when title is associated with DU 2 (HE)");
        String appTitleGuid = TitlesData.getHeTitleGuid();

        log.info("Retrieve User details who is associated with DU 1 (TVD)");
        int userId = UsersData.getTvdId();

        int distId = DistributionUnitData.getTvd();

        log.info(String.format("Creating request object with status, headers, json schema contracts of " +
                "title GUID %s for user %s", appTitleGuid, userId));
        MarketingDmdcRequest titleLicenseGetRequest = DmdcMarketingClient
                .getTitleLicenses(appTitleGuid)
                .authenticationDmdStatsOnly(marketingTvdUser.getDmdstats());

        if (dbValidationFlag) {
            log.info("As dbValidationFlag is true, generating expected response and adding body contract");
            TitleLicenseGetResponse expectedResponse = TitleLicenseResponseFactory
                    .createLicenseResponse(userId, distId, appTitleGuid);

            titleLicenseGetRequest.contract(
                    ContractBody.builder()
                            .jsonEquals(expectedResponse)
                            .build()
            );
        }

        log.info("Hitting the request and validating contracts");
        titleLicenseGetRequest
                .execute()
                .as(TitleLicenseGetResponse.class);
    }

    @Test(
            groups = {
                    DmdcGroups.TITLES,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleId>/licenses] Test Title License Details with User " +
                    "Having Access to DU2 and TitleId Associated with DU1"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-651")})
    public void testLicensesForHeUserWithTvdTitle() {

        log.info("Retrieve Title details when title is associated with DU 2 (HE)");
        String appTitleGuid = TitlesData.getTvdTitleGuid();

        log.info("Retrieve User details who is associated with DU 2 (HE)");
        int userId = UsersData.getHeId();
        int distId = DistributionUnitData.getTvd();

        log.info(String.format("Creating request object with status, headers, json schema contracts of " +
                "title GUID %s for user %s", appTitleGuid, userId));
        MarketingDmdcRequest titleLicenseGetRequest = DmdcMarketingClient
                .getTitleLicenses(appTitleGuid)
                .authenticationDmdStatsOnly(marketingHeUser.getDmdstats());

        if (dbValidationFlag) {
            log.info("As dbValidationFlag is true, generating expected response and adding body contract");
            TitleLicenseGetResponse expectedResponse = TitleLicenseResponseFactory
                    .createLicenseResponse(userId, distId, appTitleGuid);

            titleLicenseGetRequest.contract(
                    ContractBody.builder()
                            .jsonEquals(expectedResponse)
                            .build()
            );
        }

        log.info("Hitting the request and validating contracts");
        titleLicenseGetRequest
                .execute()
                .as(TitleLicenseGetResponse.class);
    }

    @Test(
            groups = {
                    DmdcGroups.TITLES,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleId>/licenses] Test Title License Details with User " +
                    "Having Access to DU2 and TitleId Associated with DU2"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-652")})
    public void testLicensesForHeUserWithHeTitle() {

        log.info("Retrieve Title details when title is associated with DU 2 (HE)");
        String appTitleGuid = TitlesData.getHeTitleGuid();

        log.info("Retrieve User details who is associated with DU 2 (HE)");
        int userId = UsersData.getHeId();

        int distId = DistributionUnitData.getTvd();

        log.info(String.format("Creating request object with status, headers, json schema contracts of " +
                "title GUID %s for user %s", appTitleGuid, userId));
        MarketingDmdcRequest titleLicenseGetRequest = DmdcMarketingClient
                .getTitleLicenses(appTitleGuid)
                .authenticationDmdStatsOnly(marketingHeUser.getDmdstats());

        if (dbValidationFlag) {
            log.info("As dbValidationFlag is true, generating expected response and adding body contract");
            TitleLicenseGetResponse expectedResponse = TitleLicenseResponseFactory
                    .createLicenseResponse(userId, distId, appTitleGuid);

            titleLicenseGetRequest.contract(
                    ContractBody.builder()
                            .jsonEquals(expectedResponse)
                            .build()
            );
        }

        log.info("Hitting the request and validating contracts");
        titleLicenseGetRequest
                .execute()
                .as(TitleLicenseGetResponse.class);
    }

    @Test(
            groups = {
                    DmdcGroups.TITLES,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleId>/licenses] Test Title Licenses without header cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-591")})
    public void testLicensesWithoutCookie() {

        log.info("Retrieve Title details when title is associated with DU 2 (HE)");
        TestTitles testTitle = TestTitleData.getTitleDUHe();

        log.info("Get 401 when dmdstats cookie is not provided");
        DmdcMarketingClient.getTitleLicenses(testTitle.getTitleId())
                .dmdstatsContractsAndNoAuth()
                .execute();
    }

    @Test(
            groups = {
                    DmdcGroups.TITLES,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleId>/licenses] Test Title Licenses with Invalid header cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-593")})
    public void testLicensesWithInvalidCookie() {

        log.info("Retrieve Title details when title is associated with DU 2 (HE)");
        TestTitles testTitle = TestTitleData.getTitleDUHe();

        log.info("Get 401 when dmdstats cookie is not provided");
        DmdcMarketingClient.getTitleLicenses(testTitle.getTitleId())
                .invalidDmdStatsAuthAndContracts(TestUser.INVALID_DMDSTATS)
                .execute();
    }
}
