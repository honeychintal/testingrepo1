package com.disney.dmdc.qa;

import com.disney.dmdc.qa.client.DmdcMarketingClient;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.factory.LocalNamesRequestFactory;
import com.disney.dmdc.qa.factory.LocalNamesResponseFactory;
import com.disney.dmdc.qa.model.Item;
import com.disney.dmdc.qa.model.LocalNamesRequest;
import com.disney.dmdc.qa.model.LocalNamesResponse;
import com.disney.dmdc.qa.data.SampleTitle;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.groups.TestGroups;
import org.testng.annotations.Test;

import java.util.List;

public class DmdcTitleLocalNamesTest {

	private static final TestUserCache testUserCache = new TestUserCache();
	private static final TestUser adminUser = testUserCache.getTestUserFromConfig(TestUserCache.ADMIN_DMDC_API_AUTOMATION_USER_KEY);

	@Test(groups = { DmdcGroups.TITLES, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P2 })
	@TestDoc(externalIds = { @ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-259") })
	public void testTitleLocalNames() {

		SampleTitle testTitle = SampleTitle.CHEAPER_BY_THE_DOZEN;
		Integer testPageSize = 3;

		LocalNamesRequest localNamesRequestBody = LocalNamesRequestFactory.CreateDefaultLocalizedDetailsRequest(testTitle);
		localNamesRequestBody.setPageSize(testPageSize);

		int pageResultSize = testPageSize < testTitle.getLocalNames().size() ? testPageSize : testTitle.getLocalNames().size();

		List<Item> expectedItems = testTitle.getLocalNames().subList(0, pageResultSize);

		LocalNamesResponse expectedResponseBody =
				LocalNamesResponseFactory.CreateDefaultLocalNamesResponse(testTitle.getLocalNames()).toBuilder()
						.items(expectedItems)
						.pageSize(testPageSize)
						.build();

		LocalNamesResponse responseBody = DmdcMarketingClient.getTitleLocalNames(testTitle.getTitleId(), localNamesRequestBody)
				.authenticationWithAntiforgery(adminUser)
				.contract(
						ContractBody.builder()
								.jsonEquals(expectedResponseBody)
								//.option(Option.IGNORING_ARRAY_ORDER)
								.build()
				)
				.execute()
				.as(LocalNamesResponse.class);
	}
}
