package com.disney.dmdc.qa;

import com.disney.dmdc.qa.client.DmdcMarketingClient;
import com.disney.dmdc.qa.constant.DistributionUnitIds;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.factory.TitleLocalsResponseFactory;
import com.disney.dmdc.qa.model.TitleLocalsGetResponse;
import com.disney.dmdc.qa.request.MarketingDmdcRequest;
import com.disney.dmdc.qa.util.TestServicesConfig;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.dmdc.qa.util.data.DistributionUnitData;
import com.disney.dmdc.qa.util.data.TitlesData;
import com.disney.dmdc.qa.util.data.UsersData;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.groups.TestGroups;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;


public class DmdcTitleLocalsTest {

    private static final TestUserCache testUserCache = new TestUserCache();
    private static final TestUser marketingTvdHeUser = testUserCache.getTestUserFromConfig(TestUserCache.MARKETING_TVD_HE_USER_KEY);
    private static final Logger log = LoggerFactory.getLogger(DmdcTitleLocalsTest.class);
    boolean dbValidationFlag = TestServicesConfig.shouldCompareResponseToBackendDatabase();

    @Test(
            groups = {
                    DmdcGroups.TITLELOCALS,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Title] [/api/portal/title/<titleId>/locals] Test Title Locals"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-135")})
    public void testLocals() {

        log.info("Retrieve Title details when title is associated with DU 1 (TVD) and DU 2 (HE) and passing DU 1 as query param");
        String appTitleGuid = TitlesData.getTvdHeGuid();
        int userId = UsersData.getTvdHeId();
        int distId = DistributionUnitData.getTvd();

        log.info("Creating request object with status, headers, json schema contracts");
        MarketingDmdcRequest titleLocalsGetRequest = DmdcMarketingClient.getTitleLocals(
                appTitleGuid,
                DistributionUnitIds.TELEVISION_DISTRIBUTION
        )
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats());

        if (dbValidationFlag) {
            log.info("As dbValidationFlag is true, generating expected response and adding body contract");
            TitleLocalsGetResponse expectedResponse = TitleLocalsResponseFactory
                    .createExpectedLocalsResponse(appTitleGuid, userId, distId);

            titleLocalsGetRequest.contract(
                    ContractBody.builder()
                    .jsonEquals(expectedResponse)
                    .build()
            );
        }

        log.info("Hitting the request and validating contracts");
        TitleLocalsGetResponse titleLocalsGetResponse = titleLocalsGetRequest
                .execute()
                .as(TitleLocalsGetResponse.class);

    }

    @Test(
            groups = {
                    DmdcGroups.TITLELOCALS,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Title] [/api/portal/title/<titleId>/locals] Test Title Locals associated only with DistributionId `2` and giving value as `1`"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-237")})
    public void TestLocalsWithHETitleAndQueryParamAsTVD() {

        log.info("Retrieve Title details when title is associated with DU 2 (HE) and passing DU 1 as query param");
        String appTitleGuid = TitlesData.getHeTitleGuid();
        int userId = UsersData.getTvdHeId();
        int distId = DistributionUnitData.getTvd();

        MarketingDmdcRequest titleLocalsGetRequest = DmdcMarketingClient.getTitleLocals(
                appTitleGuid,
                DistributionUnitIds.TELEVISION_DISTRIBUTION
        )
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats());

        if (dbValidationFlag) {
            TitleLocalsGetResponse expectedResponse = TitleLocalsResponseFactory
                    .createExpectedLocalsResponse(appTitleGuid, userId, distId);

            titleLocalsGetRequest.contract(
                    ContractBody.builder()
                            .jsonEquals(expectedResponse)
                            .build()
            );
        }

        TitleLocalsGetResponse titleLocalsGetResponse = titleLocalsGetRequest
                .execute()
                .as(TitleLocalsGetResponse.class);
    }

    @Test(
            groups = {
                    DmdcGroups.TITLELOCALS,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleId>/locals]Test Title Locals associated only with DistributionId `1` and giving value as `2`"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-330")})
    public void TestLocalsWithTVDTitleAndQueryParamAsHE() {

        log.info("Retrieve Title details when title is associated with DU 1 (TVD) and passing DU 2 as query param");
        String appTitleGuid = TitlesData.getTvdTitleGuid();
        int userId = UsersData.getTvdHeId();
        int distId = DistributionUnitData.getHe();

        MarketingDmdcRequest titleLocalsGetRequest = DmdcMarketingClient.getTitleLocals(
                appTitleGuid,
                DistributionUnitIds.HOME_ENTERTAINMENT
        )
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats());

        if (dbValidationFlag) {
            TitleLocalsGetResponse expectedResponse = TitleLocalsResponseFactory
                    .createExpectedLocalsResponse(appTitleGuid, userId, distId);

            titleLocalsGetRequest.contract(
                    ContractBody.builder()
                            .jsonEquals(expectedResponse)
                            .build()
            );
        }

        TitleLocalsGetResponse titleLocalsGetResponse = titleLocalsGetRequest
                .execute()
                .as(TitleLocalsGetResponse.class);
    }

    @Test(
            groups = {
                    DmdcGroups.TITLELOCALS,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Title] [/api/portal/title/<titleId>/locals] Test Title Locals with DistributionId value as `2`"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-197")})
    public void testLocalsWithQueryParamDUAs2() {

        log.info("Retrieve Title details when title is associated with DU 2 (HE) and passing DU 2 as query param");
        String appTitleGuid = TitlesData.getHeTitleGuid();
        int userId = UsersData.getTvdHeId();
        int distId = DistributionUnitData.getHe();

        MarketingDmdcRequest titleLocalsGetRequest = DmdcMarketingClient.getTitleLocals(
                appTitleGuid,
                DistributionUnitIds.HOME_ENTERTAINMENT
        )
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats());

        if (dbValidationFlag) {
            TitleLocalsGetResponse expectedResponse = TitleLocalsResponseFactory
                    .createExpectedLocalsResponse(appTitleGuid, userId, distId);

            titleLocalsGetRequest.contract(
                    ContractBody.builder()
                            .jsonEquals(expectedResponse)
                            .build()
            );
        }

        TitleLocalsGetResponse titleLocalsGetResponse = titleLocalsGetRequest
                .execute()
                .as(TitleLocalsGetResponse.class);
    }

    @Test(
            groups = {
                    DmdcGroups.TITLELOCALS,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Title] [/api/portal/title/<titleId>/locals] Test Title Locals with out query params"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-159")})
    public void testLocalsWithoutQueryParams() {

        log.info("Retrieve Title details when title is associated with DU 1 (TVD) and DU 2 (HE) and not passing any DU as query param");
        String appTitleGuid = TitlesData.getTvdHeGuid();
        int userId = UsersData.getTvdHeId();

        MarketingDmdcRequest titleLocalsGetRequest = DmdcMarketingClient.getTitleLocals(
                appTitleGuid
        )
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats());

        if (dbValidationFlag) {
            TitleLocalsGetResponse expectedResponse = TitleLocalsResponseFactory
                    .createExpectedLocalsResponse(appTitleGuid, userId, null);

            titleLocalsGetRequest.contract(
                    ContractBody.builder()
                            .jsonEquals(expectedResponse)
                            .build()
            );
        }

        TitleLocalsGetResponse titleLocalsGetResponse = titleLocalsGetRequest
                .execute()
                .as(TitleLocalsGetResponse.class);
    }

    @Test(
            groups = {
                    DmdcGroups.TITLELOCALS,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleId>/locals]Test Title Locals with DistributionId value as '1'"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-331")})
    public void testLocalsWithQueryParamDUAs1() {

        log.info("Retrieve Title details when title is associated with DU 1 (TVD) and passing DU 1 as query params");
        String appTitleGuid = TitlesData.getTvdTitleGuid();
        int userId = UsersData.getTvdHeId();
        int distId = DistributionUnitData.getTvd();

        MarketingDmdcRequest titleLocalsGetRequest = DmdcMarketingClient.getTitleLocals(
                appTitleGuid,
                DistributionUnitIds.TELEVISION_DISTRIBUTION
        )
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats());

        if (dbValidationFlag) {
            TitleLocalsGetResponse expectedResponse = TitleLocalsResponseFactory
                    .createExpectedLocalsResponse(appTitleGuid, userId, distId);

            titleLocalsGetRequest.contract(
                    ContractBody.builder()
                            .jsonEquals(expectedResponse)
                            .build()
            );
        }

        TitleLocalsGetResponse titleLocalsGetResponse = titleLocalsGetRequest
                .execute()
                .as(TitleLocalsGetResponse.class);
    }

    @Test(
            groups = {
                    DmdcGroups.TITLELOCALS,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleId>/locals]Test Title Locals associated with DistributionId '1' and '2'"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-332")})
    public void testLocalsWithTitleTVDAndHE() {

        log.info("Retrieve Title details when title is associated with DU 1 (TVD) and DU 2 (HE) and passing DU 2 as query param");
        String appTitleGuid = TitlesData.getTvdHeGuid();
        int userId = UsersData.getTvdHeId();
        int distId = DistributionUnitData.getHe();

        MarketingDmdcRequest titleLocalsGetRequest = DmdcMarketingClient.getTitleLocals(
                appTitleGuid,
                DistributionUnitIds.HOME_ENTERTAINMENT
        )
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats());

        if (dbValidationFlag) {
            TitleLocalsGetResponse expectedResponse = TitleLocalsResponseFactory
                    .createExpectedLocalsResponse(appTitleGuid, userId, distId);

            titleLocalsGetRequest.contract(
                    ContractBody.builder()
                            .jsonEquals(expectedResponse)
                            .build()
            );
        }

        TitleLocalsGetResponse titleLocalsGetResponse = titleLocalsGetRequest
                .execute()
                .as(TitleLocalsGetResponse.class);
    }

    @Test(
            groups = {
                    DmdcGroups.TITLELOCALS,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Title] [/api/portal/title/<titleId>/locals] Test Title Locals without Header Cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-150")})
    public void testLocalsWithoutDmdstats() {

        log.info("Retrieve Title details when title is associated with DU 1 (TVD) and DU 2 (HE) and passing DU 2 as query param");
        String appTitleGuid = TitlesData.getTvdHeGuid();

        log.info("Get 401 when dmdstats cookie is not provided");
        DmdcMarketingClient.getTitleLocals(appTitleGuid,
                DistributionUnitIds.HOME_ENTERTAINMENT
                )
                .dmdstatsContractsAndNoAuth()
                .execute();
    }

    @Test(
            groups = {
                    DmdcGroups.TITLELOCALS,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleId>/locals]Test Title Locals with invalid header cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-334")})
    public void testLocalsWithInvalidDmdstats() {

        log.info("Retrieve Title details when title is associated with DU 1 (TVD) and DU 2 (HE) and passing DU 2 as query param");
        String appTitleGuid = TitlesData.getTvdHeGuid();

        log.info("Get 401 when invalid dmdstats cookie is provided");
        DmdcMarketingClient.getTitleLocals(appTitleGuid,
                DistributionUnitIds.HOME_ENTERTAINMENT
        )
                .invalidDmdStatsAuthAndContracts(TestUser.INVALID_DMDSTATS)
                .execute();
    }
}
