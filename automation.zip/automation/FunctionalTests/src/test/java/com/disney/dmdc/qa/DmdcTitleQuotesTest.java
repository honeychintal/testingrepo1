package com.disney.dmdc.qa;

import com.disney.dmdc.qa.client.DmdcMarketingClient;
import com.disney.dmdc.qa.constant.DistributionUnitIds;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.constant.LocaleIds;
import com.disney.dmdc.qa.data.TestTitles;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.factory.TitleQuotesResponseFactory;
import com.disney.dmdc.qa.model.TitleQuotesResponse;
import com.disney.dmdc.qa.request.MarketingDmdcRequest;
import com.disney.dmdc.qa.util.TestServicesConfig;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.dmdc.qa.util.data.DistributionUnitData;
import com.disney.dmdc.qa.util.data.TitlesData;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.groups.TestGroups;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

public class DmdcTitleQuotesTest {

    private static final TestUserCache testUserCache = new TestUserCache();
    private static final TestUser marketingTvdHeUser = testUserCache.getTestUserFromConfig(TestUserCache.MARKETING_TVD_HE_USER_KEY);
    private static final TestUser marketingHeUser = testUserCache.getTestUserFromConfig(TestUserCache.MARKETING_HE_USER_KEY);

    private static final TestUser tvd_he_user = testUserCache.getTestUserFromConfig(TestUserCache.MARKETING_TVD_HE_USER_KEY);
    private static final Logger log = LoggerFactory.getLogger(DmdcTitleQuotesTest.class);
    boolean dbValidationFlag = TestServicesConfig.shouldCompareResponseToBackendDatabase();

    @Test(
            groups = {
                    DmdcGroups.TITLES,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Title][/api/portal/title/<title id>/quotes] Test title Quotes with valid distributionUnitId=1 and available localId param set to true"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-307")})
    public void testTitleQuotes_TVD_User() {

        log.info("Retrieve Title details when title is associated with DU 1 (TVD) & 2 (HE) and passing DU 1 as query param");
        String appTitleGuid = TitlesData.getTvdHeGuid();
        int distId = DistributionUnitData.getTvd();
        int localId = LocaleIds.ENG_US;

        MarketingDmdcRequest titleQuotesGetRequest = DmdcMarketingClient.getTitleQuotes(
                appTitleGuid,
                DistributionUnitIds.TELEVISION_DISTRIBUTION,
                LocaleIds.ENG_US
        )
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats());

        if (dbValidationFlag) {
            TitleQuotesResponse expectedQuotesResponse = TitleQuotesResponseFactory
                    .createTitleQuotesResponse(appTitleGuid, distId, localId);

            titleQuotesGetRequest.contract(
              ContractBody.builder()
              .jsonEquals(expectedQuotesResponse)
              .build()
            );
        }

        log.info("Generating expected response from DB and adding body contract");
        TitleQuotesResponse quotesResponse = titleQuotesGetRequest
                .execute()
                .as(TitleQuotesResponse.class);
    }

    @Test(
            groups = {
                    DmdcGroups.TITLES,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Title][/api/portal/title/<title id>/quotes] Test title Quotes with valid distributionUnitId=2 and available localId param set to true"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-308")})
    public void testTitleQuotes_HE_User() {

        log.info("Retrieve Title details when title is associated with DU 1 (TVD) & 2 (HE) and passing DU 2 as query param");
        String appTitleGuid = TitlesData.getTvdHeGuid();
        int distId = DistributionUnitData.getHe();
        int localId = LocaleIds.ENG_US;

        MarketingDmdcRequest titleQuotesGetRequest = DmdcMarketingClient.getTitleQuotes(
                appTitleGuid,
                DistributionUnitIds.HOME_ENTERTAINMENT,
                LocaleIds.ENG_US
        )
                .authenticationDmdStatsOnly(marketingHeUser.getDmdstats());

        if (dbValidationFlag) {
            TitleQuotesResponse expectedQuotesResponse = TitleQuotesResponseFactory
                    .createTitleQuotesResponse(appTitleGuid, distId, localId);

            titleQuotesGetRequest.contract(
                    ContractBody.builder()
                            .jsonEquals(expectedQuotesResponse)
                            .build()
            );
        }

        log.info("Generating expected response from DB and adding body contract");
        TitleQuotesResponse quotesResponse = titleQuotesGetRequest
                .execute()
                .as(TitleQuotesResponse.class);

    }

    @Test(
            groups = {
                    DmdcGroups.TITLES,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleId>/quotes] Test Title Quotes with invalid dmdstats cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-291")})
    public void testTitleQuotesWithInvalidCookie() {

        TestTitles title = TestTitles.ALIEN_VS_PREDATOR_DU_TVD_HE;
        DmdcMarketingClient.getTitleQuotes(
                title.getTitleId(),
                DistributionUnitIds.TELEVISION_DISTRIBUTION,
                LocaleIds.ENG_US
        )
                .invalidDmdStatsAuthAndContracts(TestUser.INVALID_DMDSTATS)
                .execute();
    }

    @Test(
            groups = {
                    DmdcGroups.TITLES,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleId>/quotes] Test Title Quotes without dmdstats header cookies"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-246")})
    public void testTitleQuotesWithoutCookie() {

        TestTitles title = TestTitles.ALIEN_VS_PREDATOR_DU_TVD_HE;

        DmdcMarketingClient.getTitleQuotes(
                title.getTitleId(),
                DistributionUnitIds.TELEVISION_DISTRIBUTION,
                LocaleIds.ENG_US
        )
                .dmdstatsContractsAndNoAuth()
                .execute();
    }

}
