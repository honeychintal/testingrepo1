package com.disney.dmdc.qa;

import com.disney.dmdc.qa.client.DmdcMarketingClient;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.constant.LocaleIds;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.factory.TitleTalentsResponseFactory;
import com.disney.dmdc.qa.model.TitleTalentsGetResponse;
import com.disney.dmdc.qa.request.MarketingDmdcRequest;
import com.disney.dmdc.qa.type.Locals;
import com.disney.dmdc.qa.util.TestServicesConfig;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.dmdc.qa.util.data.TitlesData;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.groups.TestGroups;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

public class DmdcTitleTalentsTest {

    private static final TestUserCache testUserCache = new TestUserCache();
    private static final TestUser marketingTvdHeUser = testUserCache
            .getTestUserFromConfig(TestUserCache.MARKETING_TVD_HE_USER_KEY);
    private static final Logger log = LoggerFactory.getLogger(DmdcTitleTalentsTest.class);
    boolean dbValidationFlag = TestServicesConfig.shouldCompareResponseToBackendDatabase();

    @Test(groups = {DmdcGroups.TITLES, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleid>/talents] Test title talent Details")
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-154")})
    public void testTitleTalents() {

        log.info("Retrieve Title details when title is associated with TVD and HE");
        String appTitleGuid = TitlesData.getTvdHeGuid();
        int localId = Locals.ENG_USA.getId();

        log.info("Creating request object with status, headers, json schema contracts");
        MarketingDmdcRequest titleTalentsGetRequest = DmdcMarketingClient.getTitleTalents(
                appTitleGuid,
                LocaleIds.ENG_US
        )
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats());

        log.info("Generating expected response from DB and adding body contract");
        if(dbValidationFlag){
            TitleTalentsGetResponse expectedResponseBody =
                    TitleTalentsResponseFactory.createTitleTalentsDefaultResponse(appTitleGuid, localId);
            titleTalentsGetRequest
                    .contract(ContractBody.builder()
                    .jsonEquals(expectedResponseBody)
                    .build()
            );
        }

        log.info("Hitting the request and validating contracts");
        titleTalentsGetRequest
                .execute()
                .as(TitleTalentsGetResponse.class);
    }

    @Test(groups = {DmdcGroups.TITLES, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Title][/api/portal/title/<title id>/talents] Test title talent Details with TitleId associated with only TVD")
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-539")})
    public void testTitleTalentsTVD() {

        log.info("Retrieve Title details when title is associated with TVD");
        String appTitleGuid = TitlesData.getTvdTitleGuid();
        int localId = Locals.ENG_USA.getId();

        log.info("Creating request object with status, headers, json schema contracts");
        MarketingDmdcRequest titleTalentsGetRequest = DmdcMarketingClient.getTitleTalents(
                appTitleGuid,
                LocaleIds.ENG_US
        )
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats());

        log.info("Generating expected response from DB and adding body contract");
        if(dbValidationFlag) {
            TitleTalentsGetResponse expectedResponseBody =
                    TitleTalentsResponseFactory.createTitleTalentsDefaultResponse(appTitleGuid, localId);
            titleTalentsGetRequest
                    .contract(ContractBody.builder()
                    .jsonEquals(expectedResponseBody)
                    .build()
            );
        }

        log.info("Hitting the request and validating contracts");
        titleTalentsGetRequest
                .execute()
                .as(TitleTalentsGetResponse.class);
    }

    @Test(groups = {DmdcGroups.TITLES, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Title][/api/portal/title/<title id>/talents] Test title talent Details with TitleId associated with only HE")
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-538")})
    public void testTitleTalentsHE() {

        log.info("Retrieve Title details when title is associated with HE");
        String appTitleGuid = TitlesData.getHeTitleGuid();
        int localId = Locals.ENG_USA.getId();

        log.info("Creating request object with status, headers, json schema contracts");
        MarketingDmdcRequest titleTalentsGetRequest = DmdcMarketingClient.getTitleTalents(
                appTitleGuid,
                LocaleIds.ENG_US
        )
                .authenticationDmdStatsOnly(marketingTvdHeUser.getDmdstats());

        log.info("Generating expected response from DB and adding body contract");
        if(dbValidationFlag) {
            TitleTalentsGetResponse expectedResponseBody =
                    TitleTalentsResponseFactory.createTitleTalentsDefaultResponse(appTitleGuid, localId);
            titleTalentsGetRequest
                    .contract(ContractBody.builder()
                    .jsonEquals(expectedResponseBody)
                    .build()
            );
        }

        log.info("Hitting the request and validating contracts");
        titleTalentsGetRequest
                .execute()
                .as(TitleTalentsGetResponse.class);
    }

    @Test(groups = {DmdcGroups.TITLES, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleid>/talents] Test title talent Details without Cookie")
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-247")})
    public void testTitleTalentsWithoutCookie() {
        log.info("Retrieve Title details when title is associated with TVD and HE");
        String appTitleGuid = TitlesData.getTvdHeGuid();

        DmdcMarketingClient.getTitleTalents(
                appTitleGuid,
                LocaleIds.ENG_US
        )
                .dmdstatsContractsAndNoAuth()
                .execute();
    }

    @Test(groups = {DmdcGroups.TITLES, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Title][/api/portal/title/<titleid>/talents] " +
                    "Test title talent Details with invalid header cookie")
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-537")})
    public void testTitleTalentsWithInvalidCookie() {

        log.info("Retrieve Title details when title is associated with TVD and HE");
        String appTitleGuid = TitlesData.getTvdHeGuid();

        DmdcMarketingClient.getTitleTalents(
                appTitleGuid,
                LocaleIds.ENG_US
        )
                .invalidDmdStatsAuthAndContracts(TestUser.INVALID_DMDSTATS)
                .execute();
    }
}
