package com.disney.dmdc.qa;

import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.entities.ApplicationTitle;
import com.disney.dmdc.qa.entities.ApplicationTitleCategory;
import com.disney.dmdc.qa.entities.HomepageTitleSearch;
import com.disney.dmdc.qa.entities.Locale;
import com.disney.dmdc.qa.entities.QuickView;
import com.disney.dmdc.qa.entities.Status;
import com.disney.dmdc.qa.util.data.DistributionUnitData;
import com.disney.dmdc.qa.util.data.TitlesData;
import com.disney.dmdc.qa.util.data.UsersData;
import com.disney.dmdc.qa.util.db.DmdCentralDbUtils;
import org.testng.annotations.Test;

import java.sql.SQLException;
import java.util.List;

public class TestDataManagementTest {
    @Test(groups = DmdcGroups.POC, enabled = false)
    public void testSelectingTitleInformationFromDatabase() throws SQLException {
        String appTitleGuid = TitlesData.getTvdHeGuid();
        ApplicationTitle appTitle = DmdCentralDbUtils.selectApplicationTitle(appTitleGuid);
        HomepageTitleSearch titleSearch = DmdCentralDbUtils.selectHomepageTitleSearch(appTitle.getApplicationTitleId());
        List<ApplicationTitleCategory> categories = DmdCentralDbUtils.selectApplicationTitleCategory(appTitle.getApplicationTitleId());
        Status status = DmdCentralDbUtils.selectStatus(appTitle.getStatusId());
    }

    @Test(groups = DmdcGroups.POC, enabled = false)
    public void testTitleLocalStoredProc() throws SQLException {
        String appTitleGuid = TitlesData.getTvdHeGuid();
        int userId = UsersData.getTvdHeId();
        int distId = DistributionUnitData.getTvd();

        ApplicationTitle appTitle = DmdCentralDbUtils.selectApplicationTitle(appTitleGuid);
        List<Locale> localeList = DmdCentralDbUtils.callTitleLocalToList(appTitle.getApplicationId(), userId, distId, appTitleGuid);
    }

    @Test(groups = DmdcGroups.POC, enabled = false)
    public void testMultiTableStoredProcResult() throws SQLException {
        String appTitleGuid = TitlesData.getTvdHeGuid();
        int userId = UsersData.getTvdHeId();
        int distId = DistributionUnitData.getTvd();

        ApplicationTitle appTitle = DmdCentralDbUtils.selectApplicationTitle(appTitleGuid);
        QuickView quickView = DmdCentralDbUtils.callTitleQuickViewGetInfo(appTitle.getApplicationId(), userId, appTitleGuid);
        DmdCentralDbUtils.callTitleAssetDetailGetInfo(1, 12512, 3479884);
    }
}
