package com.disney.dmdc.qa.admin;

import com.disney.dmdc.qa.client.DmdcAdminClient;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.factory.LookupGroupResponseFactory;
import com.disney.dmdc.qa.model.LookupGroupGetResponse;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.groups.TestGroups;
import org.testng.annotations.Test;

public class DmdcLookupDistributionGroupTest {

    private static final TestUserCache testUserCache = new TestUserCache();
    private static final TestUser adminUser = testUserCache.getTestUserFromConfig(TestUserCache.ADMIN_DMDC_API_AUTOMATION_USER_KEY);

    @Test(
            groups = {DmdcGroups.LOOKUP,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Admin Lookup][/api/lookup/distributionGroup] Distribution Group"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-463")})
    public void testDistributionGroups() {

        // create and retrieve the expected response
        LookupGroupGetResponse expectedResponse = LookupGroupResponseFactory
                .createDefaultDistributionGroupResponse();

        DmdcAdminClient.getLookupDistributionGroup()
                .authenticationDmdStatsOnly(adminUser.getDmdstats())
                .contract(
                        ContractBody.builder()
                                .jsonEquals(expectedResponse)
                                .build())
                .execute()
                .as(LookupGroupGetResponse.class);
    }

    @Test(
            groups = {
                    DmdcGroups.LOOKUP,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Admin Lookup][/api/lookup/distributionGroup] Distribution Group Details without dmdstats header cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-464")})
    public void testDistributionGroupsWithoutDmdstats() {

        //Get 401 when dmdstats cookie is not provided
        DmdcAdminClient.getLookupDistributionGroup()
                .dmdstatsContractsAndNoAuth()
                .execute();
    }

    @Test(
            groups = {
                    DmdcGroups.LOOKUP,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Admin Lookup][/api/lookup/distributionGroup] Distribution Group Details with invalid dmdstats header cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-465")})
    public void testDistributionGroupsWithInvalidDmdstats() {

        //Get 401 when invalid dmdstats cookie is provided
        DmdcAdminClient.getLookupDistributionGroup()
                .invalidDmdStatsAuthAndContracts(TestUser.INVALID_DMDSTATS)
                .execute();
    }
}
