package com.disney.dmdc.qa.admin;

import com.disney.dmdc.qa.client.DmdcAdminClient;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.factory.MembershipTerritoriesResponseFactory;
import com.disney.dmdc.qa.model.MembershipTerritoriesGetResponse;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.groups.TestGroups;
import net.javacrumbs.jsonunit.core.Option;
import org.testng.annotations.Test;

public class DmdcLookupMembershipTerritoriesTest {

    private static final TestUserCache testUserCache = new TestUserCache();
    private static final TestUser adminUser = testUserCache.getTestUserFromConfig(TestUserCache.ADMIN_DMDC_API_AUTOMATION_USER_KEY);

    @Test(
            groups = {DmdcGroups.LOOKUP,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Admin Lookup][/api/lookup/membership/territories]To get the list of available Territories along with id's"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-489")})
    public void testAvailableTerritories() {

        // create and retrieve the expected response
        MembershipTerritoriesGetResponse expectedResponse = MembershipTerritoriesResponseFactory.createDefaultTerritoryResponse();

        DmdcAdminClient.getLookupMembershipTerritories()
                .authenticationDmdStatsOnly(adminUser.getDmdstats())
                .contract(
                        ContractBody.builder()
                                .jsonEquals(expectedResponse)
                                // We have more array items to validate, Once DB is implemented, will remove 'option'
                                .option(Option.IGNORING_EXTRA_ARRAY_ITEMS)
                                .build())
                .execute()
                .as(MembershipTerritoriesGetResponse.class);
    }

    @Test(
            groups = {
                    DmdcGroups.LOOKUP,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Admin Lookup][/api/lookup/membership/territories]Test lookup membership territories without Header Cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-490")})
    public void testAvailableTerritoriesWithoutDmdstats() {

        //Get 401 when dmdstats cookie is not provided
        DmdcAdminClient.getLookupMembershipTerritories()
                .dmdstatsContractsAndNoAuth()
                .execute();
    }

    @Test(
            groups = {
                    DmdcGroups.LOOKUP,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Admin Lookup][/api/lookup/membership/territories]Test lookup membership territories with invalid Header Cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-492")})
    public void testAvailableTerritoriesWithInvalidDmdstats() {

        //Get 401 when invalid dmdstats cookie is provided
        DmdcAdminClient.getLookupMembershipTerritories()
                .invalidDmdStatsAuthAndContracts(TestUser.INVALID_DMDSTATS)
                .execute();
    }
}
