package com.disney.dmdc.qa.admin;

import com.disney.dmdc.qa.client.DmdcAdminClient;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.data.TestUserCommandsData;
import com.disney.dmdc.qa.factory.UserCommandsResponseFactory;
import com.disney.dmdc.qa.model.UserCommandsItem;
import com.disney.dmdc.qa.model.UserCommandsResponse;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.groups.TestGroups;
import org.testng.annotations.Test;

import java.util.List;

public class DmdcMembershipUserCommandsTest {

    private static final TestUserCache testUserCache = new TestUserCache();
    private static final TestUser adminUser = testUserCache
            .getTestUserFromConfig(TestUserCache.ADMIN_DMDC_API_AUTOMATION_USER_KEY);

    @Test(
            groups = {DmdcGroups.MEMBERSHIP_USER, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Admin Membership User][/api/membership/user/<userid>/commands]" +
                    "Test To get the actions that the user can perform"
    )
    @TestDoc(externalIds = { @ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-745") })
    public void testUserCommands() {

        Integer testUserId = TestUserCommandsData.getUserId();
        List<UserCommandsItem> testUserCommandsItems = TestUserCommandsData.getUserCommandsItems();

        UserCommandsResponse expectedResponse = UserCommandsResponseFactory
                .createDefaultUserCommandsResponse(testUserCommandsItems);

        DmdcAdminClient.getUserCommands(testUserId)
                .authenticationDmdStatsOnly(adminUser.getDmdstats())
                .contract(
                        ContractBody.builder()
                                .jsonEquals(expectedResponse)
                                .build())
                .execute()
                .as(UserCommandsResponse.class);
    }

    @Test(
            groups = {DmdcGroups.MEMBERSHIP_USER, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Admin Membership User][/api/membership/user/<userid>/commands]" +
                    "Test User Actions without header cookie"
    )
    @TestDoc(externalIds = { @ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-765") })
    public void testUserCommandsWithoutCookie() {

        Integer testUserId = TestUserCommandsData.getUserId();

        DmdcAdminClient.getUserCommands(testUserId)
                .dmdstatsContractsAndNoAuth()
                .execute();
    }

    @Test(
            groups = {DmdcGroups.MEMBERSHIP_USER, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Admin Membership User][/api/membership/user/<userid>/commands]" +
                    "Test User Actions with invalid header cookie"
    )
    @TestDoc(externalIds = { @ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-766") })
    public void testUserCommandsWithInvalidCookie() {

        Integer testUserId = TestUserCommandsData.getUserId();

        DmdcAdminClient.getUserCommands(testUserId)
                .invalidDmdStatsAuthAndContracts(TestUser.INVALID_DMDSTATS)
                .execute();
    }
}