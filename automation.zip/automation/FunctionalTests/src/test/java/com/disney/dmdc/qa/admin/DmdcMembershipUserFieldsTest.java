package com.disney.dmdc.qa.admin;

import com.disney.dmdc.qa.client.DmdcAdminClient;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.data.TestFieldsData;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.model.FieldGetResponse;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.groups.TestGroups;
import org.testng.annotations.Test;

import java.util.List;

public class DmdcMembershipUserFieldsTest {
    private static final TestUserCache testUserCache = new TestUserCache();
    private static final TestUser adminUser = testUserCache.getTestUserFromConfig(TestUserCache.ADMIN_DMDC_API_AUTOMATION_USER_KEY);

    @Test(
            groups = {DmdcGroups.MEMBERSHIP_USER, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Admin Membership User][/api/membership/user/fields] Test Admin User fields"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-655")})
    public void testMembershipUserFields() {

        List<FieldGetResponse> expectedResponse = TestFieldsData.getMembershipUserFieldsResponse();

        DmdcAdminClient.getMembershipUserFields()
                .authenticationDmdStatsOnly(adminUser.getDmdstats())
                .contract(
                        ContractBody.builder()
                                .jsonEquals(expectedResponse)
                                .build())
                .execute();
    }

    @Test(
            groups = {
                    DmdcGroups.MEMBERSHIP_USER,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Admin Membership User][/api/membership/user/fields] Test Admin User fields without header cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-658")})
    public void testMembershipUserWithoutDmdstats() {

        //Get 401 when dmdstats cookie is not provided
        DmdcAdminClient.getMembershipUserFields()
                .dmdstatsContractsAndNoAuth()
                .execute();
    }

    @Test(
            groups = {
                    DmdcGroups.MEMBERSHIP_USER,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Admin Membership User][/api/membership/user/fields] Test Admin User fields with invalid header cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-677")})
    public void testMembershipUserWithInvalidDmdstats() {

        //Get 401 when invalid dmdstats cookie is provided
        DmdcAdminClient.getMembershipUserFields()
                .invalidDmdStatsAuthAndContracts(TestUser.INVALID_DMDSTATS)
                .execute();
    }
}
