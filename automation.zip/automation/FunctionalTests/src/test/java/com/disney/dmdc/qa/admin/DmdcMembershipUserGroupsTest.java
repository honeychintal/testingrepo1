package com.disney.dmdc.qa.admin;

import com.disney.dmdc.qa.client.DmdcAdminClient;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.constant.PageIndex;
import com.disney.dmdc.qa.constant.TestAccounts;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.data.TestUserGroupsResultData;
import com.disney.dmdc.qa.factory.UserGroupsResponseFactory;
import com.disney.dmdc.qa.model.UserGroupsResponse;
import com.disney.dmdc.qa.model.UserGroupsResult;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.groups.TestGroups;
import org.testng.annotations.Test;

public class DmdcMembershipUserGroupsTest {

    private static final TestUserCache testUserCache = new TestUserCache();
    private static final TestUser adminUser = testUserCache
            .getTestUserFromConfig(TestUserCache.ADMIN_DMDC_API_AUTOMATION_USER_KEY);

    @Test(
            groups = {DmdcGroups.MEMBERSHIP_USER, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Admin Membership User][/api/membership/user/<userid>/groups] Get user groups"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-803")})
    public void testUserGroups() {

        int userId = TestAccounts.TEST_TVD_HE_USER.getId();

        UserGroupsResult userGroupsResult = TestUserGroupsResultData
                .getTestTvdHEUserGroups();

        UserGroupsResponse expectedResponse = UserGroupsResponseFactory
                .testUserGroupsResponse(userGroupsResult);

        DmdcAdminClient.getUserGroups(
                userId,
                userId,
                PageIndex.DEFAULT
        )
                .authenticationDmdStatsOnly(adminUser.getDmdstats())
                .contract(
                        ContractBody.builder()
                                .jsonEquals(expectedResponse)
                                .build())
                .execute()
                .as(UserGroupsResponse.class);
    }

    @Test(
            groups = {DmdcGroups.MEMBERSHIP_USER, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "Admin Membership User][/api/membership/user/<userid>/groups] Get user groups " +
                    "with user (header cookie )without admin access"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-822")})
    public void testUserGroupWithNonAdminUser() {

        int userId = TestAccounts.TEST_TVD_HE_USER.getId();
        TestUser marketingTvdHeUser = testUserCache
                .getTestUserFromConfig(TestUserCache.MARKETING_TVD_HE_USER_KEY);

        DmdcAdminClient.getUserGroups(
                userId,
                userId,
                PageIndex.DEFAULT
        )
                .forbiddenDmdStatsContract(marketingTvdHeUser.getDmdstats())
                .execute();
    }

    @Test(
            groups = {DmdcGroups.MEMBERSHIP_USER, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "Admin Membership User][/api/membership/user/<userid>/groups] Get user groups " +
                    "without header cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-823")})
    public void testUserGroupWithoutCookie() {

        int userId = TestAccounts.TEST_TVD_HE_USER.getId();

        DmdcAdminClient.getUserGroups(
                userId,
                userId,
                PageIndex.DEFAULT
        )
                .dmdstatsContractsAndNoAuth()
                .execute();
    }

    @Test(
            groups = {DmdcGroups.MEMBERSHIP_USER, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "Admin Membership User][/api/membership/user/<userid>/groups] Get user groups " +
                    "with invalid header cookie (dmdstats)"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-825")})
    public void testUserGroupWithInvalidCookie() {

        int userId = TestAccounts.TEST_TVD_HE_USER.getId();

        DmdcAdminClient.getUserGroups(
                userId,
                userId,
                PageIndex.DEFAULT
        )
                .invalidDmdStatsAuthAndContracts(TestUser.INVALID_DMDSTATS)
                .execute();
    }

}
