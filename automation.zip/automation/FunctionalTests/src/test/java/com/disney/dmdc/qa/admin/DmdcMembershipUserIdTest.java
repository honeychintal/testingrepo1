package com.disney.dmdc.qa.admin;

import com.disney.dmdc.qa.client.DmdcAdminClient;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.constant.RequestIds;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.data.TestUserData;
import com.disney.dmdc.qa.data.TestUserIdResultData;
import com.disney.dmdc.qa.factory.MembershipUserIdResponseFactory;
import com.disney.dmdc.qa.model.MembershipUserIdResponse;
import com.disney.dmdc.qa.model.MembershipUserIdResult;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.groups.TestGroups;
import org.testng.annotations.Test;


public class DmdcMembershipUserIdTest {

    private static final TestUserCache testUserCache = new TestUserCache();
    private static final TestUser adminUser = testUserCache
            .getTestUserFromConfig(TestUserCache.ADMIN_DMDC_API_AUTOMATION_USER_KEY);


    @Test(
            groups = {DmdcGroups.MEMBERSHIP_USER, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Admin Membership User][/api/membership/user/<userId>] Get user by userid"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-876")})
    public void testGetUserByUserId() {

        int userId = TestUserData
                .TEST_USER_ID
                .getUserId();
        
        MembershipUserIdResult membershipUserIdResult = TestUserIdResultData.getTestUserIdDetails();
        MembershipUserIdResponse expectedResponse = MembershipUserIdResponseFactory
                .testUserIdResponse(membershipUserIdResult);

        DmdcAdminClient.getUserId(userId,
                userId,
                RequestIds.DEFAULT
        )
                .authenticationDmdStatsOnly(adminUser.getDmdstats())
                .contract(
                        ContractBody.builder()
                                .jsonEquals(expectedResponse)
                                .build())
                .execute();
    }

    @Test(
            groups = {DmdcGroups.MEMBERSHIP_USER, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Admin Membership User][/api/membership/user/<userId>] Get user by userid " +
                    "with header cookie of non-admin user"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-884")})
    public void testGetUserIdNonAdminUser() {

        int userId = TestUserData
                .TEST_USER_ID
                .getUserId();

        TestUser marketingTvdHeUser = testUserCache
                .getTestUserFromConfig(TestUserCache.MARKETING_TVD_HE_USER_KEY);

        DmdcAdminClient.getUserId(userId,
                userId,
                RequestIds.DEFAULT
        )
                .forbiddenDmdStatsContract(marketingTvdHeUser.getDmdstats())
                .execute();
    }

    @Test(
            groups = {DmdcGroups.MEMBERSHIP_USER, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Admin Membership User][/api/membership/user/<userId>] Get user by userid " +
                    "without header cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-888")})
    public void testGetUserIdWithoutCookie() {

        int userId = TestUserData
                .TEST_USER_ID
                .getUserId();

        DmdcAdminClient.getUserId(userId,
                userId,
                RequestIds.DEFAULT
        )
                .dmdstatsContractsAndNoAuth()
                .execute();
    }

    @Test(
            groups = {DmdcGroups.MEMBERSHIP_USER, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Admin Membership User][/api/membership/user/<userId>] Get user by userid " +
                    "with invalid header cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-890")})
    public void testGetUserIdInvalidCookie() {

        int userId = TestUserData
                .TEST_USER_ID
                .getUserId();

        DmdcAdminClient.getUserId(userId,
                userId,
                RequestIds.DEFAULT
        )
                .invalidDmdStatsAuthAndContracts(TestUser.INVALID_DMDSTATS)
                .execute();
    }

}
