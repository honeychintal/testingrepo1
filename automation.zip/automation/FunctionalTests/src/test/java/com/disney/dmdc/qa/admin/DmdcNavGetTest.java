package com.disney.dmdc.qa.admin;

import com.disney.dmdc.qa.client.DmdcAdminClient;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.factory.NavGetResponsefactory;
import com.disney.dmdc.qa.model.NavGetResponse;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.dmdc.qa.util.TestUserUtil;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.groups.TestGroups;
import org.testng.annotations.Test;


public class DmdcNavGetTest {

    private static final TestUserCache testUserCache = new TestUserCache();
    private static final TestUser nonAdminUser = testUserCache.getTestUserFromConfig(TestUserCache.MARKETING_TVD_HE_USER_KEY);
    private static final TestUser adminUser = testUserCache.getTestUserFromConfig(TestUserCache.ADMIN_DMDC_API_AUTOMATION_USER_KEY);

    @Test(
            groups = {
                    DmdcGroups.NAV_GET,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Admin Nav][/api/nav/get] Test to retrieve the manageable actions and settings of Admin User"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-780")})
    public void testNavGetForAdminUser() {

        // creating an expected response for admin User dmdc_api_automation@dmdcentral.com
        NavGetResponse expectedResponse = NavGetResponsefactory
                .createNavGetResponse(TestUserUtil.getTestAccountDmdcApiAutomationAdminUser());

        //Get navGet details of a admin user
        NavGetResponse navGetResponse =  DmdcAdminClient.getNavGet()
                .authenticationDmdStatsOnly(adminUser.getDmdstats())
                .contract(
                        ContractBody.builder()
                                .jsonEquals(expectedResponse)
                                .build())
                .execute()
                .as(NavGetResponse.class);
    }

    @Test(
            groups = {
                    DmdcGroups.NAV_GET,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Admin Nav][/api/nav/get] Test To get the manageable actions and settings of a User not having access to Admin"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-778")})
    public void testNavGetForNonAdminUser() {

        // creating an expected response for non-admin User test_tvd_and_he_user@dmdcentral.com
        NavGetResponse expectedResponse = NavGetResponsefactory
                .createNavGetResponse(TestUserUtil.getTestAccountTvdHeMarketingUser());

        //Get navGet details of a non-admin user
        NavGetResponse navGetResponse =  DmdcAdminClient.getNavGet()
                .authenticationDmdStatsOnly(nonAdminUser.getDmdstats())
                .contract(
                        ContractBody.builder()
                                .jsonEquals(expectedResponse)
                                .build())
                .execute()
                .as(NavGetResponse.class);
    }

    @Test(
            groups = {
                    DmdcGroups.NAV_GET,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Admin Nav][/api/nav/get] To get the Admin Menu Details without Header Cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-782")})
    public void testNavGetWithoutCookie() {

        DmdcAdminClient.getNavGet()
                .dmdstatsContractsAndNoAuth()
                .execute();
    }

    @Test(
            groups = {
                    DmdcGroups.NAV_GET,
                    TestGroups.BVT,
                    DmdcGroups.XRAY,
                    DmdcGroups.P1},
            description = "[Admin Nav][/api/nav/get] To get the Admin Menu Details with Invalid Header Cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-784")})
    public void testNavGetWithInvalidCookie() {

        DmdcAdminClient.getNavGet()
                .invalidDmdStatsAuthAndContracts(TestUser.INVALID_DMDSTATS)
                .execute();
    }
}
