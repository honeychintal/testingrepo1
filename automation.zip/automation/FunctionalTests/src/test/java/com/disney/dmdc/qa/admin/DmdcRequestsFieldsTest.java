package com.disney.dmdc.qa.admin;

import com.disney.dmdc.qa.client.DmdcAdminClient;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.data.TestFieldsData;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.model.FieldGetResponse;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.groups.TestGroups;
import org.testng.annotations.Test;

import java.util.List;

public class DmdcRequestsFieldsTest {

    private static final TestUserCache testUserCache = new TestUserCache();
    private static final TestUser adminUser = testUserCache
            .getTestUserFromConfig(TestUserCache.ADMIN_DMDC_API_AUTOMATION_USER_KEY);

    @Test(
            groups = {DmdcGroups.REQUESTS, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Admin Requests] [/api/requests/fields] " +
                    "Test To get the details of the default search criteria fields"
    )
    @TestDoc(externalIds = { @ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-707") })
    public void testRequestsFields() {

        List<FieldGetResponse> expectedResponse = TestFieldsData.getRequestsFields();

        DmdcAdminClient.getRequestsFields()
                .authenticationDmdStatsOnly(adminUser.getDmdstats())
                .contract(
                        ContractBody.builder()
                                .jsonEquals(expectedResponse)
                                .build())
                .execute();
    }

    @Test(
            groups = {DmdcGroups.REQUESTS, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Admin Requests] [api/requests/fields]" +
                    "To get the details of the default search criteria fields without header cookie"
    )
    @TestDoc(externalIds = { @ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-708") })
    public void testRequestsFieldsWithoutCookie() {

        DmdcAdminClient.getRequestsFields()
                .dmdstatsContractsAndNoAuth()
                .execute();
    }

    @Test(
            groups = {DmdcGroups.REQUESTS, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Admin Requests] [api/requests/fields]" +
                    "To get the details of the default search criteria fields with invalid header cookie"
    )
    @TestDoc(externalIds = { @ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-710") })
    public void testRequestsFieldsWithInvalidCookie() {

        DmdcAdminClient.getRequestsFields()
                .invalidDmdStatsAuthAndContracts(TestUser.INVALID_DMDSTATS)
                .execute();
    }
}