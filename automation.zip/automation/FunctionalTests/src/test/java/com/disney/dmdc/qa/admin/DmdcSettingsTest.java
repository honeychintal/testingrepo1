package com.disney.dmdc.qa.admin;

import com.disney.dmdc.qa.client.DmdcAdminClient;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.factory.AdminSettingsResponseFactory;
import com.disney.dmdc.qa.model.AdminSettingsGetResponse;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.groups.TestGroups;
import org.testng.annotations.Test;

public class DmdcSettingsTest {

    private static final TestUserCache testUserCache = new TestUserCache();
    private static final TestUser adminUser = testUserCache.getTestUserFromConfig(
            TestUserCache.ADMIN_DMDC_API_AUTOMATION_USER_KEY);

    @Test(
            groups = {DmdcGroups.SETTINGS, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Admin Settings] [/api/settings] Test To get the information about Dmdc Central Admin page settings"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-656")})
    public void testSettings() {

        AdminSettingsGetResponse expectedResponse = AdminSettingsResponseFactory.createDefaultResponse();

        DmdcAdminClient.getSettings()
                .authenticationDmdStatsOnly(adminUser.getDmdstats())
                .contract(ContractBody.builder()
                        .jsonEquals(expectedResponse)
                        .build()
                )
                .execute()
                .as(AdminSettingsGetResponse.class);
    }

    @Test(
            groups = {DmdcGroups.SETTINGS, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Admin Settings] [/api/settings] Test settings without header cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-657")})
    public void testSettingsWithoutCookie(){

        DmdcAdminClient.getSettings()
                .dmdstatsContractsAndNoAuth()
                .execute();
    }

    @Test(
            groups = {DmdcGroups.SETTINGS, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Admin Settings] [/api/settings] Test settings with invalid header cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-660")})
    public void testSettingsWithInvalidCookie(){

        DmdcAdminClient.getSettings()
                .invalidDmdStatsAuthAndContracts(TestUser.INVALID_DMDSTATS)
                .execute();
    }
}
