package com.disney.dmdc.qa.admin;

import com.disney.dmdc.qa.client.DmdcAdminClient;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.constant.RequestIds;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.data.TestUserCommentsData;
import com.disney.dmdc.qa.data.TestUserData;
import com.disney.dmdc.qa.factory.UserCommentsFactory;
import com.disney.dmdc.qa.model.UserCommentsResponse;
import com.disney.dmdc.qa.model.UserCommentsResult;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.groups.TestGroups;
import org.testng.annotations.Test;

public class DmdcUserCommentsTest {

    private static final TestUserCache testUserCache = new TestUserCache();
    private static final TestUser adminUser = testUserCache
            .getTestUserFromConfig(TestUserCache.ADMIN_DMDC_API_AUTOMATION_USER_KEY);


    @Test(
            groups = {DmdcGroups.MEMBERSHIP_USER, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Admin Membership User][/api/membership/user/<userid>/comments] Get user comments"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-725")})
    public void testActiveWithUserComments() {

        int userId = TestUserData.ACTIVE_USER_ID.getUserId();

        UserCommentsResult userCommentsResult = TestUserCommentsData.getUserComments();

        executeUserComments(
                userId,
                userId,
                RequestIds.DEFAULT,
                userCommentsResult
        );
    }

    @Test(
            groups = {DmdcGroups.MEMBERSHIP_USER, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Admin Membership User][/api/membership/user/<userid>/comments] Get user comments with user having no comments"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-836")})
    public void testActiveUserWithoutComments() {

        int userId = TestUserData.ACTIVE_USER_ID_NO_COMMENTS.getUserId();

        UserCommentsResult userCommentsResult = TestUserCommentsData.getEmptyComments();

        executeUserComments(
                userId,
                userId,
                RequestIds.DEFAULT,
                userCommentsResult
        );
    }

    @Test(
            groups = {DmdcGroups.MEMBERSHIP_USER, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Admin Membership User][/api/membership/user/<userid>/comments] Get user comments with inactive user"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-837")})
    public void testInactiveUserComments() {

        int userId = TestUserData.INACTIVE_USER_ID.getUserId();

        UserCommentsResult userCommentsResult = TestUserCommentsData.getEmptyComments();

        executeUserComments(
                userId,
                userId,
                RequestIds.DEFAULT,
                userCommentsResult
        );
    }

    @Test(
            groups = {DmdcGroups.MEMBERSHIP_USER, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Admin Membership User][/api/membership/user/<userid>/comments] Get user comments with disabled user"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-838")})
    public void testIDisabledUserComments() {

        int userId = TestUserData.DISABLED_USER_ID.getUserId();

        UserCommentsResult userCommentsResult = TestUserCommentsData.getEmptyComments();

        executeUserComments(
                userId,
                userId,
                RequestIds.DEFAULT,
                userCommentsResult
        );
    }

    @Test(
            groups = {DmdcGroups.MEMBERSHIP_USER, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Admin Membership User][/api/membership/user/<userid>/comments] Get user comments with terminated user"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-839")})
    public void testTerminatedUserComments() {

        int userId = TestUserData.TERMINATED_USER_ID.getUserId();

        UserCommentsResult userCommentsResult = TestUserCommentsData.getEmptyComments();

        executeUserComments(
                userId,
                userId,
                RequestIds.DEFAULT,
                userCommentsResult
        );
    }

    @Test(
            groups = {DmdcGroups.MEMBERSHIP_USER, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Admin Membership User][/api/membership/user/<userid>/comments] Get user comments with invalid cookie header"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-740")})
    public void testUserCommentsWithInvalidHeaderCookie() {

        int userId = TestUserData.ACTIVE_USER_ID.getUserId();

        DmdcAdminClient.getUserComments(userId, userId, RequestIds.DEFAULT)
                .invalidDmdStatsAuthAndContracts(TestUser.INVALID_DMDSTATS)
                .execute();
    }

    @Test(
            groups = {DmdcGroups.MEMBERSHIP_USER, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Admin Membership User][/api/membership/user/<userid>/comments] Get user comments without cookie header"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-738")})
    public void testUserCommentsWithOutHeaderCookie() {

        int userId = TestUserData.ACTIVE_USER_ID.getUserId();

        DmdcAdminClient.getUserComments(userId, userId, RequestIds.DEFAULT)
                .dmdstatsContractsAndNoAuth()
                .execute();
    }

    public void executeUserComments(
            int userId, int id, int requestId, UserCommentsResult userCommentsResult) {

        UserCommentsResponse expectedResponse = UserCommentsFactory
                .testUserCommentsResponse(userCommentsResult);


        DmdcAdminClient.getUserComments(userId, id, requestId)
                .authenticationDmdStatsOnly(adminUser.getDmdstats())
                .contract(
                        ContractBody.builder()
                                .jsonEquals(expectedResponse)
                                .build())
                .execute();
    }

}
