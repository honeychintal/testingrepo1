package com.disney.dmdc.qa.admin;

import com.disney.dmdc.qa.client.DmdcAdminClient;
import com.disney.dmdc.qa.constant.DmdcGroups;
import com.disney.dmdc.qa.constant.RequestIds;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.dmdc.qa.data.TestUserData;
import com.disney.dmdc.qa.data.TestUserRequestSummaryResultData;
import com.disney.dmdc.qa.factory.UserRequestSummaryResponseFactory;
import com.disney.dmdc.qa.model.UserRequestSummaryResponse;
import com.disney.dmdc.qa.model.UserRequestSummaryResult;
import com.disney.dmdc.qa.util.TestUserCache;
import com.disney.qa.automation.ExternalId;
import com.disney.qa.automation.TestDoc;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.groups.TestGroups;
import org.testng.annotations.Test;

public class DmdcUserRequestSummaryTest {

    private static final TestUserCache testUserCache = new TestUserCache();
    private static final TestUser adminUser = testUserCache
            .getTestUserFromConfig(TestUserCache.ADMIN_DMDC_API_AUTOMATION_USER_KEY);

    @Test(
            groups = {DmdcGroups.MEMBERSHIP_USER, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Admin Membership User][api/membership/user/<userid>/requestsummary/]Test To " +
                    "Retrieve requestsummary details of an admin user"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-910")})
    public void testUserRequestSummaryDetails() {

        int userId = TestUserData
                .ACTIVE_USER_ID
                .getUserId();

        UserRequestSummaryResult userRequestSummaryResult = TestUserRequestSummaryResultData
                .getTestUserRequestSummary();

        executeUserRequestSummary(
                userId,
                userId,
                RequestIds.DEFAULT,
                userRequestSummaryResult
        );
    }

    @Test(
            groups = {DmdcGroups.MEMBERSHIP_USER, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Admin Membership User][api/membership/user/<userid>/requestsummary]To Test " +
                    "requestsummary details by providing Inactive userId as path parameter"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-1046")})
    public void testInactiveUserRequestSummary() {

        int userId = TestUserData
                .INACTIVE_USER_ID
                .getUserId();

        UserRequestSummaryResult userRequestSummaryResult = TestUserRequestSummaryResultData
                .getInactiveUserRequestSummary();

        executeUserRequestSummary(
                userId,
                userId,
                RequestIds.DEFAULT,
                userRequestSummaryResult
        );
    }

    @Test(
            groups = {DmdcGroups.MEMBERSHIP_USER, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Admin Membership User][api/membership/user/<userid>/requestsummary]To Test " +
                    "requestsummary details by providing Terminated userId as path parameter"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-1047")})
    public void testTerminatedUserRequestSummary() {

        int userId = TestUserData
                .TERMINATED_USER_ID
                .getUserId();

        UserRequestSummaryResult userRequestSummaryResult = TestUserRequestSummaryResultData
                .getTerminatedUserRequestSummary();

        executeUserRequestSummary(
                userId,
                userId,
                RequestIds.DEFAULT,
                userRequestSummaryResult
        );
    }

    @Test(
            groups = {DmdcGroups.MEMBERSHIP_USER, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Admin Membership User][api/membership/user/<userid>/requestsummary]To Test" +
                    " requestsummary details by providing Disabled userId as path parameter"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-1048")})
    public void testDisabledUserRequestSummary() {

        int userId = TestUserData
                .DISABLED_USER_ID
                .getUserId();

        UserRequestSummaryResult userRequestSummaryResult = TestUserRequestSummaryResultData
                .getDisabledUserRequestSummary();

        executeUserRequestSummary(
                userId,
                userId,
                RequestIds.DEFAULT,
                userRequestSummaryResult
        );
    }

    @Test(
            groups = {DmdcGroups.MEMBERSHIP_USER, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Admin Membership User][api/membership/user/<userid>/requestsummary/]Test to " +
                    "retrieve requestsummary details with the user not having access to admin"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-1049")})
    public void testUserRequestSummaryNonAdminUser() {

        int userId = TestUserData
                .ACTIVE_USER_ID
                .getUserId();

        TestUser marketingTvdHeUser = testUserCache
                .getTestUserFromConfig(TestUserCache.MARKETING_TVD_HE_USER_KEY);

        DmdcAdminClient.getUserRequestSummary(userId,
                userId,
                RequestIds.DEFAULT
        )
                .forbiddenDmdStatsContract(marketingTvdHeUser.getDmdstats())
                .execute();
    }

    @Test(
            groups = {DmdcGroups.MEMBERSHIP_USER, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Admin Membership User][api/membership/user/<userid>/requestsummary/]Test" +
                    "requestsummary details with invalid dmdstats Header Cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-917")})
    public void testUserRequestSummaryWithInvalidHeaderCookie() {

        int userId = TestUserData.ACTIVE_USER_ID_NO_COMMENTS.getUserId();

        DmdcAdminClient.getUserRequestSummary(userId, userId, RequestIds.DEFAULT)
                .invalidDmdStatsAuthAndContracts(TestUser.INVALID_DMDSTATS)
                .execute();
    }

    @Test(
            groups = {DmdcGroups.MEMBERSHIP_USER, TestGroups.BVT, DmdcGroups.XRAY, DmdcGroups.P1},
            description = "[Admin Membership User][api/membership/user/<userid>/requestsummary/]Test" +
                    "requestsummary details without dmdstats Header Cookie"
    )
    @TestDoc(externalIds = {@ExternalId(externalSystemName = "XRAY", externalSystemId = "GUNRAY-913")})
    public void testUserRequestSummaryWithOutHeaderCookie() {

        int userId = TestUserData.ACTIVE_USER_ID_NO_COMMENTS.getUserId();


        DmdcAdminClient.getUserRequestSummary(userId, userId, RequestIds.DEFAULT)
                .dmdstatsContractsAndNoAuth()
                .execute();
    }

    public void executeUserRequestSummary(
            int userId, int id, int requestId, UserRequestSummaryResult userRequestSummaryResult) {

        UserRequestSummaryResponse expectedResponse = UserRequestSummaryResponseFactory
                .testUserRequestSummaryResponse(userRequestSummaryResult);

        DmdcAdminClient.getUserRequestSummary(userId, id, requestId)
                .authenticationDmdStatsOnly(adminUser.getDmdstats())
                .contract(
                        ContractBody.builder()
                                .jsonEquals(expectedResponse)
                                .build())
                .execute();
    }

}
