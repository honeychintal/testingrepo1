# DMDCMaraJade

This repo contains the DMDC backend automation, developed for the Mara Jade platform.  These tests include Json Schema,
Status code, and header checks for all environments.  In the lower environments, a comparison of responses to backend
Stored Procedures is also done.  Some tests where DB comparison is unavailable use comparison to static data.

To run these tests requires the Whistler AES decryption key set/export as the environment variable DMDC_DECRYPTION_KEY.
This key can be found in the shared Last Pass space "Shared-DMDC/Productivity Engineering" as "(AES) DMDC Whistler Decryption Key".
Once you have set (Windows) or export (Mac/Linux) this variable, you can run the tests with:

`mvn test`

## Test environments

The currently available environments are "qa", "dev", and "pre".  The environment can be
chosen using `-Dtestenv=` argument such as `-Dtestenv=dev`.  The default environment is
"qa" if testenv is not specified.

The configuration file contains "common" sections for settings common to all test environments,
but settings can also be done on a per environment basis by updating the corresponding
section in dmdcapi.conf.

## Configuration

Tests are configured via the file `TestResources/src/main/resources/config/apps/dmdcapi.conf`.

Notable sections:

* services - Client configuration, primarily for the host url.
* propertyCollections - Other settings not related to the service.
* propertyTransformers - Whistler transformer configuration for encrypted settings.
* users - Test account details with encrypted `dmdstats` for connection.  These
  users are the context under which the tests will run.
* testData - Known ids for items existing in the db having specific properties.
* reporting - Connection details for the 3 different reporting listeners.
* db - Connection details for comparison of responses to the database.
* compareResponsesToBackendDatabase - true/false flag to indicate whether comparison to
  the backend database should occur.  This is false for higher environments as no backend
  connection is available.
* obfuscations - Regular expression statements to hide sensitive data in the logs.
* encryptedValue - Represents a value to be decrypted by the Whistler transformer.


## Reporting

Reporting can be done to 3 different sources using TestNG listeners:

* Gunray/Xray - com.disney.dmdc.qa.xray.XRayListener
* TRS - com.disney.dmdc.qa.trs.OutriderListener
* ReportPortal - com.disney.dmdc.qa.reportportal.ReportPortalListener

Listeners can be attached using the `-Dlistener=` argument:

`mvn test -Dlistener=com.disney.dmdc.qa.xray.XRayListener,com.disney.dmdc.qa.trs.OutriderListener,com.disney.dmdc.qa.reportportal.ReportPortalListener`

There are also some TestNG suite files for using these listeners:
`mvn test -Dsurefire.suiteXmlFiles=src/test/resources/suites/ReportPortalTestSuite.xml`

## More info

* DMDC home: https://confluence.disney.com/display/DMDC
* DMDC/productivity Engineering home: https://confluence.disney.com/pages/viewpage.action?pageId=561716768
* Technical document: https://confluence.disney.com/display/PPBPE/DMDC+Quality+and+Productivity+Improvement%3A+Technical+Document
* Mara Jade: https://confluence.disney.com/display/PPBPE/Mara+Jade
* Whistler encryption: https://confluence.disney.com/display/PPBPE/Whistler+-+Encryption+and+Decryption+Utility+for+Tests