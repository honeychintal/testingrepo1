package com.disney.dmdc.qa.client;

import com.disney.dmdc.qa.constant.DmdcHeaders;
import com.disney.dmdc.qa.constant.JsonSchemaPaths;
import com.disney.dmdc.qa.request.MarketingDifRequest;
import com.disney.qa.contract.ContractHeaders;
import com.disney.qa.contract.ContractJsonSchema;

import javax.ws.rs.core.MediaType;

public class DifMarketingClient extends DmdcBaseClient {

    public static final String NEWS_PATH = "/api/portal/news";
    public static final String SPOTLIGHT_PATH = "/api/portal/spotlight";
    public static final String TITLE_ADDITIONAL_DATA_GET_PATH = "/api/portal/title/{titleId}/additionaldata";

    public static final ContractHeaders DEFAULT_HEADER_CONTRACT = ContractHeaders.builder()
            .expectedHeaders(DmdcHeaders.EXPECTED_COMMON)
            .ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
            .build();

    public static MarketingDifRequest getNews(){

        return new MarketingDifRequest()
                .get()
                .path(NEWS_PATH)
                .contentType(MediaType.APPLICATION_JSON)
                .accepts(MediaType.APPLICATION_JSON)
                .contract(DEFAULT_STATUS_CODE_CONTRACT)
                .contract(ContractHeaders.builder()
                        .expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
                        .ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
                        .build()
                );
    }

    public static MarketingDifRequest getSpotlight(){

        return new MarketingDifRequest()
                .get()
                .path(SPOTLIGHT_PATH)
                .contentType(MediaType.APPLICATION_JSON)
                .accepts(MediaType.APPLICATION_JSON)
                .contract(DEFAULT_STATUS_CODE_CONTRACT)
                .contract(ContractHeaders.builder()
                        .expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
                        .ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
                        .build()
                );
    }

    /** Creates a base request for GET to "/api/portal/title/{titleId}/additionalData".
     * @param titleId The GUID associated with the title
     * @return A request object with typical status code and header contracts.
     */
    public static MarketingDifRequest getAdditionalData(String titleId){

        return new MarketingDifRequest()
                .get()
                .path(TITLE_ADDITIONAL_DATA_GET_PATH, titleId)
                .contentType(MediaType.APPLICATION_JSON)
                .accepts(MediaType.APPLICATION_JSON)
                .contract(DEFAULT_STATUS_CODE_CONTRACT)
                .contract(ContractHeaders.builder()
                        .expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
                        .ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
                        .build()
                )
                .contract(ContractJsonSchema.builder()
                        .jsonSchemaPath(JsonSchemaPaths.TITLE_ADDITIONAL_DATA)
                        .build()
                );
    }
}
