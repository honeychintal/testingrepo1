package com.disney.dmdc.qa.client;

import com.disney.dmdc.qa.constant.DmdcHeaders;
import com.disney.dmdc.qa.constant.JsonSchemaPaths;
import com.disney.dmdc.qa.constant.QueryParams;
import com.disney.dmdc.qa.model.TitleAvailabilityDataElement;
import com.disney.dmdc.qa.request.AdminDmdcRequest;
import com.disney.qa.contract.ContractHeaders;
import com.disney.qa.contract.ContractJsonSchema;

import javax.ws.rs.core.MediaType;
import java.util.List;

public class DmdcAdminClient extends DmdcBaseClient {

	public static final String TOP_LEVEL_HTML_PATH = "";
	public static final String TITLE_AVAILABILITY_GET_PATH = "api/title/{titleId}/availability";
	public static final String TITLE_AVAILABILITY_POST_PATH = "api/title/availability";
	public static final String LOOKUP_MEMBERSHIP_TERRITORIES_PATH = "/api/lookup/membership/territories";
	public static final String MEMBERSHIP_USER_FIELDS_PATH = "/api/membership/user/fields";
	public static final String REQUESTS_FIELDS_PATH = "api/requests/fields";
	public static final String LOOKUP_DISTRIBUTION_GROUP_PATH = "api/lookup/distributionGroup";
	public static final String MEMBERSHIP_GROUP_FIELDS_PATH = "api/membership/group/fields";
	public static final String LOOKUP_GROUP_STATUS_PATH = "api/lookup/group/status";
	public static final String TITLE_FIELDS_PATH = "/api/title/fields";
	public static final String USER_REQUEST_SUMMARY_PATH = "api/membership/user/{userId}/requestsummary";
	public static final String NAV_GET_PATH = "api/nav/get";
	public static final String SETTINGS_PATH = "api/settings";
	public static final String USER_COMMANDS_PATH = "api/membership/user/{USERId}/commands";
	public static final String MEMBERSHIP_USERID_PATH = "api/membership/user/{userId}";
	public static final String MEMBERSHIP_USER_GROUPS_PATH = "api/membership/user/{userId}/groups";
	public static final String USER_COMMENTS_PATH = "api/membership/user/{userId}/comments";

	public static AdminDmdcRequest getTopLevelHtml() {
		return new AdminDmdcRequest()
				.get()
				.path(TOP_LEVEL_HTML_PATH)
				.contract(DEFAULT_STATUS_CODE_CONTRACT);
	}

	public static AdminDmdcRequest getTitleAvailability(String titleId){

		return new AdminDmdcRequest()
				.get()
				.path(TITLE_AVAILABILITY_GET_PATH, titleId)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_TITLE_AVAILABILITY)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
						.build()
				);
	}

	public static AdminDmdcRequest getTitleAvailability(String titleId, int distributionUnitId, int localId, int productType) {
		return DmdcAdminClient.getTitleAvailability(titleId)
				.parameter(QueryParams.ID, titleId)
				.parameter(QueryParams.DISTRIBUTION_UNIT_ID, distributionUnitId)
				.parameter(QueryParams.LOCAL_ID, localId)
				.parameter(QueryParams.PRODUCT_TYPE, productType);
	}

	public static AdminDmdcRequest postTitleAvailability(){

		return new AdminDmdcRequest()
				.post()
				.path(TITLE_AVAILABILITY_POST_PATH)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_COMMON_ADMIN)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
						.build()
				);
	}

	public static AdminDmdcRequest postTitleAvailability(int distributionUnitId, List<TitleAvailabilityDataElement> body){

		return postTitleAvailability()
				.parameter(QueryParams.DISTRIBUTION_UNIT_ID, distributionUnitId)
				.body(body);
	}

	public static AdminDmdcRequest getLookupMembershipTerritories() {

		return new AdminDmdcRequest()
				.get()
				.path(LOOKUP_MEMBERSHIP_TERRITORIES_PATH)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
						.build()
				);
	}

	public static AdminDmdcRequest getMembershipUserFields() {

		return new AdminDmdcRequest()
				.get()
				.path(MEMBERSHIP_USER_FIELDS_PATH)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
						.build()
				);
	}

	public static AdminDmdcRequest getRequestsFields(){

		return new AdminDmdcRequest()
				.get()
				.path(REQUESTS_FIELDS_PATH)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
						.build()
				)
				.contract(ContractJsonSchema.builder()
						.jsonSchemaPath(JsonSchemaPaths.REQUESTS_FIELDS)
						.build()
				);
	}

	public static AdminDmdcRequest getLookupDistributionGroup(){

		return new AdminDmdcRequest()
				.get()
				.path(LOOKUP_DISTRIBUTION_GROUP_PATH)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
						.build()
				);
	}

	public static AdminDmdcRequest getMembershipGroupFields(){

		return new AdminDmdcRequest()
				.get()
				.path(MEMBERSHIP_GROUP_FIELDS_PATH)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
						.build()
				)
				.contract(ContractJsonSchema.builder()
						.jsonSchemaPath(JsonSchemaPaths.MEMBERSHIP_GROUP_FIELDS)
						.build()
				);
	}

	public static AdminDmdcRequest getLookupGroupStatus(){

		return new AdminDmdcRequest()
				.get()
				.path(LOOKUP_GROUP_STATUS_PATH)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
						.build()
				);
	}

	public static AdminDmdcRequest getTitleFields(){
		return new AdminDmdcRequest()
				.get()
				.path(TITLE_FIELDS_PATH)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
						.build()
				);
	}

	public static AdminDmdcRequest getUserRequestSummary(Integer userId){

		return new AdminDmdcRequest()
				.get()
				.path(USER_REQUEST_SUMMARY_PATH,userId)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
						.build()
				)
				.contract(ContractJsonSchema.builder()
						.jsonSchemaPath(JsonSchemaPaths.USER_REQUEST_SUMMARY)
						.build()
				);
	}

	public static AdminDmdcRequest getUserRequestSummary(Integer userId, Integer id, Integer requestId){

		return getUserRequestSummary(userId)
				.parameter(QueryParams.ID, id)
				.parameter(QueryParams.REQUEST_ID, requestId);
	}

	public static AdminDmdcRequest getNavGet(){

		return new AdminDmdcRequest()
				.get()
				.path(NAV_GET_PATH)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
						.build()
				);
	}
	public static AdminDmdcRequest getSettings() {
		return new AdminDmdcRequest()
				.get()
				.path(SETTINGS_PATH)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
						.build()
				);
	}

	public static AdminDmdcRequest getUserCommands(Integer userId){

		return new AdminDmdcRequest()
				.get()
				.path(USER_COMMANDS_PATH, userId)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
						.build()
				)
				.contract(ContractJsonSchema.builder()
						.jsonSchemaPath(JsonSchemaPaths.MEMBERSHIP_USER_COMMANDS)
						.build()
				);
	}

	public static AdminDmdcRequest getUserId(Integer userId) {

		return new AdminDmdcRequest()
				.get()
				.path(MEMBERSHIP_USERID_PATH, userId)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
						.build()
				)
				.contract(ContractJsonSchema.builder()
						.jsonSchemaPath(JsonSchemaPaths.MEMBERSHIP_USERID)
						.build()
				);
	}

	public static AdminDmdcRequest getUserId(int userId, int id, int requestId) {

		return getUserId(userId)
				.parameter(QueryParams.ID, id)
				.parameter(QueryParams.REQUEST_ID, requestId);
	}

	public static AdminDmdcRequest getUserGroups(Integer userId) {

		return new AdminDmdcRequest()
				.get()
				.path(MEMBERSHIP_USER_GROUPS_PATH, userId)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
						.build()
				)
				.contract(ContractJsonSchema.builder()
						.jsonSchemaPath(JsonSchemaPaths.MEMBERSHIP_USER_GROUPS)
						.build()
				);
	}

	public static AdminDmdcRequest getUserGroups(Integer userId, Integer id, Integer pageIndex) {

		return getUserGroups(userId)
				.parameter(QueryParams.ID, id)
				.parameter(QueryParams.PAGE_INDEX, pageIndex);
	}

	public static AdminDmdcRequest getUserComments(Integer userId){

		return new AdminDmdcRequest()
				.get()
				.path(USER_COMMENTS_PATH,userId)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
						.build()
				);
	}

	public static AdminDmdcRequest getUserComments(Integer userId, Integer id, Integer requestId){

		return getUserComments(userId)
				.parameter(QueryParams.ID, id)
				.parameter(QueryParams.REQUEST_ID, requestId);
	}

}
