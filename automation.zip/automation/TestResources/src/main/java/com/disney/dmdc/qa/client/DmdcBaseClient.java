package com.disney.dmdc.qa.client;

import com.disney.qa.contract.ContractStatusCodes;

import javax.ws.rs.core.Response.Status;

public class DmdcBaseClient {
	
	public static final ContractStatusCodes DEFAULT_STATUS_CODE_CONTRACT = ContractStatusCodes.buildStatusCodeContract(Status.OK.getStatusCode());
	public static final ContractStatusCodes UNAUTHORIZED_STATUS_CODE = ContractStatusCodes.buildStatusCodeContract(Status.UNAUTHORIZED.getStatusCode());
	public static final ContractStatusCodes FORBIDDEN_STATUS_CODE = ContractStatusCodes.buildStatusCodeContract(Status.FORBIDDEN.getStatusCode());
	public static final ContractStatusCodes BAD_REQUEST_STATUS_CODE = ContractStatusCodes.buildStatusCodeContract(Status.BAD_REQUEST.getStatusCode());
}
