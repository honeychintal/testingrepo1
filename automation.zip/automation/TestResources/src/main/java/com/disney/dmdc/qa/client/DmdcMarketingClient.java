package com.disney.dmdc.qa.client;

import com.disney.dmdc.qa.constant.DmdcHeaders;
import com.disney.dmdc.qa.constant.JsonSchemaPaths;
import com.disney.dmdc.qa.constant.QueryParams;
import com.disney.dmdc.qa.model.LocalNamesRequest;
import com.disney.dmdc.qa.model.TitleSearchRequest;
import com.disney.dmdc.qa.model.PortalTitleSuggestRequest;
import com.disney.dmdc.qa.request.MarketingDmdcRequest;
import com.disney.qa.contract.ContractHeaders;
import com.disney.qa.contract.ContractJsonSchema;
import com.google.common.net.HttpHeaders;

import javax.ws.rs.core.MediaType;

public class DmdcMarketingClient extends DmdcBaseClient {

	public static final String TOP_LEVEL_HTML_PATH = "";
	public static final String SETTINGS_PATH = "/api/settings";
	public static final String TITLE_LOCAL_NAMES_PATH = "/api/portal/title/{titleId}/localnames";
	public static final String TITLE_AVAILABILITY_GET_PATH = "/api/portal/title/{titleId}/availability";
	public static final String CATEGORY_ID_PATH = "/api/portal/category/{categoryId}";
	public static final String TITLE_HEADER_PATH = "/api/portal/title/{titleId}/header";
	public static final String PORTAL_NAV_MENU_GET_PATH = "/api/portal/nav/menu";
	public static final String PORTAL_SEARCH_GET = "/api/portal/search/get";
	public static final String TITLE_LOCALS_GET_PATH = "/api/portal/title/{titleId}/locals";
	public static final String ASSET_AUDIO_CHANNELS_PATH = "/api/portal/asset/{assetId}/quickview/audiochannels";
	public static final String TITLE_HIERARCHY_PATH = "/api/portal/title/{titleId}/hierarchy";
	public static final String ASSET_INFO_PATH = "/api/portal/asset/{assetId}/quickview/info";
	public static final String TITLE_TABS_PATH = "/api/portal/title/{titleId}/tabs";
	public static final String TITLE_AWARDS_GET_PATH = "/api/portal/title/{titleId}/awards";
	public static final String TITLE_TALENTS_PATH = "api/portal/title/{titleId}/talents";
	public static final String TITLE_QUOTES_PATH = "/api/portal/title/{titleId}/quotes";
	public static final String PLAYBACK_SESSION_GET_PATH = "/api/portal/playback/session";
	public static final String PORTAL_SEARCH_TABS = "/api/portal/search/tabs";
	public static final String CATEGORY_PATH = "/api/portal/category";
	public static final String TITLE_QUICKVIEW_PATH = "/api/portal/title/{titleId}/quickview";
	public static final String TITLE_LICENSES_PATH = "/api/portal/title/{titleId}/licenses";
	public static final String TITLE_ADDITIONALCREW="/api/portal/title/{titleId}/additionalcrew";
	public static final String TITLE_ADDITIONAL_CAST = "/api/portal/title/{titleid}/additionalcast";
	public static final String TITLE_SEARCH_PATH = "/api/portal/title/search";
	public static final String PORTAL_TITLE_SUGGEST_POST_PATH= "/api/portal/title/suggest";

	public static final ContractHeaders DEFAULT_HEADER_CONTRACT = ContractHeaders.builder()
			.expectedHeaders(DmdcHeaders.EXPECTED_COMMON)
			.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
			.build();

	public static MarketingDmdcRequest getTopLevelHtml() {
		return new MarketingDmdcRequest()
				.get()
				.path(TOP_LEVEL_HTML_PATH)
				.contract(DEFAULT_STATUS_CODE_CONTRACT);
	}

	public static MarketingDmdcRequest getSettings() {
		return new MarketingDmdcRequest()
				.get()
				.path(SETTINGS_PATH)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_SETTINGS)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
						.build()
				)
				.contract(ContractJsonSchema.builder()
						.jsonSchemaPath(JsonSchemaPaths.MARKETING_SETTINGS)
						.build()
				);
	}

	/** Creates a base request for POST to "/api/portal/title/{titleId}/localnames".
	 * @param titleId The GUID associated with the title
	 * @return A request object with typical status code and header contracts.
	 */
	public static MarketingDmdcRequest getTitleLocalNames(String titleId){
		return new MarketingDmdcRequest()
				.post()
				.path(TITLE_LOCAL_NAMES_PATH, titleId)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(DEFAULT_HEADER_CONTRACT);
	}

	public static MarketingDmdcRequest getTitleLocalNames(String titleId, LocalNamesRequest body){
		return DmdcMarketingClient.getTitleLocalNames(titleId)
				.body(body);
	}

	public static MarketingDmdcRequest getTitleAvailability(String titleId){

		return new MarketingDmdcRequest()
				.get()
				.path(TITLE_AVAILABILITY_GET_PATH, titleId)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
						.build()
				)
				.contract(ContractJsonSchema.builder()
						.jsonSchemaPath(JsonSchemaPaths.TITLE_AVAILABILITY)
						.build()
				);
	}

	public static MarketingDmdcRequest getCategoryId(String categoryId){

		return new MarketingDmdcRequest()
				.get()
				.path(CATEGORY_ID_PATH, categoryId)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
						.build()
				)
				.contract(ContractJsonSchema.builder()
						.jsonSchemaPath(JsonSchemaPaths.CATEGORY_ID)
						.build()
				);
	}

	public static MarketingDmdcRequest getTitleHeader(String titleId){

		return new MarketingDmdcRequest()
				.get()
				.path(TITLE_HEADER_PATH, titleId)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
						.build()
				)
				.contract(ContractJsonSchema.builder()
						.jsonSchemaPath(JsonSchemaPaths.TITLE_HEADER)
						.build()
				);
	}

	public static MarketingDmdcRequest getTitleHeader(String titleId, int distributionUnitId, int localId){

		return DmdcMarketingClient.getTitleHeader(titleId)
				.parameter(QueryParams.DISTRIBUTION_UNIT_ID, distributionUnitId)
				.parameter(QueryParams.LOCAL_ID, localId);
	}

	public static MarketingDmdcRequest getPortalSearchGet() {

		return new MarketingDmdcRequest()
				.get()
				.path(PORTAL_SEARCH_GET)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
						.build()
				);
	}

		public static MarketingDmdcRequest getAssetAudioChannels(Integer assetId){

		return new MarketingDmdcRequest()
				.get()
				.path(ASSET_AUDIO_CHANNELS_PATH, assetId)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
						.build()
				)
				.contract(ContractJsonSchema.builder()
						.jsonSchemaPath(JsonSchemaPaths.ASSET_AUDIO_CHANNELS)
						.build()
				);
	}

	public static MarketingDmdcRequest getPortalNavMenu(){

		return new MarketingDmdcRequest()
				.get()
				.path(PORTAL_NAV_MENU_GET_PATH)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
						.build()
				).contract(ContractJsonSchema.builder()
						.jsonSchemaPath(JsonSchemaPaths.PORTAL_NAV_MENU)
						.build()
				);
	}

	/** Creates a base request for POST to "/api/portal/title/{titleId}/locals".
	 * @param titleId The GUID associated with the title
	 * @return A request object with typical status code and header contracts.
	 */
	public static MarketingDmdcRequest getTitleLocals(String titleId) {
		return new MarketingDmdcRequest()
				.get()
				.path(TITLE_LOCALS_GET_PATH, titleId)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
						.build()
				)
				.contract(ContractJsonSchema.builder()
						.jsonSchemaPath(JsonSchemaPaths.TITLE_LOCALS)
						.build()
				);
	}

	public  static MarketingDmdcRequest getTitleLocals(String titleId, int distributionUnitId) {
		return DmdcMarketingClient.getTitleLocals(titleId)
				.parameter(QueryParams.DISTRIBUTION_UNIT_ID, distributionUnitId);
	}

	public static MarketingDmdcRequest getTitleHierarchy(String titleId) {

		return new MarketingDmdcRequest()
				.get()
				.path(TITLE_HIERARCHY_PATH, titleId)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
						.ignoredHeader(HttpHeaders.CACHE_CONTROL)
						.ignoredHeader(HttpHeaders.EXPIRES)
						.build()
				)
				.contract(ContractJsonSchema.builder()
				.jsonSchemaPath(JsonSchemaPaths.TITLE_HIERARCHY)
				.build()
		);
	}

	public static MarketingDmdcRequest getTitleHierarchy(String titleId, int distributionUnitId){

		return DmdcMarketingClient.getTitleHierarchy(titleId)
				.parameter(QueryParams.DISTRIBUTION_UNIT_ID, distributionUnitId);
	}

	public static MarketingDmdcRequest getAssetInfo(String assetId){

		return new MarketingDmdcRequest()
				.get()
				.path(ASSET_INFO_PATH, assetId)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
						.build()
				)
				.contract(ContractJsonSchema.builder()
						.jsonSchemaPath(JsonSchemaPaths.ASSET_QUICKVIEW_INFO)
						.build()
				);
	}

    public static MarketingDmdcRequest getTitleTabs(String titleId) {

        return new MarketingDmdcRequest()
                .get()
                .path(TITLE_TABS_PATH, titleId)
                .contentType(MediaType.APPLICATION_JSON)
                .accepts(MediaType.APPLICATION_JSON)
                .contract(DEFAULT_STATUS_CODE_CONTRACT)
                .contract(ContractHeaders.builder()
                        .expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
                        .ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
                        .build()
                )
				.contract(ContractJsonSchema.builder()
						.jsonSchemaPath(JsonSchemaPaths.TITLE_TABS)
						.build()
				);
    }

    public static MarketingDmdcRequest getTitleTabs(String titleId, String id, int distributionUnitId) {

        return DmdcMarketingClient.getTitleTabs(titleId)
                .parameter(QueryParams.DISTRIBUTION_UNIT_ID, distributionUnitId)
                .parameter(QueryParams.ID, id);
    }

	/** Creates a base request for GET to "/api/portal/title/{titleId}/awards".
	 * @param titleId The GUID associated with the title
	 * @return A request object with typical status code and header contracts.
	 */
	public static MarketingDmdcRequest getTitleAwards(String titleId) {
		return new MarketingDmdcRequest()
				.get()
				.path(TITLE_AWARDS_GET_PATH, titleId)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders
								.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
						.ignoredHeaders(DmdcHeaders
								.IGNORED_COMMON)
						.build()
				)
				.contract(ContractJsonSchema.builder()
						.jsonSchemaPath(JsonSchemaPaths.TITLE_AWARDS)
						.build()
				);
	}

	public  static MarketingDmdcRequest getTitleAwards(String titleId, int distributionUnitId) {
		return DmdcMarketingClient.getTitleAwards(titleId)
				.parameter(QueryParams.DISTRIBUTION_UNIT_ID, distributionUnitId);
	}

	public static MarketingDmdcRequest getTitleTalents(String titleId){
		return new MarketingDmdcRequest()
				.get()
				.path(TITLE_TALENTS_PATH, titleId)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
						.build()
				)
				.contract(ContractJsonSchema.builder()
						.jsonSchemaPath(JsonSchemaPaths.TITLE_TALENTS)
						.build()
				);
	}

	public static MarketingDmdcRequest getTitleTalents(String titleId, int localId){
		return DmdcMarketingClient.getTitleTalents(titleId)
				.parameter(QueryParams.LOCAL_ID,localId);
	}

	public static MarketingDmdcRequest getTitleQuotes(String titleId) {

		return new MarketingDmdcRequest()
				.get()
				.path(TITLE_QUOTES_PATH, titleId)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
						.build()
				)
				.contract(ContractJsonSchema.builder()
						.jsonSchemaPath(JsonSchemaPaths.TITLE_QUOTES)
						.build()
				);
	}

	public static MarketingDmdcRequest getTitleQuotes(String titleId, int distributionUnitId, int localId) {

		return DmdcMarketingClient.getTitleQuotes(titleId)
				.parameter(QueryParams.DISTRIBUTION_UNIT_ID, distributionUnitId)
				.parameter(QueryParams.LOCAL_ID, localId);
	}

	public static MarketingDmdcRequest getPlaybackSessionDetails() {
		return new MarketingDmdcRequest()
				.get()
				.path(PLAYBACK_SESSION_GET_PATH)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
						.build()
				)
				.contract(ContractJsonSchema.builder()
						.jsonSchemaPath(JsonSchemaPaths.PLAYBACK_SESSION)
						.build()
				);
	}

	public static MarketingDmdcRequest getPortalSearchTabs(){
		return new MarketingDmdcRequest()
				.get()
				.path(PORTAL_SEARCH_TABS)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
						.build()
				)
				.contract(ContractJsonSchema.builder()
						.jsonSchemaPath(JsonSchemaPaths.SEARCH_TABS)
						.build()
				);
	}

	public static MarketingDmdcRequest getCategory(){

		return new MarketingDmdcRequest()
				.get()
				.path(CATEGORY_PATH)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
						.build()
				)
				.contract(ContractJsonSchema.builder()
						.jsonSchemaPath(JsonSchemaPaths.CATEGORY)
						.build()
				);
	}

	public static MarketingDmdcRequest getCategory(String categoryMode){

		return DmdcMarketingClient.getCategory()
				.parameter(QueryParams.MODE, categoryMode);
	}

	public static MarketingDmdcRequest getTitleQuickView(String titleId){

		return new MarketingDmdcRequest()
				.get()
				.path(TITLE_QUICKVIEW_PATH, titleId)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
						.build()
				)
				.contract(ContractJsonSchema.builder()
						.jsonSchemaPath(JsonSchemaPaths.TITLE_QUICKVIEW)
						.build()
				);
	}

	public static MarketingDmdcRequest getTitleLicenses(String titleId) {
		return new MarketingDmdcRequest()
				.get()
				.path(TITLE_LICENSES_PATH, titleId)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
						.build()
				)
				.contract(ContractJsonSchema.builder()
						.jsonSchemaPath(JsonSchemaPaths.TITLE_LICENSE)
						.build()
				);
	}

	public static MarketingDmdcRequest getTitleAdditionalCrew(String titleId){
		return new MarketingDmdcRequest()
				.get()
				.path(TITLE_ADDITIONALCREW, titleId)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
						.build()
				)
				.contract(ContractJsonSchema.builder()
						.jsonSchemaPath(JsonSchemaPaths.TITLE_ADDITIONALCAST_ADDITIONALCREW)
						.build()
				);
	}

	public static MarketingDmdcRequest getTitleAdditionalCrew(String titleId,int localId){

		return DmdcMarketingClient.getTitleAdditionalCrew(titleId)
				.parameter(QueryParams.LOCAL_ID,localId);

	}

	public static MarketingDmdcRequest getTitleAdditionalCast(String titleId) {

		return new MarketingDmdcRequest()
				.get()
				.path(TITLE_ADDITIONAL_CAST, titleId)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
						.build()
				)
				.contract(ContractJsonSchema.builder()
						.jsonSchemaPath(JsonSchemaPaths.TITLE_ADDITIONALCAST_ADDITIONALCREW)
						.build()
				);
	}

	public static MarketingDmdcRequest getTitleAdditionalCast(String titleId, int localId) {

		return DmdcMarketingClient.getTitleAdditionalCast(titleId)
				.parameter(QueryParams.LOCAL_ID, localId);
	}

	public static MarketingDmdcRequest getTitleAvailability(String titleId, String id, int distributionUnitId, int localId, int productType){
		return DmdcMarketingClient.getTitleAvailability(titleId)
				.parameter(QueryParams.ID, id)
				.parameter(QueryParams.DISTRIBUTION_UNIT_ID, distributionUnitId)
				.parameter(QueryParams.LOCAL_ID, localId)
				.parameter(QueryParams.PRODUCT_TYPE, productType);

	}

	public static MarketingDmdcRequest getTitleAvailability(String titleId, String id, int distributionUnitId, int localId, int productType, Boolean episode) {
		return DmdcMarketingClient.getTitleAvailability(titleId,id,distributionUnitId,localId,productType)
				.parameter(QueryParams.EPISODE_DATA, episode);
	}

	public static MarketingDmdcRequest postTitleSearchResults(){

		return new MarketingDmdcRequest()
				.post()
				.path(TITLE_SEARCH_PATH)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_COMMON)
						.ignoredHeaders(DmdcHeaders.IGNORED_TITLE_SEARCH)
						.build()
				)
				.contract(ContractJsonSchema.builder()
						.jsonSchemaPath(JsonSchemaPaths.PORTAL_TITLE_SEARCH)
						.build()
				);
	}

	public static MarketingDmdcRequest postTitleSearchResults(TitleSearchRequest request){

		return DmdcMarketingClient.postTitleSearchResults()
				.body(request);
	}

	public static MarketingDmdcRequest postPortalTitleSuggest(){

		return new MarketingDmdcRequest()
				.post()
				.path(PORTAL_TITLE_SUGGEST_POST_PATH)
				.contentType(MediaType.APPLICATION_JSON)
				.accepts(MediaType.APPLICATION_JSON)
				.contract(DEFAULT_STATUS_CODE_CONTRACT)
				.contract(DEFAULT_HEADER_CONTRACT)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_COMMON_AND_X_FRAME_OPTIONS)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
						.build()
				)
				.contract(ContractJsonSchema.builder()
						.jsonSchemaPath(JsonSchemaPaths.TITLE_SUGGEST)
						.build()
				);
	}

	public static MarketingDmdcRequest postPortalTitleSuggest(PortalTitleSuggestRequest body){
		return DmdcMarketingClient.postPortalTitleSuggest()
				.body(body);
	}
}