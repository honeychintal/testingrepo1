package com.disney.dmdc.qa.constant;

public class AssetAvailability {

	public static final String PENDING = "0";
	public static final String AVAILABLE = "1";
	public static final String NOT_AVAILABLE = "2";
}
