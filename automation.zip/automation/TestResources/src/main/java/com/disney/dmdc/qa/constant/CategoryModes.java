package com.disney.dmdc.qa.constant;

public class CategoryModes {

    public static final String USER = "user";
    public static final String SYSTEM = "system";
}
