package com.disney.dmdc.qa.constant;

public class DistributionUnitIds {

    public static final int TELEVISION_DISTRIBUTION = 1;
    public static final int HOME_ENTERTAINMENT = 2;
    public static final int DISNEY_INFLIGHT = 3;
    public static final int DISNEY_BOX_OFFICE = 4;
}
