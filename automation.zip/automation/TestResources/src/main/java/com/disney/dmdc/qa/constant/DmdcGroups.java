package com.disney.dmdc.qa.constant;

import com.disney.qa.groups.TestGroups;

public class DmdcGroups extends TestGroups {

	public static final String SETTINGS = "settings";
	public static final String TITLES = "titles";
	public static final String TITLELOCALS = "locals";
	public static final String ASSETS = "assets";
	public static final String CATEGORIES = "categories";
	public static final String SEARCH = "search";
	public static final String XRAY = "xray";
	public static final String PORTAL_NAV_MENU = "portalNavMenu";
	public static final String POC = "poc";
	public static final String LOOKUP = "lookup";
	public static final String MEMBERSHIP_USER = "membershipUser";
	public static final String REQUESTS = "requests";
	public static final String SESSION = "session";
	public static final String PORTAL_SEARCH_TABS = "portalSearchTabs";
	public static final String NEWS = "news";
	public static final String SPOTLIGHT = "spotlight";
	public static final String MEMBERSHIP_GROUP = "membershipGroup";
	public static final String NAV_GET = "navGet";
	public static final String PORTAL_TITLE_SEARCH = "portalTitleSearch";
	public static final String TITLE_SUGGEST = "titleSuggest";
	public static final String P1 = "p1";
	public static final String P2 = "p2";
	public static final String P3 = "p3";
	public static final String P4 = "p4";
}