package com.disney.dmdc.qa.constant;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.net.HttpHeaders;

import java.util.Collection;
import java.util.Map;

public class DmdcHeaders {

    public static final String REQUEST_CONTEXT = "Request-Context";
    public static final String X_XSRF_TOKEN ="X-XSRF-TOKEN";

    //Cookies
    public static final String TACA_COOKIE_NAME = "taca";
    public static final String XSRF_COOKIE_NAME="XSRF-TOKEN";
    public static final String DMDSTATS_COOKIE_NAME = "dmdstats";
    public static final String ANTIFORGERY_COOKIE_NAME = ".Antiforgery";

    //Expected Headers
    public static final Map<String, String> EXPECTED_COMMON = ImmutableMap.<String, String>builder()
            .put(HttpHeaders.SERVER, "Kestrel")
            .put(HttpHeaders.CACHE_CONTROL, "no-cache")
            .put(HttpHeaders.CONNECTION, "keep-alive")
            .put(HttpHeaders.VARY, "Accept-Encoding")
            .put(HttpHeaders.EXPIRES, "-1")
            .put(HttpHeaders.PRAGMA, "no-cache")
            .put(HttpHeaders.X_POWERED_BY, "ASP.NET")
            .put(HttpHeaders.CONTENT_TYPE, "application/json; charset=utf-8")
            .put(HttpHeaders.STRICT_TRANSPORT_SECURITY, "max-age=2592000")
            .build();

    public static final Map<String, String> EXPECTED_COMMON_ADMIN = ImmutableMap.<String, String>builder()
            .putAll(EXPECTED_COMMON)
            .build();

    public static final Map<String, String> EXPECTED_TITLE_AVAILABILITY = ImmutableMap.<String, String>builder()
            .putAll(EXPECTED_COMMON_ADMIN)
            .put(HttpHeaders.X_FRAME_OPTIONS, "SAMEORIGIN")
            .build();

    public static final Map<String, String> EXPECTED_SETTINGS = ImmutableMap.<String, String>builder()
            .putAll(EXPECTED_COMMON)
            .put(HttpHeaders.X_FRAME_OPTIONS, "SAMEORIGIN")
            .build();

    public static final Map<String, String> EXPECTED_COMMON_AND_X_FRAME_OPTIONS = ImmutableMap.<String, String>builder()
            .putAll(EXPECTED_COMMON)
            .put(HttpHeaders.X_FRAME_OPTIONS, "SAMEORIGIN")
            .build();

    public static final Map<String, String> EXPECTED_NO_DMDSTATS = ImmutableMap.<String, String>builder()
            .put(HttpHeaders.STRICT_TRANSPORT_SECURITY, "max-age=2592000")
            .put(HttpHeaders.X_POWERED_BY, "ASP.NET")
            .put(HttpHeaders.SERVER, "Kestrel")
            .put(HttpHeaders.PRAGMA, "no-cache")
            .put(HttpHeaders.CACHE_CONTROL, "no-cache, no-store")
            .put(HttpHeaders.CONTENT_TYPE, "text/plain")
            .put(HttpHeaders.X_FRAME_OPTIONS, "SAMEORIGIN")
            .build();

    //Ignored Headers
    public static final Collection<String> IGNORED_COMMON = ImmutableList.of(
            HttpHeaders.DATE,
            HttpHeaders.SET_COOKIE,
            DmdcHeaders.REQUEST_CONTEXT,
            HttpHeaders.X_FRAME_OPTIONS
    );

    public static final Collection<String> IGNORED_COMMON_ADMIN = ImmutableList.of(
            HttpHeaders.DATE,
            HttpHeaders.SET_COOKIE,
            DmdcHeaders.REQUEST_CONTEXT,
            HttpHeaders.CONTENT_LENGTH,
            HttpHeaders.CONTENT_TYPE
    );

    public static final Collection<String> IGNORED_TITLE_SEARCH = ImmutableList.of(
            HttpHeaders.DATE,
            HttpHeaders.SET_COOKIE,
            DmdcHeaders.REQUEST_CONTEXT,
            HttpHeaders.CONNECTION
    );

    public static final Map<String, String> EXPECTED_NO_ANTIFORGERY_OR_XSRF = ImmutableMap.<String, String>builder()
            .put(HttpHeaders.SERVER, "Kestrel")
            .put(HttpHeaders.CACHE_CONTROL, "no-cache")
            .put(HttpHeaders.CONNECTION, "close")
            .put(HttpHeaders.EXPIRES, "-1")
            .put(HttpHeaders.PRAGMA, "no-cache")
            .put(HttpHeaders.X_POWERED_BY, "ASP.NET")
            .put(HttpHeaders.CONTENT_TYPE, "text/plain")
            .put(HttpHeaders.STRICT_TRANSPORT_SECURITY, "max-age=2592000")
            .build();

    public static final Collection<String> IGNORED_ANTIFORGERY = ImmutableList.of(
            HttpHeaders.DATE,
            HttpHeaders.SET_COOKIE,
            DmdcHeaders.REQUEST_CONTEXT,
            HttpHeaders.CONTENT_LENGTH,
            HttpHeaders.CONTENT_TYPE,
            HttpHeaders.X_FRAME_OPTIONS,
            HttpHeaders.CONNECTION
    );
}