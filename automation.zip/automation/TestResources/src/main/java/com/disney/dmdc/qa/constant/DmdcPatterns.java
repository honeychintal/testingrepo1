package com.disney.dmdc.qa.constant;

import com.disney.qa.constants.JsonUnit;

public class DmdcPatterns {

	public static final String IMAGE_TOKEN_REGEX = JsonUnit.REGEX + "[a-zA-Z0-9_\\-]{111}";
}
