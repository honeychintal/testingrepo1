package com.disney.dmdc.qa.constant;

public class JsonSchemaPaths {

    public static final String PORTAL_NAV_MENU = "src/test/resources/schemaValidationJsons/portalNavMenu.json";
    public static final String TITLE_ADDITIONAL_DATA = "src/test/resources/schemaValidationJsons/titleAdditionalData.json";
    public static final String TITLE_AWARDS = "src/test/resources/schemaValidationJsons/titleAwards.json";
    public static final String TITLE_HEADER = "src/test/resources/schemaValidationJsons/titleHeader.json";
    public static final String TITLE_LICENSE = "src/test/resources/schemaValidationJsons/titleLicense.json";
    public static final String TITLE_LOCALS = "src/test/resources/schemaValidationJsons/titleLocals.json";
    public static final String TITLE_QUICKVIEW = "src/test/resources/schemaValidationJsons/titleQuickview.json";
    public static final String ASSET_AUDIO_CHANNELS = "src/test/resources/schemaValidationJsons/assetAudioChannels.json";
    public static final String CATEGORY_ID = "src/test/resources/schemaValidationJsons/categoryId.json";
    public static final String CATEGORY = "src/test/resources/schemaValidationJsons/category.json";
    public static final String TITLE_HIERARCHY = "src/test/resources/schemaValidationJsons/titleHierarchy.json";
    public static final String MEMBERSHIP_GROUP_FIELDS = "src/test/resources/schemaValidationJsons/admin/membershipGroupFields.json";
    public static final String MEMBERSHIP_USER_COMMANDS = "src/test/resources/schemaValidationJsons/admin/membershipUserCommands.json";
    public static final String MARKETING_SETTINGS = "src/test/resources/schemaValidationJsons/settings.json";
    public static final String USER_REQUEST_SUMMARY = "src/test/resources/schemaValidationJsons/admin/userRequestSummary.json";
    public static final String TITLE_TABS = "src/test/resources/schemaValidationJsons/titleTabs.json";
    public static final String MEMBERSHIP_USERID = "src/test/resources/schemaValidationJsons/admin/membershipUserId.json";
    public static final String REQUESTS_FIELDS = "src/test/resources/schemaValidationJsons/admin/requestsFields.json";
    public static final String MEMBERSHIP_USER_GROUPS = "src/test/resources/schemaValidationJsons/admin/membershipUserGroups.json";
    public static final String TITLE_AVAILABILITY = "src/test/resources/schemaValidationJsons/titleAvailability.json";
    public static final String PLAYBACK_SESSION = "src/test/resources/schemaValidationJsons/playbackSession.json";
    public static final String TITLE_TALENTS = "src/test/resources/schemaValidationJsons/titleTalents.json";
    public static final String TITLE_QUOTES = "src/test/resources/schemaValidationJsons/titleQuotes.json";
    public static final String SEARCH_TABS = "src/test/resources/schemaValidationJsons/searchTabs.json";
    public static final String ASSET_QUICKVIEW_INFO = "src/test/resources/schemaValidationJsons/assetQuickViewInfo.json";
    public static final String TITLE_ADDITIONALCAST_ADDITIONALCREW = "src/test/resources/schemaValidationJsons/titleAdditionalCastAndCrew.json";
    public static final String PORTAL_TITLE_SEARCH = "src/test/resources/schemaValidationJsons/portalTitleSearch.json";
    public static final String TITLE_SUGGEST = "src/test/resources/schemaValidationJsons/titleSuggest.json";
}