package com.disney.dmdc.qa.constant;

public class LocaleIds {

    public static final int ENG_US = 3;
    public static final int HIN_IN = 39;
}
