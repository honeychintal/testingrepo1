package com.disney.dmdc.qa.constant;

public class PageIndex {

    public static final int DEFAULT = 0;
}
