package com.disney.dmdc.qa.constant;

public class ProductTypeIds {

    public static final int COMPILATION_EPISODE = 2;
    public static final int DIRECT_TO_VIDEO = 3;
    public static final int EPISODE = 4;
    public static final int FEATURE = 5;
    public static final int FORMAT = 6;
    public static final int MAKING_OF = 7;
    public static final int MINI_SERIES = 8;
    public static final int OMT = 9;
    public static final int PILOT = 10;
    public static final int PRESENTATION = 11;
    public static final int SEASON = 12;
    public static final int SERIES = 13;
    public static final int SHORTS = 14;
    public static final int SPECIAL = 15;
    public static final int UNSCRIPTED_FORMAT = 16;
    public static final int SCRIPTED_FORMAT = 17;
    public static final int WORKSPACE = 18;
    public static final int NEW_MEDIA_FILM = 19;
    public static final int MASH_UP = 20;
    public static final int MFT_MOW = 21;
}
