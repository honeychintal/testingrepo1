package com.disney.dmdc.qa.constant;

public class QueryParams {

	public static final String ID = "id";
	public static final String DISTRIBUTION_UNIT_ID = "distributionUnitId";
	public static final String LOCAL_ID = "localId";
	public static final String PRODUCT_TYPE = "productType";
	public static final String MODE = "mode";
	public static final String REQUEST_ID = "requestId";
	public static final String PAGE_INDEX = "pageIndex";
	public static final String EPISODE_DATA = "episodeData";
}
