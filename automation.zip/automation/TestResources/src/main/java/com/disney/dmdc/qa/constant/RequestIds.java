package com.disney.dmdc.qa.constant;

public class RequestIds {

    public static final int DEFAULT = 0;
}
