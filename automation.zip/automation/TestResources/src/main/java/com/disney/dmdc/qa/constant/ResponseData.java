package com.disney.dmdc.qa.constant;

public class ResponseData {
    public static final String INVALID_DMDSTATS_RESPONSE = "Status code page, status code: 401";
    public static final String BAD_REQUEST_RESPONSE = "Status code page, status code: 400";
}