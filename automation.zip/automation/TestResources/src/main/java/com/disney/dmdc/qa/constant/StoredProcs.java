package com.disney.dmdc.qa.constant;

public class StoredProcs {

    public static final String ASSET_AUDIO_CHANNEL = "[Titles].[ProductPage_AssetDetail_GetAudioChannelDetails] @ApplicationAssetId=?";
    public static final String ASSET_DETAIL = "[Titles].[ProductPage_AssetDetail_GetInfo] @ApplicationId=?, @UserId=?, @ApplicationAssetId=?";
    public static final String CATEGORY = "[Titles].[HomePage_Categories_GetCategoryList] @ApplicationId=?, @UserId=?, @QueryType=?, @CategoryId=?";
    public static final String SEARCH_TABS = "[Titles].[ProductPage_Tabs_GetInfo] @ApplicationId=?, @UserId=?, @DistributionUnitId=?, @ApplicationTitleGuid=?, @SearchMode=?";
    public static final String TITLE_ADDITIONAL_CREW_AND_CAST = "[Titles].[ProductPage_AditionalTalents_GetInfo] @ApplicationTitleGuid=?, @LocaleId = ?, @CreditTypeId = ?";
    public static final String TITLE_ADDITIONAL_DATA = "[Titles].[ProductPage_FNTData_GetInfo] @ApplicationTitleGuid=?";
    public static final String TITLE_AWARDS = "[Titles].[ProductPage_Awards_GetInfo] @ApplicationTitleGuid=?, @DistributionUnitId=?";
    public static final String TITLE_HEADER = "[Titles].[ProductPage_Header_GetInfo] @ApplicationId=?, @UserId=?, @DistributionUnitId=?, @ApplicationTitleGuId=?, @LocaleId=?";
    public static final String TITLE_HIERARCHY = "[Titles].[ProductPage_Hierarchy_GetInfo] @ApplicationId=?, @UserId=?, @DistributionUnitId=?, @ApplicationTitleGuid=?";
    public static final String TITLE_LICENSE = "[Titles].[ProductPage_License_GetInfo] @ApplicationId=?, @UserId=?, @ApplicationTitleGuid=?";
    public static final String TITLE_LOCAL = "[Titles].[ProductPage_Locale_GetInfo] @ApplicationId=?, @UserId=?, @DistributionUnitId=?, @ApplicationTitleGuid=?";
    public static final String TITLE_TABS = "[Titles].[ProductPage_Tabs_GetInfo] @ApplicationId=?, @UserId=?, @DistributionUnitId=?, @ApplicationTitleGuid=?, @SearchMode=?";
    public static final String TITLE_TALENT = "[Titles].[ProductPage_Talents_GetInfo] @ApplicationTitleGuid=?, @LocaleId=?";
    public static final String TITLE_QUICKVIEW = "[Titles].[ProductPage_TitleQuickView_GetInfo] @ApplicationId=?, @UserId=?, @ApplicationTitleGuid=?";
    public static final String TITLE_SYNOPSIS = "[Titles].[SynopsisGetByTitleUniqueId] @TitleUniqueId=?, @LocaleId=?";
    public static final String TITLE_QUOTES = "[Titles].[ProductPage_PressQuotes_GetInfo] @ApplicationTitleGuid=?, @DistributionUnitId=?, @LocaleId=?";
    public static final String TITLE_SUGGEST = "[Titles].[HomePage_Search_TypeAhead] @ApplicationId=?, @UserId=?,@SearchData=?";

}