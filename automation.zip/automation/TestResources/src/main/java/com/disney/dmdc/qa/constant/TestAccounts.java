package com.disney.dmdc.qa.constant;

import com.disney.dmdc.qa.model.UserDetails;

public class TestAccounts {

    //dmdc_api_automation@dmdcentral.com
    public static final UserDetails DMDC_API_AUTOMATION = UserDetails.builder()
            .email("dmdc_api_automation@dmdcentral.com")
            .firstName("dmdc_api_automation")
            .id(111117)
            .lastName("last")
            .userType("admin")
            .build();

    //test_tvd_and_he_user@dmdcentral.com
    public static final UserDetails TEST_TVD_HE_USER = UserDetails.builder()
            .email("test_tvd_and_he_user@dmdcentral.com")
            .firstName("Tvd-he")
            .id(111408)
            .lastName("User")
            .userType("TvdHe")
            .build();

    //test_tvd_user@dmdcentral.com
    public static final UserDetails TEST_TVD_USER = UserDetails.builder()
            .email("test_tvd_user@dmdcentral.com")
            .firstName("tvd-only")
            .id(111409)
            .lastName("User")
            .userType("Tvd")
            .build();

    //test_he_user@dmdcentral.com
    public static final UserDetails TEST_HE_USER = UserDetails.builder()
            .email("test_he_user@dmdcentral.com")
            .firstName("he-only")
            .id(111410)
            .lastName("User")
            .userType("He")
            .build();
}
