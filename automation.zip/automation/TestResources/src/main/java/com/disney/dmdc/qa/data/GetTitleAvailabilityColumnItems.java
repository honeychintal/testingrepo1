package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.factory.GetTitleAvailabilityColumnFactory;
import com.disney.dmdc.qa.model.Column;
import com.google.common.collect.ImmutableList;

import java.util.List;

public class GetTitleAvailabilityColumnItems {

    public static final List<Column> GET_TITLEAVAILABILITY_COLUMN_DATA =
            ImmutableList.of(
                    GetTitleAvailabilityColumnFactory.createGetTitleAvailabilityColumnData(
                            "CpmProductId",
                            "Product ID",
                            false,
                            false,
                            0,
                            "string"
                    ),
                    GetTitleAvailabilityColumnFactory.createGetTitleAvailabilityColumnData(
                            "WprId",
                            "Title ID",
                            false,
                            false,
                            0,
                            "string"
                    )
            );

    public static final List<Column> GET_TITLEAVAILABILITY_COLUMN_DATA_SEASON =
            ImmutableList.of(
                    GetTitleAvailabilityColumnFactory.createGetTitleAvailabilityColumnData(
                            "EpisodeNumber",
                            "Ep",
                            false,
                            false,
                            0,
                            "string"
                    ),
                    GetTitleAvailabilityColumnFactory.createGetTitleAvailabilityColumnData(
                            "CpmProductId",
                            "Product ID",
                            false,
                            false,
                            0,
                            "string"
                    )
            );
}