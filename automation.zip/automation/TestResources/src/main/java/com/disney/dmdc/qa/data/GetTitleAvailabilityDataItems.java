package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.factory.GetTitleAvailabilityDataElementFactory;
import com.disney.dmdc.qa.model.GetTitleAvailabilityDataElement;
import com.google.common.collect.ImmutableList;

import java.util.List;

public class GetTitleAvailabilityDataItems {

    public static final List<GetTitleAvailabilityDataElement> GET_TITLEAVAILABILITY_ELEMENTS_DATA =
            ImmutableList.of(
                    GetTitleAvailabilityDataElementFactory.createGetTitleAvailabilityDataElements(
                            "e60b9856-1629-49b1-b089-adb01e59871e",
                            null,
                            "038171",
                            "Alien VS. Predator",
                            "NR",
                            "13 Aug 2004",
                            "ac4c42de-6758-4a4d-8b71-c01689254a0e",
                            "A team of scientists get caught up in a war between aliens and predators.",
                            "1",
                            "2",
                            "2",
                            "0",
                            "1",
                            "1",
                            "1",
                            "1",
                            "2",
                            "1",
                            "2",
                            "2",
                            "1",
                            "1",
                            "1",
                            "1",
                            "1",
                            "2",
                            "1",
                            "1",
                            "120026",
                            null,
                            null
                    ));

    public static final List<GetTitleAvailabilityDataElement> GET_TITLEAVAILABILITY_ELEMENTS_DATA_SEASON=
            ImmutableList.of(
                    GetTitleAvailabilityDataElementFactory.createGetTitleAvailabilityDataElements(
                            "af38bdf0-28f6-4292-8363-a3b2688612b0",
                            "1",
                            "7ATM01",
                            "About Three Years Later",
                            "TV-14",
                            "10 Apr 2018",
                            "c5287e0e-01a3-4e36-8be2-52d6b0ddd52b",
                            "Marriage, babies and whole lot of crazy.",
                            "1",
                            "1",
                            "0",
                            "0",
                            "0",
                            "0",
                            "1",
                            "0",
                            "0",
                            "1",
                            "0",
                            "0",
                            "1",
                            "1",
                            "1",
                            "1",
                            "1",
                            "1",
                            "1",
                            "1",
                            "220963",
                            null,
                            null
                    ),
                    GetTitleAvailabilityDataElementFactory.createGetTitleAvailabilityDataElements(
                            "56272cd5-3eca-4b97-80c9-6e5fb32d6b48",
                            "2",
                            "7ATM02",
                            "Tuesday Meeting",
                            "TV-14",
                            "17 Apr 2018",
                            "d645bf6e-0a51-4c78-b684-cc65e13f923e",
                            "Jess is inspired and Schmidt is tired.",
                            "1",
                            "1",
                            "0",
                            "0",
                            "0",
                            "0",
                            "1",
                            "0",
                            "0",
                            "1",
                            "0",
                            "0",
                            "1",
                            "1",
                            "1",
                            "1",
                            "1",
                            "1",
                            "1",
                            "1",
                            "220964",
                            null,
                            null
                    )
            );
}