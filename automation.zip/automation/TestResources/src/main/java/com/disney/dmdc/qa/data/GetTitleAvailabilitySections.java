package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.model.Column;
import com.disney.dmdc.qa.model.GetTitleAvailabilityDataElement;

import java.util.List;

public class GetTitleAvailabilitySections {

    public static List<GetTitleAvailabilityDataElement> getTitleAvailabilityDataItems(){

        return GetTitleAvailabilityDataItems.GET_TITLEAVAILABILITY_ELEMENTS_DATA;
    }
    public static List<Column> getTitleAvailabilityColumnItems(){

        return GetTitleAvailabilityColumnItems.GET_TITLEAVAILABILITY_COLUMN_DATA;
    }
    public static List<GetTitleAvailabilityDataElement> getTitleAvailabilityDataItemsSeason(){

        return GetTitleAvailabilityDataItems.GET_TITLEAVAILABILITY_ELEMENTS_DATA_SEASON;
    }
    public static List<Column> getTitleAvailabilityColumnItemsSeason(){

        return GetTitleAvailabilityColumnItems.GET_TITLEAVAILABILITY_COLUMN_DATA_SEASON;
    }
}
