package com.disney.dmdc.qa.data;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum IDP_USER_STATUS {


    ACTIVE("ACTIVE");
    @Getter private String value;

}
