package com.disney.dmdc.qa.data;

import com.typesafe.config.Config;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum IDP_USER_TYPE {


    OKTA("OKTA");
    @Getter private String value;

}
