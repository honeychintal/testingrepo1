package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.model.Item;
import com.google.common.collect.ImmutableList;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.List;

@AllArgsConstructor
@Getter
public enum SampleTitle {

    CHEAPER_BY_THE_DOZEN(
            "06362779-f295-45ed-87fc-5ed924a4b6ae",
            "001184",
            ImmutableList.of()
            //Non-English locale data is not currently available
            /*
            ImmutableList.of(
                    ItemFactory.CreateItem(
                            Territory.BRAZIL,
                            Language.BRAZILIAN_PORTUGUESE,
                            "Papai Batuta"
                    ),
                    ItemFactory.CreateItem(
                            Territory.FRANCE,
                            Language.FRENCH,
                            "TREIZE À LA DOUZAINE"
                    ),
                    ItemFactory.CreateItem(
                            Territory.ITALY,
                            Language.ITALIAN,
                            "Una scatenata dozzina"
                    ),
                    ItemFactory.CreateItem(
                            Territory.MEXICO,
                            Language.LATIN_SPANISH,
                            "Mas Barato Por Docena "
                    )
            )*/
    ),
    ALIEN_VS_PREDATOR(
            "e60b9856-1629-49b1-b089-adb01e59871e",
            "038171",
            null
    )
    ;

    private String titleId;
    private String wprids;
    private List<Item> localNames;
}
