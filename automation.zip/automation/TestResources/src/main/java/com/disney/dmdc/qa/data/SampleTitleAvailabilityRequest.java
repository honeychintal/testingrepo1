package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.model.TitleAvailabilityDataElement;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum SampleTitleAvailabilityRequest {

    TEST1(
            TitleAvailabilityDataElement.builder()
                    .applicationTitleGuid(SampleTitle.ALIEN_VS_PREDATOR.getTitleId())
                    .bQFullProgram("1")
                    .closedCaptions("1")
                    .cpmProductId("120026")
                    .domesticEpisodeNumber(null)
                    .dubCards("1")
                    .episodeNumber(null)
                    .episodicPhotos("2")
                    .eventPhotos("2")
                    .foreignEpisodeNumber(null)
                    .galleryPhotos("0")
                    .hELogosArtwork("1")
                    .hEProductionStills("2")
                    .localizationReports("1")
                    .logosArtwork("1")
                    .musicCues("1")
                    .productionStills("1")
                    .promosTrailers("1")
                    .releaseDate("13 Aug 2004")
                    .screenersFullProgram("1")
                    .scripts("1")
                    .specialShootPhotos("2")
                    .subtitles("1")
                    .synopsis("1")
                    .titleName("Alien vs. Predator")
                    .titleRep("2")
                    .wprId("038171")
                    .build()
    )
    ;

    private TitleAvailabilityDataElement value;
}
