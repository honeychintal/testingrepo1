package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.constant.DmdcPatterns;
import com.disney.dmdc.qa.factory.FooterSettingsFactory;
import com.disney.dmdc.qa.factory.SettingsResponseFactory;
import com.disney.dmdc.qa.model.HomeSettings;
import com.disney.dmdc.qa.model.MediaPlayerSettings;
import com.disney.dmdc.qa.model.SettingsResponse;
import com.disney.dmdc.qa.model.TitleDetailsSettings;
import com.disney.dmdc.qa.util.TestServicesConfig;
import com.google.common.collect.ImmutableList;

public class SettingsData {

    public static final SettingsResponse ADMIN_USER_SETTINGS_RESPONSE =
            SettingsResponseFactory.createSettingsResponse(
                    "DMD Central",
                    1,
                    "foxfast",
                    TestServicesConfig.getServiceUrls("cdn"),
                    TestServicesConfig.getServiceUrls("admin"),
                    DmdcPatterns.IMAGE_TOKEN_REGEX,
                    "+0700",
                    ImmutableList.of(
                            FooterSettingsFactory.createFooterSettingsFactory(
                                    TestServicesConfig.getServiceUrls("www") + "Home/Feedback",
                                    1,
                                    "Feedback"
                            ),
                            FooterSettingsFactory.createFooterSettingsFactory(
                                    TestServicesConfig.getServiceUrls("static") +
                                            "policies/1/en-us/terms.html",
                                    2,
                                    "Terms & Conditions"
                            ),
                            FooterSettingsFactory.createFooterSettingsFactory(
                                    TestServicesConfig.getServiceUrls("static") +
                                            "policies/1/en-us/privacy.html",
                                    3,
                                    "Privacy Policy"
                            ),
                            FooterSettingsFactory.createFooterSettingsFactory(
                                    TestServicesConfig.getServiceUrls("privacy") +
                                            "en/current-privacy-policy/your-california-privacy-rights//",
                                    4,
                                    "Your California Privacy Rights"
                            ),
                            FooterSettingsFactory.createFooterSettingsFactory(
                                    TestServicesConfig.getServiceUrls("www") + "Help",
                                    6,
                                    "Help"
                            )
                    ),
                    HomeSettings.builder()
                            .isSpotlightEnabled(true)
                            .requestAssets(false)
                            .requestScreeners(false)
                            .build(),
                    TitleDetailsSettings.builder()
                            .isSpotlightEnabled(false)
                            .requestAssets(false)
                            .requestScreeners(false)
                            .externalTitleSource("{\"portal\":\"disneymediadistribution-test.tv\", \"href\": "+
                                    "\"https://www.disneymediadistribution-test.tv/\", \"target\": \"_blank\" }")
                            .build(),
                    1009702,
                    new ImmutableList.Builder<Integer>()
                            .add(12, 5, 1, 4, 34, 60, 61, 6, 13, 42, 11, 14, 10, 7, 8, 3, 36, 35,
                                    43, 2, 41, 50, 48, 47, 53, 51, 49, 52, 46, 54, 26, 37, 38, 58)
                            .build(),
                    TestServicesConfig.getServiceUrls("www"),
                    TestServicesConfig.getServiceUrls("auth"),
                    true,
                    MediaPlayerSettings.builder()
                            .sdkUrl("https://wapi-stage2.idviu.io/xres/mvp/0/mvp.js")
                            .apiUrl("wapi-stage2.idviu.io")
                            .build(),
                    TestServicesConfig.getServiceUrls("apim") + "api/signalr",
                    "b0abad80-d0f2-4418-bb60-f85d1616b09e"
            );

    public static final SettingsResponse MARKETING_USER_SETTINGS_RESPONSE =
            SettingsResponseFactory.createSettingsResponse(
                    "DMD Central",
                    1,
                    "foxfast",
                    TestServicesConfig.getServiceUrls("cdn"),
                    TestServicesConfig.getServiceUrls("admin"),
                    DmdcPatterns.IMAGE_TOKEN_REGEX,
                    "+0700",
                    ImmutableList.of(
                            FooterSettingsFactory.createFooterSettingsFactory(
                                    TestServicesConfig.getServiceUrls("www") + "Home/Feedback",
                                    1,
                                    "Feedback"
                            ),
                            FooterSettingsFactory.createFooterSettingsFactory(
                                    TestServicesConfig.getServiceUrls("static") +
                                            "policies/1/en-us/terms.html",
                                    2,
                                    "Terms & Conditions"
                            ),
                            FooterSettingsFactory.createFooterSettingsFactory(
                                    TestServicesConfig.getServiceUrls("static") +
                                            "policies/1/en-us/privacy.html",
                                    3,
                                    "Privacy Policy"
                            ),
                            FooterSettingsFactory.createFooterSettingsFactory(
                                    TestServicesConfig.getServiceUrls("privacy") +
                                            "en/current-privacy-policy/your-california-privacy-rights//",
                                    4,
                                    "Your California Privacy Rights"
                            ),
                            FooterSettingsFactory.createFooterSettingsFactory(
                                    TestServicesConfig.getServiceUrls("www") + "Help",
                                    6,
                                    "Help"
                            )
                    ),
                    HomeSettings.builder()
                            .isSpotlightEnabled(true)
                            .requestAssets(false)
                            .requestScreeners(false)
                            .build(),
                    TitleDetailsSettings.builder()
                            .isSpotlightEnabled(false)
                            .requestAssets(false)
                            .requestScreeners(false)
                            .externalTitleSource("{\"portal\":\"disneymediadistribution-test.tv\", \"href\": " +
                                    "\"https://www.disneymediadistribution-test.tv/\", \"target\": \"_blank\" }")
                            .build(),
                    131072,
                    ImmutableList.of(),
                    TestServicesConfig.getServiceUrls("www"),
                    TestServicesConfig.getServiceUrls("auth"),
                    false,
                    MediaPlayerSettings.builder()
                            .sdkUrl("https://wapi-stage2.idviu.io/xres/mvp/0/mvp.js")
                            .apiUrl("wapi-stage2.idviu.io")
                            .build(),
                    TestServicesConfig.getServiceUrls("apim") + "api/signalr",
                    "b0abad80-d0f2-4418-bb60-f85d1616b09e"
            );
}
