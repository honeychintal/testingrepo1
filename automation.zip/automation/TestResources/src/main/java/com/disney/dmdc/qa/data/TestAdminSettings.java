package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.model.AdminSettingsGetResponse;
import com.disney.dmdc.qa.util.TestServicesConfig;

public class TestAdminSettings {

    public static AdminSettingsGetResponse adminSettingsGetResponse() {
        
        return AdminSettingsGetResponse.builder()
                .appInsights("b0abad80-d0f2-4418-bb60-f85d1616b09e")
                .appName("DMD Central")
                .theme("foxfast")
                .marketingBaseUrl(TestServicesConfig.getServiceUrls("marketing"))
                .legacyPortalBaseUrl(TestServicesConfig.getServiceUrls("www"))
                .cdnBaseUrl(TestServicesConfig.getServiceUrls("cdn"))
                .authAppUrl(TestServicesConfig.getServiceUrls("auth"))
                .build();
    }
}
