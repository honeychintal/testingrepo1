package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.model.AdminSettingsGetResponse;

public class TestAdminSettingsData {

    public static AdminSettingsGetResponse getSettingsResponse() {
        return TestAdminSettings.adminSettingsGetResponse();
    }
}
