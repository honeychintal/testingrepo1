package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.model.AssetAudioChannels;

public class TestAssetAudioChannels {

    public static final String ASSET_ID = "1208448";

    public static AssetAudioChannels getAssetAudioChannelInfo(Integer channelNumber, String audioChannelConfig){

        return AssetAudioChannels.builder()
                .channelNumber(channelNumber)
                .audioChannelLanguage("ENG")
                .audioChannelConfig(audioChannelConfig)
                .audioChannelFormat("2T")
                .audioChannelUsage("")
                .audioChannelDynamicRange("Broadcast")
                .build();

    }
}