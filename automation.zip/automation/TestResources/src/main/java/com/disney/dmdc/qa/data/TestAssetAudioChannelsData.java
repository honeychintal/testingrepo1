package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.model.AssetAudioChannels;

public class TestAssetAudioChannelsData {

    public static AssetAudioChannels getAssetFirstAudioChannelData(){

        return TestAssetAudioChannels.getAssetAudioChannelInfo(1, "L");
    }

    public static AssetAudioChannels getAssetSecondAudioChannelData(){

        return TestAssetAudioChannels.getAssetAudioChannelInfo(2, "R");
    }

    public static String getAssetId(){

        return TestAssetAudioChannels.ASSET_ID;
    }
}