package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.factory.AssetInfoAssetParentFactory;
import com.disney.dmdc.qa.model.AssetInfoResult;
import com.google.common.collect.ImmutableList;

public class TestAssetInfoResult {

    public static final AssetInfoResult ALIEN_VS_PREDATOR = AssetInfoResult
            .builder()
            .asset(AssetInfoAssetParentFactory.createAssetInfoAssetParent(
                    1208448, 1208448, 1, "Alien VS. Predator", "038171", 120026, "", "2004-08-13T00:00:00",
                    0, 0, "Published", "English Audio | Original Version", "5416439", 7, 5,
                    "2004-08-13T00:00:00+00:00", "Screeners - Full Program", "INTL_60055", true, false,
                    0, 0, false, 0, "2021-02-19T17:48:51.655556+00:00", 3, "Feature", "Screener Source",
                    "Theatrical:OV:en", "Theatrical:OV:en", 60055, "Full Frame", "ENG", "ENG", "ENG",
                    "International", "01:40:45",
                    "AlienVsPredator_038171_ORIG_V60055_INT_C_TVD_SCRNRFFE720p_23_ENG_178_ENG-ST_RT014045_HDScreener.mp4",
                    6023951759L, "TV Distribution", "Servicing", "23.98", "720p", "16x9", "1.78:1", "720",
                    "1280", "H.264", "8", "AAC-LC", "16", "DRM", "L", "ENG", "2T", "Broadcast", "R", "ENG",
                    "2T", false, false, 64, 0, 64, 0, "Feature", "System Update", "System Update",
                    "Final Delivery", false, false, true, false, 16, ImmutableList.of()
                    )
            )
            .parent(AssetInfoAssetParentFactory.createAssetInfoAssetParent(
                    1208448, 1208448, 1, "Alien VS. Predator", "038171", 120026, "", "2004-08-13T00:00:00",
                    0, 0, "Published", "English Audio | Original Version", "5416439", 7, 5,
                    "2004-08-13T00:00:00+00:00", "Screeners - Full Program", "INTL_60055", true, false,
                    0, 0, false, 0, "2021-02-19T17:48:51.655556+00:00", 3, "Feature", "Screener Source",
                    "Theatrical:OV:en", "Theatrical:OV:en", 60055, "Full Frame", "ENG", "ENG", "ENG",
                    "International", "01:40:45",
                    "AlienVsPredator_038171_ORIG_V60055_INT_C_TVD_SCRNRFFE720p_23_ENG_178_ENG-ST_RT014045_HDScreener.mp4",
                    6023951759L, "TV Distribution", "Servicing", "23.98", "720p", "16x9", "1.78:1", "720",
                    "1280", "H.264", "8", "AAC-LC", "16", "DRM", "L", "ENG", "2T", "Broadcast", "R", "ENG",
                    "2T", false, false, 64, 0, 64, 0, "Feature", "System Update", "System Update",
                    "Final Delivery", false, false, true, false, 16, ImmutableList.of()
                    )
            )
            .relatedAssets(ImmutableList.of())
            .build();

}
