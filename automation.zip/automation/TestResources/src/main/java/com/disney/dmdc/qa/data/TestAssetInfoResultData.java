package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.model.AssetInfoResult;

public class TestAssetInfoResultData {

    public static AssetInfoResult getAssetInfoResultData() {

        return TestAssetInfoResult.ALIEN_VS_PREDATOR;
    }
}
