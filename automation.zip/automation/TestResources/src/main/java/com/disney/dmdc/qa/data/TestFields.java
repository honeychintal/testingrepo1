package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.factory.FieldFactory;
import com.disney.dmdc.qa.model.FieldGetResponse;
import com.google.common.collect.ImmutableList;

import java.util.List;

public class TestFields {

    public static final List<FieldGetResponse> MEMBERSHIP_USER_FIELDS_GET_RESPONSE_LIST = ImmutableList.of(
            FieldFactory.createField(
                    "UsersName",
                    "User's Name",
                    true
            ),
            FieldFactory.createField(
                    "Email",
                    "Email",
                    true
            ),
            FieldFactory.createField(
                    "Company",
                    "Company",
                    false
            ),
            FieldFactory.createField(
                    "SalesRep",
                    "Sales Rep",
                    false
            ),
            FieldFactory.createField(
                    "CustomerNumber",
                    "Customer / Vendor Number",
                    true
            ),
            FieldFactory.createField(
                    "GroupName",
                    "Group Name",
                    true
            )
    );

    public static final List<FieldGetResponse> REQUESTS_FIELDS = ImmutableList.of (
            FieldFactory.createField(
                    "Email",
                    "Email",
                    true
            ),
            FieldFactory.createField(
                    "FirstName",
                    "First Name",
                    true
            ),
            FieldFactory.createField(
                    "LastName",
                    "Last Name",
                    true
            ),
            FieldFactory.createField(
                    "RequestId",
                    "Request ID",
                    null
            ),
            FieldFactory.createField(
                    "BriefDescription",
                    "Brief Description",
                    null
            )
    );

    public static final List<FieldGetResponse> GROUP_FIELDS = ImmutableList.of (
            FieldFactory.createField(
                    "ApplicationGroupName",
                    "Group Name",
                    true
            ),
            FieldFactory.createField(
                    "ApplicationGroupNumber",
                    "Customer / Vendor Number",
                    true
            ),
            FieldFactory.createField(
                    "SalesOfficeName",
                    "Sales Office",
                    false
            ),
            FieldFactory.createField(
                    "UserCompany",
                    "Company",
                    false
            ),
            FieldFactory.createField(
                    "UsersName",
                    "User's Name",
                    false
            ),
            FieldFactory.createField(
                    "Email",
                    "Email Address",
                    false
            )
    );

    public static final List<FieldGetResponse> ADMIN_TITLE_FIELDS_GET_RESPONSE_LIST = ImmutableList.of(
            FieldFactory.createField(
                    "titlename",
                    "Title Name",
                    true
            ),
            FieldFactory.createField(
                    "titlefinancialid",
                    "Title ID",
                    true
            ),
            FieldFactory.createField(
                    "episodename",
                    "Episode Name",
                    null
            )
    );
}