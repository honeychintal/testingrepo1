package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.model.FieldGetResponse;

import java.util.List;

public class TestFieldsData {
    public  static List<FieldGetResponse> getMembershipUserFieldsResponse() {

        return TestFields.MEMBERSHIP_USER_FIELDS_GET_RESPONSE_LIST;
    }

    public static List<FieldGetResponse> getRequestsFields() {

        return TestFields.REQUESTS_FIELDS;
    }

    public static List<FieldGetResponse> getGroupFields() {

        return TestFields.GROUP_FIELDS;
    }

    public  static List<FieldGetResponse> getAdminTitleFieldsResponse() {

        return TestFields.ADMIN_TITLE_FIELDS_GET_RESPONSE_LIST;
    }
}
