package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.model.ItemLocals;
import com.disney.dmdc.qa.model.LicenseItems;
import com.disney.dmdc.qa.type.ProductTypes;

import java.util.List;

public class TestLicenseItems {

    public static LicenseItems createLicenseResponse(Integer du, String duAbrr, Boolean active, List<ItemLocals> localItems, Integer productType) {
        return LicenseItems.builder()
                .distributionUnitId(du)
                .distributionUnitAbbr(duAbrr)
                .startDate(null)
                .endDate(null)
                .active(active)
                .productTypeId(productType)
                .locals(localItems)
                .licenseType(0)
                .build();
    }
}
