package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.model.ItemLocals;
import com.disney.dmdc.qa.model.LicenseItems;

import java.util.List;

public class TestLicenseItemsData {

    public static LicenseItems getLicenseData(Integer du, String duAbbr, boolean active, List<ItemLocals> locals, Integer productType) {
        return TestLicenseItems.createLicenseResponse(du, duAbbr, active, locals, productType);
    }
}
