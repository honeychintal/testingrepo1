package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.model.LookupGroupItems;
import com.google.common.collect.ImmutableList;

import java.util.List;

public class TestLookupGroupItems {
    public static final List<LookupGroupItems> LOOKUP_DISTRIBUTION_GROUP_ITEMS = ImmutableList.of(
            LookupGroupItems.builder()
                    .id(1)
                    .name("DMD Central")
                    .build(),
            LookupGroupItems.builder()
                    .id(15)
                    .name("Disney Inflight")
                    .build()
    );

    public static final List<LookupGroupItems> LOOKUP_GROUP_STATUS = ImmutableList.of(
            LookupGroupItems.builder()
                    .id(1)
                    .name("Active")
                    .build(),
            LookupGroupItems.builder()
                    .id(3)
                    .name("Inactive")
                    .build()
    );
}
