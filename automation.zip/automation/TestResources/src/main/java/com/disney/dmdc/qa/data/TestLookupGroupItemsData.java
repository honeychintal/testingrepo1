package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.model.LookupGroupItems;

import java.util.List;

public class TestLookupGroupItemsData {
    public static List<LookupGroupItems> getDistributionItems() {
        return TestLookupGroupItems.LOOKUP_DISTRIBUTION_GROUP_ITEMS;
    }

    public static List<LookupGroupItems> getGroupStatus() {
        return TestLookupGroupItems.LOOKUP_GROUP_STATUS;
    }
}
