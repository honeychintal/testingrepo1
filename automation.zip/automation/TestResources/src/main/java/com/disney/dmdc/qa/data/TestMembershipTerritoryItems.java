package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.factory.MembershipTerritoryItemsFactory;
import com.disney.dmdc.qa.model.MembershipTerritoryItems;
import com.disney.dmdc.qa.type.Territory;
import com.google.common.collect.ImmutableList;

import java.util.List;

public class TestMembershipTerritoryItems {

    public static final List<MembershipTerritoryItems> TERRITORY_ITEMS = ImmutableList.of(
            MembershipTerritoryItemsFactory.createTerritoryItems(
                    Territory.CANADA.getId(),
                    Territory.CANADA.getName()
            ),
            MembershipTerritoryItemsFactory.createTerritoryItems(
                    Territory.USA.getId(),
                    Territory.USA.getName()
            ),
            MembershipTerritoryItemsFactory.createTerritoryItems(
                    Territory.AFGHANISTAN.getId(),
                    Territory.AFGHANISTAN.getName()
            ),
            MembershipTerritoryItemsFactory.createTerritoryItems(
                    Territory.ALBANIA.getId(),
                    Territory.ALBANIA.getName()
            ),
            MembershipTerritoryItemsFactory.createTerritoryItems(
                    Territory.ANGOLA.getId(),
                    Territory.ANGOLA.getName()
            )
    );
}
