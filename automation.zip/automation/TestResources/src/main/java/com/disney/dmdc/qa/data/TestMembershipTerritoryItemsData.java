package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.model.MembershipTerritoryItems;

import java.util.List;

public class TestMembershipTerritoryItemsData {

    public static List<MembershipTerritoryItems> getTerritories() {
        return TestMembershipTerritoryItems.TERRITORY_ITEMS;
    }
}
