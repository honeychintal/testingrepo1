package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.factory.NavGetDataElementFactory;
import com.disney.dmdc.qa.model.NavGetDataElement;
import com.disney.dmdc.qa.model.NavGetSections;
import com.disney.dmdc.qa.util.TestServicesConfig;
import com.google.common.collect.ImmutableList;

import java.util.List;

public class TestNavGetSections {

    public static final List<NavGetSections> ADMIN_NAV_GET_SECTIONS_DATA = ImmutableList.of(NavGetSections.builder()
        .name("Manage")
        .items(ImmutableList.of(
                NavGetDataElementFactory
                    .createNavGet(
                            "manage-titles",
                            "TitleManagement",
                            false,
                            "film",
                            "Titles"),
                NavGetDataElementFactory
                        .createNavGet(
                            "manage-assets/1/appid",
                            "AssetManagement" ,
                            false,
                            "image",
                            "Assets"),
                NavGetDataElementFactory
                        .createNavGet(
                            TestServicesConfig.getServiceUrls("www") + "admin/Rights/Index",
                            "RightsManagement" ,
                            false,
                            "clipboard-check",
                            "Rights"),
                NavGetDataElementFactory
                        .createNavGet(
                            TestServicesConfig.getServiceUrls("rights") +"preauth",
                            "Authorizations" ,
                            false,
                            "clipboard-check",
                            "Authorization Dashboard"),
                NavGetDataElementFactory
                        .createNavGet(
                            "manage-membership/users",
                            "UserManagement" ,
                            false,
                            "user",
                            "Users"),
                NavGetDataElementFactory
                        .createNavGet(
                            "manage-membership/groups",
                            "GroupManagement" ,
                            false,
                            "users",
                            "Groups"),
                NavGetDataElementFactory
                        .createNavGet(
                            "request/queue/my",
                            "RequestQueue" ,
                            false,
                            "user-cog",
                            "Request Queue"),
                NavGetDataElementFactory
                        .createNavGet(
                            "request/queue/approval",
                            "ApprovalQueue",
                            false,
                            "user-check",
                            "Approval Queue"),
                NavGetDataElementFactory
                        .createNavGet(
                            TestServicesConfig.getServiceUrls("www") + "admin/RequestApproval/Index",
                            "RightsManagement" ,
                            false,
                            "tasks",
                            "License & Video Approval Queue"),
                NavGetDataElementFactory
                        .createNavGet(
                            TestServicesConfig.getServiceUrls("www") + "admin/Spotlight",
                            "SpotlightManagement" ,
                            false,
                            "megaphone",
                            "Spotlight"),
                NavGetDataElementFactory
                        .createNavGet(
                            TestServicesConfig.getServiceUrls("www") + "admin/Category",
                            "CategoryManagement" ,
                            false,
                            "images",
                            "Categories"),
                NavGetDataElementFactory
                        .createNavGet(
                            TestServicesConfig.getServiceUrls("www") + "admin/Notifications",
                            "NotificationsManagement" ,
                            false,
                            "bell",
                            "Notifications"),
                NavGetDataElementFactory
                        .createNavGet(
                            TestServicesConfig.getServiceUrls("www") + "admin/NewsAndAnnouncements",
                            "NewsManagement" ,
                            false,
                            "mail-bulk",
                            "News & Announcements"),
                NavGetDataElementFactory
                        .createNavGet(
                                TestServicesConfig.getServiceUrls("www") + "admin/SalesRep",
                                "SalesRepManagement" ,
                                false,
                                "user-tie",
                                "Sales Rep")
            )).build(),
            NavGetSections.builder()
                    .name("Settings")
                    .items(ImmutableList.of(
                            NavGetDataElementFactory
                                    .createNavGet(
                                            TestServicesConfig.getServiceUrls("www") + "MyAccount",
                                            "Preference",
                                            false,
                                            "users-cog",
                                            "My Account Settings")
                    )).build(),
            NavGetSections.builder()
                    .name("")
                    .items(ImmutableList.of(
                            NavGetDataElementFactory
                                    .createNavGet(
                                            TestServicesConfig.getServiceUrls("www") + "Home/MyUserProfile",
                                            "Profile",
                                            false,
                                            "user-circle",
                                            "My User Profile"),
                            NavGetDataElementFactory
                                    .createNavGet(
                                            "https://ffeuswdmsia107.ffe.foxeg.com/MicroStrategy/asp/Main.aspx?Server" +
                                                    "=FFEUSWDUXAP151.FFE.FOXEG.COM&Project=FMC&Port=0&evt=2001&" +
                                                    "src=Main.aspx.shared.fbb.fb.2001&folderID=FEE0993943AAC32ABDCF3C91E0188DA6",
                                            "Reports",
                                            false,
                                            "file-chart-line",
                                            "Reports"),
                            NavGetDataElementFactory
                                    .createNavGet(
                                            TestServicesConfig.getServiceUrls("imfManager"),
                                            "IMFManager",
                                            false,
                                            "list-alt",
                                            "IMF Manager"),
                            NavGetDataElementFactory
                                    .createNavGet(
                                            TestServicesConfig.getServiceUrls("www") + "Help",
                                            null,
                                            false,
                                            "question-circle",
                                            "Help"),
                            NavGetDataElementFactory
                                    .createNavGet(
                                            TestServicesConfig.getServiceUrls("static") + "policies/1/en-us/privacy.html",
                                            null,
                                            false,
                                            "question-circle",
                                            "Privacy Policy"),
                            NavGetDataElementFactory
                                    .createNavGet(
                                            TestServicesConfig.getServiceUrls("static") + "policies/1/help.html",
                                            null,
                                            false,
                                            "address-card",
                                            "Contact Us")
                    )).build());

    public static final List<NavGetSections> NON_ADMIN_NAV_GET_SECTIONS_DATA = ImmutableList.of(NavGetSections.builder()
            .name("Settings")
            .items(ImmutableList.of(
                    NavGetDataElementFactory
                            .createNavGet(
                                    TestServicesConfig.getServiceUrls("www") + "MyAccount",
                                    "Preference" ,
                                    false,
                                    "users-cog",
                                    "My Account Settings")
            )).build(),
            NavGetSections.builder()
                    .name("")
                    .items(ImmutableList.of(
                            NavGetDataElementFactory
                                    .createNavGet(
                                            TestServicesConfig.getServiceUrls("www") + "Home/MyUserProfile",
                                            "Profile",
                                            false,
                                            "user-circle",
                                            "My User Profile"),
                            NavGetDataElementFactory
                                    .createNavGet(
                                            TestServicesConfig.getServiceUrls("www") + "Help",
                                            null,
                                            false,
                                            "question-circle",
                                            "Help"),
                            NavGetDataElementFactory
                                    .createNavGet(
                                            TestServicesConfig.getServiceUrls("static") + "policies/1/en-us/privacy.html",
                                            null,
                                            false,
                                            "question-circle",
                                            "Privacy Policy"),
                            NavGetDataElementFactory
                                    .createNavGet(
                                            TestServicesConfig.getServiceUrls("static") + "policies/1/help.html",
                                            null,
                                            false,
                                            "address-card",
                                            "Contact Us")
                    )).build());

    public static final NavGetDataElement ADMIN_NAV_GET_DEFAULT_DATA =
            NavGetDataElementFactory
                    .createNavGet(
                            TestServicesConfig.getServiceUrls("marketing"),
                            "",
                            false,
                            "address-card",
                            "");

    public static final NavGetDataElement NON_ADMIN_NAV_GET_DEFAULT_DATA =
            NavGetDataElementFactory
                    .createNavGet(
                            TestServicesConfig.getServiceUrls("marketing"),
                            "",
                            false,
                            "address-card",
                            "");

}
