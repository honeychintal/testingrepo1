package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.model.NavGetDataElement;
import com.disney.dmdc.qa.model.NavGetSections;

import java.util.List;

public class TestNavGetSectionsData {

    public  static List<NavGetSections> getAdminNavSectionData(){
        return TestNavGetSections.ADMIN_NAV_GET_SECTIONS_DATA;
    }

    public  static List<NavGetSections> getMarketingNavSectionData(){
        return TestNavGetSections.NON_ADMIN_NAV_GET_SECTIONS_DATA;
    }

    public  static NavGetDataElement getAdminNavDefaultData() {
        return TestNavGetSections.ADMIN_NAV_GET_DEFAULT_DATA;
    }
    public  static NavGetDataElement getMarketingNavDefaultData() {
        return TestNavGetSections.NON_ADMIN_NAV_GET_DEFAULT_DATA;
    }
}
