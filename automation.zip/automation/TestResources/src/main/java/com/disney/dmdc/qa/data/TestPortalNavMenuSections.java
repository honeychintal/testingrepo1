package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.factory.PortalNavMenuDataElementFactory;
import com.disney.dmdc.qa.model.PortalNavMenuDataElement;
import com.disney.dmdc.qa.model.PortalNavMenuSections;
import com.disney.dmdc.qa.util.TestServicesConfig;
import com.google.common.collect.ImmutableList;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.List;

@AllArgsConstructor
@Getter
public class TestPortalNavMenuSections {

    public static final List<PortalNavMenuSections> ADMIN_NAV_MENU_SECTIONS_DATA = ImmutableList.of(PortalNavMenuSections.builder()
        .name("Manage")
        .items(ImmutableList.of(
            PortalNavMenuDataElementFactory
                    .CreatePortalNavMenu(
                            TestServicesConfig.getServiceUrls("admin") + "manage-titles",
                            "TitleManagement",
                            false,
                            "film",
                            "Titles"),
            PortalNavMenuDataElementFactory
                    .CreatePortalNavMenu(
                            TestServicesConfig.getServiceUrls("admin") + "manage-assets/1/appid",
                            "AssetManagement" ,
                            false,
                            "image",
                            "Assets"),
            PortalNavMenuDataElementFactory
                    .CreatePortalNavMenu(
                            TestServicesConfig.getServiceUrls("www") + "admin/Rights/Index",
                            "RightsManagement" ,
                            false,
                            "clipboard-check",
                            "Rights"),
            PortalNavMenuDataElementFactory
                    .CreatePortalNavMenu(
                            TestServicesConfig.getServiceUrls("rights") +"preauth",
                            "Authorizations" ,
                            false,
                            "clipboard-check",
                            "Authorization Dashboard"),
            PortalNavMenuDataElementFactory
                    .CreatePortalNavMenu(
                            TestServicesConfig.getServiceUrls("admin") + "manage-membership/users",
                            "UserManagement" ,
                            false,
                            "user",
                            "Users"),
            PortalNavMenuDataElementFactory
                    .CreatePortalNavMenu(
                            TestServicesConfig.getServiceUrls("admin") +"manage-membership/groups",
                            "GroupManagement" ,
                            false,
                            "users",
                            "Groups"),
            PortalNavMenuDataElementFactory
                    .CreatePortalNavMenu(
                            TestServicesConfig.getServiceUrls("admin") + "request/queue/my",
                            "RequestQueue" ,
                            false,
                            "user-cog",
                            "Request Queue"),
            PortalNavMenuDataElementFactory
                    .CreatePortalNavMenu(
                            TestServicesConfig.getServiceUrls("admin") + "request/queue/approval",
                            "ApprovalQueue",
                            false,
                            "user-check",
                            "Approval Queue"),
            PortalNavMenuDataElementFactory
                    .CreatePortalNavMenu(
                            TestServicesConfig.getServiceUrls("www") + "admin/RequestApproval/Index",
                            "RightsManagement" ,
                            false,
                            "tasks",
                            "License & Video Approval Queue"),
            PortalNavMenuDataElementFactory
                    .CreatePortalNavMenu(
                            TestServicesConfig.getServiceUrls("www") + "admin/Spotlight",
                            "SpotlightManagement" ,
                            false,
                            "megaphone",
                            "Spotlight"),
            PortalNavMenuDataElementFactory
                    .CreatePortalNavMenu(
                            TestServicesConfig.getServiceUrls("www") + "admin/Category",
                            "CategoryManagement" ,
                            false,
                            "images",
                            "Categories"),
            PortalNavMenuDataElementFactory
                    .CreatePortalNavMenu(
                            TestServicesConfig.getServiceUrls("www") + "admin/Notifications",
                            "NotificationsManagement" ,
                            false,
                            "bell",
                            "Notifications"),
            PortalNavMenuDataElementFactory
                    .CreatePortalNavMenu(
                            TestServicesConfig.getServiceUrls("www") + "admin/NewsAndAnnouncements",
                            "NewsManagement" ,
                            false,
                            "mail-bulk",
                            "News & Announcements"),
                PortalNavMenuDataElementFactory
                        .CreatePortalNavMenu(
                                TestServicesConfig.getServiceUrls("www") + "admin/SalesRep",
                                "SalesRepManagement" ,
                                false,
                                "user-tie",
                                "Sales Rep")
            )).build(),
            PortalNavMenuSections.builder()
                    .name("Settings")
                    .items(ImmutableList.of(
                            PortalNavMenuDataElementFactory
                                    .CreatePortalNavMenu(
                                            TestServicesConfig.getServiceUrls("www") + "MyAccount",
                                            "Preference",
                                            false,
                                            "users-cog",
                                            "My Account Settings")
                    )).build(),
            PortalNavMenuSections.builder()
                    .name("")
                    .items(ImmutableList.of(
                            PortalNavMenuDataElementFactory
                                    .CreatePortalNavMenu(
                                            TestServicesConfig.getServiceUrls("www") + "Home/MyUserProfile",
                                            "Profile",
                                            false,
                                            "user-circle",
                                            "My User Profile"),
                            PortalNavMenuDataElementFactory
                                    .CreatePortalNavMenu(
                                            "https://ffeuswdmsia107.ffe.foxeg.com/MicroStrategy/asp/Main.aspx?Server" +
                                                    "=FFEUSWDUXAP151.FFE.FOXEG.COM&Project=FMC&Port=0&evt=2001&" +
                                                    "src=Main.aspx.shared.fbb.fb.2001&folderID=FEE0993943AAC32ABDCF3C91E0188DA6",
                                            "Reports",
                                            false,
                                            "file-chart-line",
                                            "Reports"),
                            PortalNavMenuDataElementFactory
                                    .CreatePortalNavMenu(
                                            TestServicesConfig.getServiceUrls("imfManager"),
                                            "IMFManager",
                                            false,
                                            "list-alt",
                                            "IMF Manager"),
                            PortalNavMenuDataElementFactory
                                    .CreatePortalNavMenu(
                                            TestServicesConfig.getServiceUrls("www") + "Help",
                                            null,
                                            false,
                                            "question-circle",
                                            "Help"),
                            PortalNavMenuDataElementFactory
                                    .CreatePortalNavMenu(
                                            TestServicesConfig.getServiceUrls("static") + "policies/1/en-us/privacy.html",
                                            null,
                                            false,
                                            "question-circle",
                                            "Privacy Policy"),
                            PortalNavMenuDataElementFactory
                                    .CreatePortalNavMenu(
                                            TestServicesConfig.getServiceUrls("static") + "policies/1/help.html",
                                            null,
                                            false,
                                            "address-card",
                                            "Contact Us")
                    )).build());

    public static final List<PortalNavMenuSections> MARKETING_NAV_MENU_SECTIONS_DATA = ImmutableList.of(PortalNavMenuSections.builder()
            .name("Settings")
            .items(ImmutableList.of(
                    PortalNavMenuDataElementFactory
                            .CreatePortalNavMenu(
                                    TestServicesConfig.getServiceUrls("www") + "MyAccount",
                                    "Preference" ,
                                    false,
                                    "users-cog",
                                    "My Account Settings")
            )).build(),
            PortalNavMenuSections.builder()
                    .name("")
                    .items(ImmutableList.of(
                            PortalNavMenuDataElementFactory
                                    .CreatePortalNavMenu(
                                            TestServicesConfig.getServiceUrls("www") + "Home/MyUserProfile",
                                            "Profile",
                                            false,
                                            "user-circle",
                                            "My User Profile"),
                            PortalNavMenuDataElementFactory
                                    .CreatePortalNavMenu(
                                            TestServicesConfig.getServiceUrls("www") + "Help",
                                            null,
                                            false,
                                            "question-circle",
                                            "Help"),
                            PortalNavMenuDataElementFactory
                                    .CreatePortalNavMenu(
                                            TestServicesConfig.getServiceUrls("static") + "policies/1/en-us/privacy.html",
                                            null,
                                            false,
                                            "question-circle",
                                            "Privacy Policy"),
                            PortalNavMenuDataElementFactory
                                    .CreatePortalNavMenu(
                                            TestServicesConfig.getServiceUrls("static") + "policies/1/help.html",
                                            null,
                                            false,
                                            "address-card",
                                            "Contact Us")
                    )).build());

    public static final PortalNavMenuDataElement ADMIN_NAV_MENU_DEFAULT_DATA =
            PortalNavMenuDataElementFactory
                    .CreatePortalNavMenu(
                            TestServicesConfig.getServiceUrls("admin") + "manage-titles",
                            "TitleManagement",
                            false,
                            "address-card",
                            "Titles");

    public static final PortalNavMenuDataElement MARKETING_NAV_MENU_DEFAULT_DATA =
            PortalNavMenuDataElementFactory
                    .CreatePortalNavMenu(
                            TestServicesConfig.getServiceUrls("www") + "MyAccount",
                            "Preference",
                            false,
                            "address-card",
                            "My Account Settings");

}
