package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.model.PortalNavMenuDataElement;
import com.disney.dmdc.qa.model.PortalNavMenuSections;

import java.util.List;

public class TestPortalNavMenuSectionsData {

    public  static List<PortalNavMenuSections> getAdminNavSectionData(){
        return TestPortalNavMenuSections.ADMIN_NAV_MENU_SECTIONS_DATA;
    }

    public  static List<PortalNavMenuSections> getMarketingNavSectionData(){
        return TestPortalNavMenuSections.MARKETING_NAV_MENU_SECTIONS_DATA;
    }

    public  static PortalNavMenuDataElement getAdminNavDefaultData() {
        return TestPortalNavMenuSections.ADMIN_NAV_MENU_DEFAULT_DATA;
    }
    public  static PortalNavMenuDataElement getMarketingNavDefaultData() {
        return TestPortalNavMenuSections.MARKETING_NAV_MENU_DEFAULT_DATA;
    }
}
