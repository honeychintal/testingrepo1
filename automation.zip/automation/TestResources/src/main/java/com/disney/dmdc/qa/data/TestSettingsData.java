package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.model.SettingsResponse;

public class TestSettingsData {

    public static SettingsResponse getMarketingSettingsData(){

        return SettingsData.MARKETING_USER_SETTINGS_RESPONSE;
    }

    public static SettingsResponse getAdminSettingsData(){

        return SettingsData.ADMIN_USER_SETTINGS_RESPONSE;
    }

}
