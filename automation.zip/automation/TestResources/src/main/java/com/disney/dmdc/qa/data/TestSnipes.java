package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.model.Snipe;
import com.disney.dmdc.qa.type.Snipes;
import com.google.common.collect.ImmutableList;

import java.util.List;

public class TestSnipes {

    public static List<Snipe> getRelatedAssets() {

        return ImmutableList.of(Snipe.builder()
                .name(Snipes.RELATED_ASSETS.getName())
                .text(Snipes.RELATED_ASSETS.getText())
                .build()
        );
    }

}
