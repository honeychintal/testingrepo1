package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.model.TitleAdditionalCastItemsMahender;

import java.util.List;

public class TestTitleAdditionalCastItemsData_Mahender {
    public static List<TitleAdditionalCastItemsMahender> getAdminAdditionalItemsData()
    {
        return TestTitleAdditionalCastItemsMahender.TITLE_ADDITIONAL_CAST_RESPONSE_DATA_MAHENDER;
    }
}