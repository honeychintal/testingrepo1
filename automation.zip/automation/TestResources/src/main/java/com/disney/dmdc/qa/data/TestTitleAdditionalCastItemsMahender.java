package com.disney.dmdc.qa.data;
import com.disney.dmdc.qa.factory.TitleAdditionalCastItemsFactoryMahender;
import com.disney.dmdc.qa.model.TitleAdditionalCastItemsMahender;
import com.disney.dmdc.qa.model.TitleAdditionalCastResponseMahender;
import com.google.common.collect.ImmutableList;
import java.util.List;

public class TestTitleAdditionalCastItemsMahender{
    public static final List<TitleAdditionalCastItemsMahender> TITLE_ADDITIONAL_CAST_RESPONSE_DATA_MAHENDER =
            ImmutableList.of(
                    TitleAdditionalCastItemsFactoryMahender.CreateTitleAdditionalCast("LIZ MAY BRICE", "Supervisor"),
                    TitleAdditionalCastItemsFactoryMahender.CreateTitleAdditionalCast("GLENN CONROY", "Technician"),
                    TitleAdditionalCastItemsFactoryMahender.CreateTitleAdditionalCast("EOIN McCARTHY", "Karl"),
                    TitleAdditionalCastItemsFactoryMahender.CreateTitleAdditionalCast("KARIMA ADEBIBE", "Sacrificial Maiden"),
                    TitleAdditionalCastItemsFactoryMahender.CreateTitleAdditionalCast("TOM WOODRUFF, JR.", "Grid"),
                    TitleAdditionalCastItemsFactoryMahender.CreateTitleAdditionalCast("IAN WHYTE", "Scar"),
                    TitleAdditionalCastItemsFactoryMahender.CreateTitleAdditionalCast("GEORGE BERNOTA", "Puppeteers"),
                    TitleAdditionalCastItemsFactoryMahender.CreateTitleAdditionalCast("ALEC GILLIS, SETH RAYMOND HAYS", ""),
                    TitleAdditionalCastItemsFactoryMahender.CreateTitleAdditionalCast("MARC IRVIN, TIMOTHY LEACH", null),
                    TitleAdditionalCastItemsFactoryMahender.CreateTitleAdditionalCast("DAVID PENIKAS, GARTH WINKLESS", null),
                    TitleAdditionalCastItemsFactoryMahender.CreateTitleAdditionalCast("RICHARD VAN DEN BERGH", null),
                    TitleAdditionalCastItemsFactoryMahender.CreateTitleAdditionalCast("CHRIS CLARKE", null),
                    TitleAdditionalCastItemsFactoryMahender.CreateTitleAdditionalCast(" ", null)
            );
}




/*    public static final List<TitleAdditionalCastItemsMahender> TITLE_ADDITIONAL_CAST_RESPONSE_DATA_MAHENDER1=ImmutableList.of(
            TitleAdditionalCastItemsMahender.builder()
                    .talentName("LIZ MAY BRICE")
                    .roleName("Supervisor")
                    .talentName("GLENN CONROY")
                    .roleName("Technician")
                    .build()
    )*/








    /*
    public static final TitleAdditionalCastResponseMahender TITLE_ADDITIONAL_CAST_RESPONSE_DATA_MAHENDER = TitleAdditionalCastResponseMahender.builder()
            .items(ImmutableList.of(
                    TitleAdditionalCastItemsFactoryMahender.CreateTitleAdditionalCast("LIZ MAY BRICE", "Supervisor"),
                    TitleAdditionalCastItemsFactoryMahender.CreateTitleAdditionalCast("GLENN CONROY", "Technician"),
                    TitleAdditionalCastItemsFactoryMahender.CreateTitleAdditionalCast("EOIN McCARTHY", "Karl"),
                    TitleAdditionalCastItemsFactoryMahender.CreateTitleAdditionalCast("KARIMA ADEBIBE", "Sacrificial Maiden"),
                    TitleAdditionalCastItemsFactoryMahender.CreateTitleAdditionalCast("TOM WOODRUFF, JR.", "Grid"),
                    TitleAdditionalCastItemsFactoryMahender.CreateTitleAdditionalCast("IAN WHYTE", "Scar"),
                    TitleAdditionalCastItemsFactoryMahender.CreateTitleAdditionalCast("GEORGE BERNOTA", "Puppeteers"),
                    TitleAdditionalCastItemsFactoryMahender.CreateTitleAdditionalCast("ALEC GILLIS, SETH RAYMOND HAYS", ""),
                    TitleAdditionalCastItemsFactoryMahender.CreateTitleAdditionalCast("MARC IRVIN, TIMOTHY LEACH", null),
                    TitleAdditionalCastItemsFactoryMahender.CreateTitleAdditionalCast("DAVID PENIKAS, GARTH WINKLESS", null),
                    TitleAdditionalCastItemsFactoryMahender.CreateTitleAdditionalCast("RICHARD VAN DEN BERGH", null),
                    TitleAdditionalCastItemsFactoryMahender.CreateTitleAdditionalCast("CHRIS CLARKE", null),
                    TitleAdditionalCastItemsFactoryMahender.CreateTitleAdditionalCast("", null)))
            .PageIndex(0)
            .HttpStatusCode(0)
            .HasError(false)
            .build();*/
