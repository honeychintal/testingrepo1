package com.disney.dmdc.qa.data;

public class TestTitleData {
    public static TestTitles getTitleDUTvdHe() {
        return TestTitles.ALIEN_VS_PREDATOR_DU_TVD_HE;
    }

    public static TestTitles getTitleDUTvd() {
        return TestTitles.HELLO_CHEYENNE_DU_TVD;
    }

    public static TestTitles getTitleDUHe() {
        return TestTitles.HELLO_FRISCO_HELLO_DU_HE;
    }

    public static TestTitles getTitleAwardsTvdHe() {
        return TestTitles.MARY_TYLER_MOORE_TVD_HE_TITLE_AWARDS;
    }
}
