package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.model.TitleSearchResponse;

public class TestTitleSearch {
    public static TitleSearchResponse getTitleSearchResponseForValidTitleName(){

        return TestTitleSearchResponseData.SEARCH_RESPONSE_FOR_VALID_TITLE_NAME;
    }

    public static TitleSearchResponse getTitleSearchResponseForValidKeyword(){

        return TestTitleSearchResponseData.SEARCH_RESPONSE_FOR_VALID_KEYWORD;
    }

    public static TitleSearchResponse getTitleSearchResponseForValidTitleID(){

        return TestTitleSearchResponseData.SEARCH_RESPONSE_FOR_TITLE_ID;
    }

    public static TitleSearchResponse getTitleSearchResponseForAllTvSeasons(){

        return TestTitleSearchResponseData.SEARCH_RESPONSE_FOR_ALL_TV_SEASONS;
    }

    public static TitleSearchResponse getTitleSearchResponseForInvalidKeyword(){

        return TestTitleSearchResponseData.SEARCH_RESPONSE_FOR_INVALID_KEYWORD;
    }
}
