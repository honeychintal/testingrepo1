package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.factory.TitleSearchResponseFactory;
import com.disney.dmdc.qa.model.FacetKey;
import com.disney.dmdc.qa.model.FacetValue;
import com.disney.dmdc.qa.model.TitleSearchResponse;
import com.disney.dmdc.qa.model.TitleSearchResponseItem;
import com.disney.qa.constants.JsonUnit;
import com.google.common.collect.ImmutableList;

public class TestTitleSearchResponseData {
    public static final TitleSearchResponse SEARCH_RESPONSE_FOR_VALID_TITLE_NAME =
            TitleSearchResponseFactory.createSearchResponse(
                    JsonUnit.ANY_NUMBER_VALUE,
                    ImmutableList.of(
                            FacetKey.builder()
                                    .facets(
                                            ImmutableList.of(
                                                    FacetValue.builder()
                                                            .totalCount(1)
                                                            .type(0)
                                                            .id("titlename")
                                                            .name("120026 ( 038171 ) | Alien VS. Predator")
                                                            .value("120026 ( 038171 ) | Alien VS. Predator")
                                                            .selected(false)
                                                            .from(null)
                                                            .to(null)
                                                            .build()
                                            )
                                    )
                                    .type(0)
                                    .id("titlename")
                                    .name(" Title ID | Title Name")
                                    .selected(false)
                                    .build()
                    ),
                    ImmutableList.of(
                            TitleSearchResponseItem.builder()
                                    .id("e60b9856-1629-49b1-b089-adb01e59871e")
                                    .name("Alien VS. Predator")
                                    .label("2004")
                                    .releaseDate("2004-08-13T00:00:00")
                                    .previewId("ac4c42de-6758-4a4d-8b71-c01689254a0e")
                                    .synopsis("A team of scientists get caught up in a war between aliens and predators.")
                                    .snipes(
                                            ImmutableList.of()
                                    )
                                    .productType("Feature")
                                    .titleHoldback(false)
                                    .holdbackToAirdate(null)
                                    .wprId("038171")
                                    .cpmProductId(120026)
                                    .episodeDomesticForeignNumber("")
                                    .applicationTitleId(144388)
                                    .build()
                    ),
                    0,
                    JsonUnit.ANY_NUMBER_VALUE,
                    0,
                    false,
                    50
            );

    public static final TitleSearchResponse SEARCH_RESPONSE_FOR_VALID_KEYWORD =

            TitleSearchResponseFactory.createSearchResponse(
                    JsonUnit.ANY_NUMBER_VALUE,
                    ImmutableList.of(
                            FacetKey.builder()
                                    .facets(
                                            ImmutableList.of(
                                                    FacetValue.builder()
                                                            .totalCount(1)
                                                            .type(0)
                                                            .id("titlename")
                                                            .name("067226 | Alien: The Director's Cut - Do Not Use")
                                                            .value("067226 | Alien: The Director's Cut - Do Not Use")
                                                            .selected(false)
                                                            .from(null)
                                                            .to(null)
                                                            .build()
                                            )
                                    )
                                    .type(0)
                                    .id("titlename")
                                    .name(" Title ID | Title Name")
                                    .selected(false)
                                    .build()
                    ),
                    ImmutableList.of(
                            TitleSearchResponseItem.builder()
                                    .id("2d952db4-f215-4cd7-a509-1ac804736d8b")
                                    .name("Alien")
                                    .label("1979")
                                    .releaseDate("1979-05-25T00:00:00")
                                    .previewId("3075d29c-c964-4ef8-a715-46af89263078")
                                    .synopsis("A crew investigates an SOS on a remote planet and make a scary discovery.")
                                    .snipes(
                                            ImmutableList.of()
                                    )
                                    .productType("Feature")
                                    .titleHoldback(false)
                                    .holdbackToAirdate(null)
                                    .wprId("005337")
                                    .cpmProductId(121066)
                                    .episodeDomesticForeignNumber("")
                                    .applicationTitleId(136894)
                                    .build()
                    ),
                    0,
                    JsonUnit.ANY_NUMBER_VALUE,
                    0,
                    false,
                    50
            );

    public static final TitleSearchResponse SEARCH_RESPONSE_FOR_ALL_TV_SEASONS =

            TitleSearchResponseFactory.createSearchResponse(

                    JsonUnit.ANY_NUMBER_VALUE,
                    ImmutableList.of(
                            FacetKey.builder()
                                    .facets(
                                            ImmutableList.of(
                                                    FacetValue.builder()
                                                            .totalCount(1)
                                                            .type(0)
                                                            .id("titlename")
                                                            .name("012492 | Sherman Oaks")
                                                            .value("012492 | Sherman Oaks")
                                                            .selected(false)
                                                            .from(null)
                                                            .to(null)
                                                            .build()
                                            )
                                    )
                                    .type(0)
                                    .id("titlename")
                                    .name(" Title ID | Title Name")
                                    .selected(false)
                                    .build()
                    ),
                    ImmutableList.of(
                            TitleSearchResponseItem.builder()
                                    .id("c23cd4b4-77c7-404d-a761-ed9c240060e7")
                                    .name("1000 Days for the Planet")
                                    .label("2017")
                                    .releaseDate("2017-06-05T00:00:00")
                                    .snipes(
                                            ImmutableList.of()
                                    )
                                    .productType("Series")
                                    .titleHoldback(false)
                                    .holdbackToAirdate(null)
                                    .wprId("0DKA00")
                                    .cpmProductId(288721)
                                    .episodeDomesticForeignNumber("")
                                    .applicationTitleId(711256)
                                    .build()
                    ),
                    0,
                    JsonUnit.ANY_NUMBER_VALUE,
                    0,
                    false,
                    50
            );

    public static final TitleSearchResponse SEARCH_RESPONSE_FOR_INVALID_KEYWORD =

            TitleSearchResponseFactory.createSearchResponse(
                    JsonUnit.ANY_NUMBER_VALUE,
                    ImmutableList.of(
                            FacetKey.builder()
                                    .facets(
                                            ImmutableList.of(
                                                    FacetValue.builder()
                                                            .totalCount(0)
                                                            .type(1)
                                                            .id("releaseyear")
                                                            .selected(false)
                                                            .from(null)
                                                            .to(null)
                                                            .build()
                                            )
                                    )
                                    .type(1)
                                    .id("releaseyear")
                                    .name("Release Year Range")
                                    .selected(false)
                                    .build(),
                            FacetKey.builder()
                                    .facets(
                                            ImmutableList.of(
                                                    FacetValue.builder()
                                                            .totalCount(null)
                                                            .type(0)
                                                            .id("showtitleswithnoreleaseyear")
                                                            .name("Show Titles with no Release Year")
                                                            .value("showtitleswithnoreleaseyear")
                                                            .selected(false)
                                                            .from(null)
                                                            .to(null)
                                                            .build()
                                            )
                                    )
                                    .type(0)
                                    .id("showtitleswithnoreleaseyear")
                                    .name(null)
                                    .selected(false)
                                    .build()
                    ),
                    ImmutableList.of(),
                    0,
                    JsonUnit.ANY_NUMBER_VALUE,
                    0,
                    false,
                    50
            );

    public static final TitleSearchResponse SEARCH_RESPONSE_FOR_TITLE_ID =

            TitleSearchResponseFactory.createSearchResponse(
                    JsonUnit.ANY_NUMBER_VALUE,
                    ImmutableList.of(
                            FacetKey.builder()
                                    .facets(
                                            ImmutableList.of(
                                                    FacetValue.builder()
                                                            .totalCount(null)
                                                            .type(0)
                                                            .id("showtitleswithnoreleaseyear")
                                                            .name("Show Titles with no Release Year")
                                                            .value("showtitleswithnoreleaseyear")
                                                            .selected(false)
                                                            .from(null)
                                                            .to(null)
                                                            .build()
                                            )
                                    )
                                    .type(0)
                                    .id("showtitleswithnoreleaseyear")
                                    .name(null)
                                    .selected(false)
                                    .build()
                    ),
                    ImmutableList.of(
                            TitleSearchResponseItem.builder()
                                    .id("c3b93602-c31b-4313-ab04-9ab09e5fc0d0")
                                    .name("Hello, Dolly!")
                                    .label("1969")
                                    .releaseDate("1969-01-01T00:00:00")
                                    .previewId("c09cd9e4-a3a9-4784-8cd4-a62c0ffe4450")
                                    .synopsis("Matchmaker Dolly Levi orchestrates the " +
                                            "love lives of her friends while trying to figure out her own.")
                                    .snipes(
                                            ImmutableList.of()
                                    )
                                    .productType("Feature")
                                    .titleHoldback(false)
                                    .holdbackToAirdate(null)
                                    .wprId("000015")
                                    .cpmProductId(195058)
                                    .episodeDomesticForeignNumber("")
                                    .applicationTitleId(111298)
                                    .build()
                    ),
                    0,
                    JsonUnit.ANY_NUMBER_VALUE,
                    0,
                    false,
                    null
            );
}
