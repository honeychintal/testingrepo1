package com.disney.dmdc.qa.data;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum TestTitles {

    ALIEN_VS_PREDATOR_DU_TVD_HE(
            "e60b9856-1629-49b1-b089-adb01e59871e",
            "038171"
    ),

    HELLO_CHEYENNE_DU_TVD(
            "c853dbdb-5147-4753-8e99-c5b420b7c977",
            "135095"
    ),

    HELLO_FRISCO_HELLO_DU_HE(
            "a0de4fe9-3657-4482-9f8f-4a3c9dec209c",
            "011027"
    ),

    ATLANTA(
            "b6a8e921-1e8c-4c2a-b483-754386e01cae",
            "YSK000"
    ),

    HOWIMET_URMOTHER_ONE(
            "0c622684-29d7-4243-a7f8-3b5a27232362",
            "1ALH00"
    ),

    NIMONA(
            "dd4f3c11-9478-4edf-92a5-d75b00fc9310",
            "032053"
    ),

    MARY_TYLER_MOORE_TVD_HE_TITLE_AWARDS(
            "4EC90BDE-0817-4916-9202-2ABB0FADBE1F",
            "203814"
    ),

    APOCALYPTO_DU_TVD(
            "e91aad9b-0102-4126-99e5-c01694ab83e7",
            "089313"
    ),

    DIARY_OF_A_WIMPY_KID_RODRICKRULES_DU_HE(
            "d32378bd-553a-4552-b91f-6812e28757c8",
            "126575"
    ),

    NEW_GIRL(
            "2fc9f9fc-a527-4245-922f-0890d888d2ff",
            "194406"
    );

    private String titleId;
    private String wprids;
}
