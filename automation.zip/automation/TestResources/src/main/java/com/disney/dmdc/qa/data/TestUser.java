package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.constant.DmdcHeaders;
import com.disney.dmdc.qa.util.AntiforgeryUtils;

import java.net.HttpCookie;
import java.util.List;

public class TestUser {

    private String username = null;
    private String password = null;
    private String dmdstats = null;
    private List<HttpCookie> antiforgeryCookiesMarketing = null;
    private List<HttpCookie> antiforgeryCookiesAdmin = null;

    // Badly formatted value
    public static final String INVALID_DMDSTATS;
    public static final String EMPTY_DMDSTATS;
    public static final String INVALID_XSRF;
    public static final String INVALID_ANTIFORGERY;

    static {
        // replace/delete/add few characters to make dmdstats value as invalid
        INVALID_DMDSTATS = "g0oq0y6%2FMnJgWUfa6L5ESJPePDBCj5dGqEYy3veHW4gvzrQ9V7TrtA%3D%3D";
        EMPTY_DMDSTATS = "";
        INVALID_XSRF = "CfDJ8MsonOVtx0tMqIF3Iwn81uH472LpD71zTLsPxXifILVL5ZjSWLn1WTrNmY6L1DiReWSgYxsCNVQ2LdE4I8UM0v9";
        INVALID_ANTIFORGERY = "CfDJ8MsonOVtx0tMqIF3Iwn81uE0Q2HAr-0CUujc9oXk0rdZcqBBdHG7_Zqkigj3AcYqO5";
    }

    public TestUser(String username, String password, String dmdstats) {
        setUserNameAndPassword(username, password);
        this.dmdstats = dmdstats;
    }

    public void setUserNameAndPassword(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getDmdstats() {
        //Need to implement getting the dmdstats from username/password
        //This is temporarily being set at construction time at the TestUserCache utility
        return dmdstats;
    }

    public List<HttpCookie> getAntiforgeryCookiesMarketing() {
        if(this.antiforgeryCookiesMarketing == null) {
            this.antiforgeryCookiesMarketing = AntiforgeryUtils.getAntiforgeryCookiesMarketing(this.getDmdstats());
        }

        return(this.antiforgeryCookiesMarketing);
    }

    public List<HttpCookie> getAntiforgeryCookiesAdmin() {
        if(this.antiforgeryCookiesAdmin == null) {
            this.antiforgeryCookiesAdmin = AntiforgeryUtils.getAntiforgeryCookiesAdmin(this.getDmdstats());
        }

        return(this.antiforgeryCookiesAdmin);
    }

    public String getXSRFCookieMarketing(){
        List<HttpCookie> cookies = AntiforgeryUtils.getAntiforgeryCookiesMarketing(this.getDmdstats());
        String antiCookieValue = null;
        for(HttpCookie cookie : cookies ){
            if(cookie.getName().equals(DmdcHeaders.XSRF_COOKIE_NAME)){
                antiCookieValue=cookie.getValue();
                break;
            }
        }
        return antiCookieValue;
    }

    public String getAntiforgeryCookieMarketing(){
        List<HttpCookie> cookies = AntiforgeryUtils.getAntiforgeryCookiesMarketing(this.getDmdstats());
        String antiCookieValue = null;
        for(HttpCookie cookie : cookies ){
            if(cookie.getName().equals(DmdcHeaders.ANTIFORGERY_COOKIE_NAME)){
                antiCookieValue=cookie.getValue();
                break;
            }
        }
        return antiCookieValue;
    }
}