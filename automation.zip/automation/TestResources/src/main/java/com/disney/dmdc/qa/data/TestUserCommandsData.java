package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.model.UserCommandsItem;

import java.util.List;

public class TestUserCommandsData {

    public static List<UserCommandsItem> getUserCommandsItems() {

        return TestUserCommandsItems.USER_COMMANDS_ITEMS;
    }

    public static Integer getUserId() {

        return TestUserCommandsItems.marketingTvdHeUserId;
    }
}