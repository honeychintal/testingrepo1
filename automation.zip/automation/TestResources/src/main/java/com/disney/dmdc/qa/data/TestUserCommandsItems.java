package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.constant.TestAccounts;
import com.disney.dmdc.qa.factory.UserCommandsItemFactory;
import com.disney.dmdc.qa.model.UserCommandsItem;
import com.disney.dmdc.qa.model.UserCommandsItemProperties;
import com.disney.dmdc.qa.util.TestServicesConfig;
import com.google.common.collect.ImmutableList;

import java.util.List;

public class TestUserCommandsItems {

    public static final Integer marketingTvdHeUserId = TestAccounts.TEST_TVD_HE_USER.getId();

    public static final List<UserCommandsItem> USER_COMMANDS_ITEMS = ImmutableList.of(
         UserCommandsItemFactory.createUserCommandsItem(
                 UserCommandsItemProperties.builder()
                         .url(TestServicesConfig.getServiceUrls("www")+"Home/Emulate/"+marketingTvdHeUserId+"/")
                         .build(),
                 "Emulate for DMD Central",
                 "Emulate for DMD Central",
                 1,
                 "emulate"
         ),
         UserCommandsItemFactory.createUserCommandsItem(
                 null,
                 "Reset User",
                 "Send 'Welcome...' email to user.  User will be prompted for a new Security Question " +
                         "& Answer upon clicking link in the 'Welcome...' email.",
                 2,
                 "resetuser"
         ),
         UserCommandsItemFactory.createUserCommandsItem(
                 null,
                 "OKTA Options",
                 "OKTA Options",
                 4,
                 "oktaoptions"
         ),
         UserCommandsItemFactory.createUserCommandsItem(
                 null,
                 "Reset Password",
                 "Reset Password",
                 5,
                 "resetpassword"
         )
    );
}