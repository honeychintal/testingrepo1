package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.model.UserCommentsResult;

public class TestUserCommentsData {

    public static UserCommentsResult getUserComments(){

        return TestUserCommentsResult.USER_COMMENTS;
    }

    public static UserCommentsResult getEmptyComments(){

        return TestUserCommentsResult.EMPTY_COMMENTS;
    }

}
