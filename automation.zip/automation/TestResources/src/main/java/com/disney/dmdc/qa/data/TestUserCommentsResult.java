package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.model.UserCommentsItems;
import com.disney.dmdc.qa.model.UserCommentsResult;
import com.google.common.collect.ImmutableList;

import java.util.Collections;
import java.util.List;

public class TestUserCommentsResult {

    private static final List<UserCommentsItems> emptyComments = Collections.emptyList();

    public static final UserCommentsResult USER_COMMENTS = UserCommentsResult
            .builder()
            .id(0)
            .isEditable(true)
            .isUserOwnRequest(false)
            .comments(ImmutableList.of(UserCommentsItems.builder()
                    .id(51892)
                    .body("Some test comments QA")
                    .created("2021-06-29T15:20:14.8433333+00:00")
                    .createdBy("admin-user User")
                    .build()
            ))
            .idPProviders(ImmutableList.of())
            .build();

    public static final UserCommentsResult EMPTY_COMMENTS = UserCommentsResult
            .builder()
            .id(0)
            .isEditable(true)
            .isUserOwnRequest(false)
            .comments(emptyComments)
            .idPProviders(ImmutableList.of())
            .build();

}
