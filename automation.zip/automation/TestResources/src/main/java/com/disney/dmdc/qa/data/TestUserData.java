package com.disney.dmdc.qa.data;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum TestUserData {

    ACTIVE_USER_ID(
            111174,
            "Test_user06apr03@dmdcentral.com"
    ),

    INACTIVE_USER_ID(
            110976,
            "Test.User12@dmdcentral.com"
    ),

    TERMINATED_USER_ID(
            51278,
            "Test_3_2_7.Fox@Fox.com"
    ),

    DISABLED_USER_ID(
            111433,
            "Roumeliatest.20thcenturystudios001@20thcenturystudios.com"
    ),

    ACTIVE_USER_ID_NO_COMMENTS(
            111408,
            "test_tvd_and_he_user@dmdcentral.com"
    ),

    TEST_USER_ID(
            111711,
            "testuservp1@dmdcentral.com"
    );

    private int userId;
    private String email;

}
