package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.model.UserGroupsResult;

public class TestUserGroupsResultData {

    public static UserGroupsResult getTestTvdHEUserGroups() {

        return TestUserGroupsResult.TEST_TVD_HE_USER_GROUPS;
    }
}
