package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.model.MembershipUserIdResult;

public class TestUserIdResultData {

    public static MembershipUserIdResult getTestUserIdDetails() {

        return TestUserIdResult.TEST_USER_ID;
    }
}