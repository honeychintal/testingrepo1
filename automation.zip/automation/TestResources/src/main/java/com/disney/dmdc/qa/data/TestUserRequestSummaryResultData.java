package com.disney.dmdc.qa.data;

import com.disney.dmdc.qa.model.UserRequestSummaryResult;

public class TestUserRequestSummaryResultData {

    public static UserRequestSummaryResult getTestUserRequestSummary(){

        return TestUserRequestSummaryResult.USER_REQUEST_SUMMARY;
    }

    public static UserRequestSummaryResult getInactiveUserRequestSummary(){

        return TestUserRequestSummaryResult.INACTIVE_USER_REQUEST_SUMMARY;
    }

    public static UserRequestSummaryResult getTerminatedUserRequestSummary(){

        return TestUserRequestSummaryResult.TERMINATED_USER_REQUEST_SUMMARY;
    }

    public static UserRequestSummaryResult getDisabledUserRequestSummary(){

        return TestUserRequestSummaryResult.DISABLED_USER_REQUEST_SUMMARY;
    }
}
