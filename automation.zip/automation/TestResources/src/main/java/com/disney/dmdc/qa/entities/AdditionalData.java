package com.disney.dmdc.qa.entities;

import lombok.Builder;
import lombok.Getter;

import java.util.List;

@Getter
@Builder
public class AdditionalData {

    private final List<ReleaseDate> releaseDates;
    private final List<RunTime> runTimes;
    private final List<Rights> rights;
}


