package com.disney.dmdc.qa.entities;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
@JsonInclude(JsonInclude.Include.ALWAYS)
@JsonIgnoreProperties({"CreatedDate", "LastModifiedDate"})
public class ApplicationTitle {
    private int lastModifiedBy;
    private String lastModifiedDate;
    private String hideReleaseToAirDate;
    private String expiryDate;
    private String hideLongSynopsistoAirDate;
    @JsonProperty("isHideLongSynopsis")
    private boolean isHideLongSynopsis;
    @JsonProperty("IsHideReleaseDate")
    private boolean isHideReleaseDate;
    @JsonProperty("isDeleted")
    private boolean isDeleted;
    private String holdbackToAirdate;
    @JsonProperty("isHideEpisodeNames")
    private boolean isHideEpisodeNames;
    private String applicationTitleGuid;
    private String hideLongSynopsisDate;
    private String assetCopyrightStatusId;
    private String hideReleaseUntilDate;
    private String imagesAvailability;
    private int createdBy;
    private String assetCopyright;
    private int duFlag;
    private int applicationTitleId;
    private int sortOrder;
    private int productTypeId;
    private String holdbackDate;
    @JsonProperty("isHoldback")
    private boolean isHoldback;
    private String hideEpisodesNamesDate;
    private String hideEpisodesNamestoAirDate;
    private String createdDate;
    private int statusId;
    private int applicationId;
    private int titleId;
    private String effectiveDate;
    @JsonProperty("IsCurrentSeason")
    private boolean isCurrentSeason;
}