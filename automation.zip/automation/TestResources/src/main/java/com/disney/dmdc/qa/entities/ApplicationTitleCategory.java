package com.disney.dmdc.qa.entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import microsoft.sql.DateTimeOffset;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
@JsonInclude(JsonInclude.Include.ALWAYS)
@JsonIgnoreProperties({"CreatedDate"})
public class ApplicationTitleCategory {
    private int applicationTitleCategoryId;
    private int applicationTitleId;
    private int sortOrder;
    private int createdBy;
    private DateTimeOffset createdDate;
}
