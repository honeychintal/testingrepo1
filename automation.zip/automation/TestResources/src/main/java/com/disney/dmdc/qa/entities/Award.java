package com.disney.dmdc.qa.entities;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class Award {

    private Integer titleVersionAwardAwardCategoryId;
    private Integer awardYear;
    private Integer awardCategoryId;
    private String awardCategoryName;
    private Integer awardId;
    private String awardName;
    private String awardAlias;
    private String talentName;
    private Boolean isWin;
    private Integer sortOrder;
    private Integer talentId;
    private String awardCategoryText;
    private Integer status;
}
