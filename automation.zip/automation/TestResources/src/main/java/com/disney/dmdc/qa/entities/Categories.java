package com.disney.dmdc.qa.entities;

import lombok.Builder;
import lombok.Getter;

import java.util.List;

@Getter
@Builder
public class Categories {

    private final List<Category> categories;
    private final List<CategoriesSortOptions> sortOptions;
}
