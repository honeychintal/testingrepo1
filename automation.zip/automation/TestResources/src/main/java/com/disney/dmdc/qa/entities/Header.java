package com.disney.dmdc.qa.entities;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
@JsonInclude(JsonInclude.Include.ALWAYS)
public class Header {
    private int applicationTitleId;
    private int distributionUnitId;
    private String wprId;
    private int titleId;
    private int titleVersionId;
    private String titleName;
    private String localTitleName;
    private String seasonName;
    private Integer episodeNumber;
    private String episodeName;
    private String concept;
    private String releaseDate;
    private int runTime;
    private String usBroadcast;
    private int productTypeId;
    private int isHoldBack;
    private int statusId;
    private String division;
    private String rating;
    private String genres;
    private String themes;
    private String synopsis;
    private String overview;
    @JsonProperty("FNT_Instructions")
    private String fnt_Instructions;
    private String titleRepImage_PreviewId;
    private int titleRepImage_ApplicationAssetId;
    private String backgroundImage_PreviewId;
    private int cpmProductId;
    private String foreignEpisodeNumber;
    private String domesticEpisodeNumber;
}