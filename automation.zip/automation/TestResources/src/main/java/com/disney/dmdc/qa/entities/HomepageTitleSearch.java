package com.disney.dmdc.qa.entities;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
@JsonInclude(JsonInclude.Include.ALWAYS)
public class HomepageTitleSearch {
    private int applicationTitleId;
    private int applicationId;
    private int duFlag;
    private String wprId;
    @JsonProperty("TitleName_Main")
    private String titleNameMain;
    @JsonProperty("TitleName_Secondary")
    private String titleNameSecondary;
    private int sequenceNumber;
    private int productTypeId;
    private Date releaseDate;
    @JsonProperty("Thumbnail_PreviewId")
    private String thumbnail_PreviewId;
    @JsonProperty("Thumbnail_DomainNumber")
    private int thumbnailDomainNumber;
    private String synopsis;
    private String applicationTitleGuid;
    private byte[] dataHash;
    private int cpmProductId;
    private String foreignEpisodeNumber;
    private String domesticEpisodeNumber;
}
