package com.disney.dmdc.qa.entities;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class License {
    private Integer distributionUnitId;
    private Integer duFlag;
    private String distributionUnitName;
    private String startDate;
    private String endDate;
    private Boolean isDefault;
    private Integer productType;

}
