package com.disney.dmdc.qa.entities;

import lombok.Builder;
import lombok.Getter;

import java.util.List;

@Getter
@Builder
public class QuickView {
    private final List<Title> titles;
    private final List<Talent> talents;
    private final List<ReleaseDate> releaseDates;
    private final List<RunTime> runTimes;
    private final List<Description> descriptions;
    private final List<Comment> comments;
}
