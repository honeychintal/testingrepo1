package com.disney.dmdc.qa.entities;

import java.util.List;
import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class SearchTab {
    private final List<Item> items;
    private final List<AssetGroup> assetGroups;
}
