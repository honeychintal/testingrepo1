package com.disney.dmdc.qa.entities;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class Talent {

    private Integer talentId;
    private Integer creditTypeId;
    private String creditTypeDescription;
    private String talentName;
    private String talentPrefix;
    private String talentSuffix;
    private String roleName;
    private Integer castTypeId;
    private String castType;
    private Boolean hasBio;
    private Integer sortOrder;
}
