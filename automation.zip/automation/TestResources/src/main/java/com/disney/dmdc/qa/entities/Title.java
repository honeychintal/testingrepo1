package com.disney.dmdc.qa.entities;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
@JsonInclude(JsonInclude.Include.ALWAYS)
public class Title {
    private Integer applicationTitleId;
    private Integer distributionUnitId;
    private String wprId;
    private Integer titleId;
    private Integer titleVersionId;
    private String titleName;
    private String localTitleName;
    private String seasonName;
    private Integer episodeNumber;
    private String episodeName;
    private String concept;
    private Integer runTime;
    private String usBroadcast;
    private Integer productTypeId;
    @JsonProperty("isHoldBack")
    private Boolean isHoldBack;
    private Integer statusId;
    private String division;
    private String rating;
    private String genres;
    private String themes;
    private String synopsis;
    private String overview;
    private String fnt_Instructions;
    private String titleRepImage_PreviewId;
    private Integer titleRepImage_ApplicationAssetId;
    private String backgroundImage_PreviewId;
    private Integer cpmProductId;
    private String foreignEpisodeNumber;
    private String domesticEpisodeNumber;
}
