package com.disney.dmdc.qa.entities;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class TitleHierarchy {

    private String applicationTitleGuid;
    @JsonProperty("TitleName_Series")
    private String titleName_Series;
    @JsonProperty("TitleName_Season")
    private String titleName_Season;
    @JsonProperty("TitleName_Episode")
    private String titleName_Episode;
    private Integer seasonNumber;
    private Integer episodeNumber;
    @JsonProperty("CpmProductId_Series")
    private Integer cpmProductId_Series;
    @JsonProperty("CpmProductId_Season")
    private Integer cpmProductId_Season;
    @JsonProperty("CpmProductId_Episode")
    private Integer cpmProductId_Episode;
    private String foreignEpisodeNumber;
    private String domesticEpisodeNumber;
}
