package com.disney.dmdc.qa.entities;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class TitleSuggestItem {
    String applicationTitleGuid;
    String titleName_Main;
    String titleName_Secondary;
    String releaseDate;
    Boolean titleHoldback;
    String wprid;
    Integer cpmProductId;
    String foreignEpisodeNumber;
    String domesticEpisodeNumber;
    Integer applicationTitleId;
}
