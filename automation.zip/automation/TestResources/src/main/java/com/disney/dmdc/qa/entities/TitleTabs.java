package com.disney.dmdc.qa.entities;

import lombok.Builder;
import lombok.Getter;

import java.util.List;

@Getter
@Builder
public class TitleTabs {

    private final List<TabNames> tabNames;
    private final List<TabAssets> tabAssets;
}
