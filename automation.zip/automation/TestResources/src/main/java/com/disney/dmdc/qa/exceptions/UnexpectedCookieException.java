package com.disney.dmdc.qa.exceptions;

public class UnexpectedCookieException extends RuntimeException {

    public UnexpectedCookieException() {
    }

    public UnexpectedCookieException(String message) {
        super(message);
    }

    public UnexpectedCookieException(String message, Throwable cause) {
        super(message, cause);
    }

    public UnexpectedCookieException(Throwable cause) {
        super(cause);
    }

    public UnexpectedCookieException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
