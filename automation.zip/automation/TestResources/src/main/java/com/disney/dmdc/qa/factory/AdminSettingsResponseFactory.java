package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.data.TestAdminSettingsData;
import com.disney.dmdc.qa.model.AdminSettingsGetResponse;

public class AdminSettingsResponseFactory {

    public static AdminSettingsGetResponse createSettingsResponse(AdminSettingsGetResponse settingsData) {
        return settingsData;
    }

    public static AdminSettingsGetResponse createDefaultResponse() {
        return createSettingsResponse(TestAdminSettingsData.getSettingsResponse());
    }
}
