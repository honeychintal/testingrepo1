package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.entities.AudioChannel;
import com.disney.dmdc.qa.exceptions.DbException;
import com.disney.dmdc.qa.model.AssetAudioChannels;
import com.disney.dmdc.qa.util.db.DmdCentralDbUtils;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AssetAudioChannelsFactory {

    public static AssetAudioChannels createAssetAudioChannelItem (
            Integer channelNumber, String channelLanguage, String channelConfig, String channelFormat,
            String channelUsage, String channelDynamicRange) {

        return AssetAudioChannels.builder()
                .channelNumber(channelNumber)
                .audioChannelLanguage(channelLanguage)
                .audioChannelConfig(channelConfig)
                .audioChannelFormat(channelFormat)
                .audioChannelUsage(channelUsage)
                .audioChannelDynamicRange(channelDynamicRange)
                .build();
    }

    public static List<AssetAudioChannels> createAssetAudioChannels (Integer assetId) {

        List<AssetAudioChannels> assetAudioChannelsList = new ArrayList<AssetAudioChannels>();

        try {

            List<AudioChannel> audioChannelList = DmdCentralDbUtils.callAssetAudioChannelToList(assetId);

            for (AudioChannel audioChannel : audioChannelList) {
                assetAudioChannelsList.add(
                        createAssetAudioChannelItem(
                                audioChannel.getChannelNumber(),
                                audioChannel.getAudioChannelLanguage(),
                                audioChannel.getAudioChannelConfig(),
                                audioChannel.getAudioChannelFormat(),
                                audioChannel.getAudioChannelUsage(),
                                audioChannel.getAudioChannelDynamicRange()
                        )
                );
            }

            return assetAudioChannelsList;

        } catch (SQLException e) {
            throw new DbException("SQL Exception occurred", e);
        }
    }
}