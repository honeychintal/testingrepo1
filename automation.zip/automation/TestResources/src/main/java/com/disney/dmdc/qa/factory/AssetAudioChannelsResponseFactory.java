package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.AssetAudioChannels;
import com.disney.dmdc.qa.model.AssetAudioChannelsResponse;

import java.util.List;

public class AssetAudioChannelsResponseFactory {

    public static AssetAudioChannelsResponse createAssetAudioChannelsResponse (
            List<AssetAudioChannels> audioChannels, Integer pageIndex, Integer statusCode, boolean errorFlag) {

        return AssetAudioChannelsResponse.builder()
                .items(audioChannels)
                .pageIndex(pageIndex)
                .httpStatusCode(statusCode)
                .hasError(errorFlag)
                .build();
    }

    public static AssetAudioChannelsResponse createExpectedAssetAudioChannelsResponse(Integer assetId) {

        return createAssetAudioChannelsResponse(
                AssetAudioChannelsFactory.createAssetAudioChannels(assetId),
                0,
                0,
                false);
    }
}