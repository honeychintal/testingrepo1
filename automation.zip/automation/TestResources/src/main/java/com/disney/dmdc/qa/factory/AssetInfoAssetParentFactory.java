package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.AssetInfoAssetOrParent;
import com.disney.dmdc.qa.model.Snipe;

import java.util.List;

public class AssetInfoAssetParentFactory {

    public static AssetInfoAssetOrParent createAssetInfoAssetParent(
            int id, int parentId, int orderNo, String titleName, String wprId, int cpmProductId, String episodeDomesticForeignNumber,
            String firstReleaseDate, int titleHoldback, int assetHoldback, String assetStatus, String assetName,
            String espritNumId, int assetTypeId, int productTypeId, String createdDate, String assetGroup, String groupParent,
            boolean isMain, boolean isExclusive, int isIntl, int isTVDOnly, boolean isLimitedUse, int isPublic, String modifiedDate,
            int repositoryId, String assetType, String subAssetType, String versionName, String versionDescription, int versionId,
            String aperture, String dubbedLanguage, String textedLanguage, String conformedLanguage, String territory, String runTime,
            String fileName, long fileSize, String division, String department, String frameRate, String resolution, String canvasAspectRatio,
            String videoAspectRatio, String canvasHeight, String canvasWidth, String videoCodec, String videoBitRate, String audioCodec,
            String audioBitDepth, String videoNotes, String audioChannel1Config, String audioChannel1Language, String audioChannel1Format,
            String audioChannel1DynamicRange, String audioChannel2Config, String audioChannel2Language, String audioChannel2Format,
            boolean isReplaced, boolean isReplacementExpired, int view, int download, int stream, int bQDownload, String productType,
            String createdBy, String modifiedBy, String deliveryType, boolean inCart, boolean thumbnailCanAnimate, boolean isPlayable,
            boolean isZoomSupported, int actions, List<Snipe> snipes) {

        return AssetInfoAssetOrParent.builder()
                .id(id)
                .parentId(parentId)
                .orderNo(orderNo)
                .titleName(titleName)
                .wprId(wprId)
                .cpmProductId(cpmProductId)
                .episodeDomesticForeignNumber(episodeDomesticForeignNumber)
                .firstReleaseDate(firstReleaseDate)
                .titleHoldback(titleHoldback)
                .assetHoldback(assetHoldback)
                .assetStatus(assetStatus)
                .assetName(assetName)
                .espritNumId(espritNumId)
                .assetTypeId(assetTypeId)
                .productTypeId(productTypeId)
                .createdDate(createdDate)
                .assetGroup(assetGroup)
                .groupParent(groupParent)
                .isMain(isMain)
                .isExclusive(isExclusive)
                .isIntl(isIntl)
                .isTVDOnly(isTVDOnly)
                .isLimitedUse(isLimitedUse)
                .isPublic(isPublic)
                .modifiedDate(modifiedDate)
                .repositoryId(repositoryId)
                .assetType(assetType)
                .subAssetType(subAssetType)
                .versionName(versionName)
                .versionDescription(versionDescription)
                .versionId(versionId)
                .aperture(aperture)
                .dubbedLanguage(dubbedLanguage)
                .textedLanguage(textedLanguage)
                .conformedLanguage(conformedLanguage)
                .territory(territory)
                .runTime(runTime)
                .fileName(fileName)
                .fileSize(fileSize)
                .division(division)
                .department(department)
                .frameRate(frameRate)
                .resolution(resolution)
                .canvasAspectRatio(canvasAspectRatio)
                .videoAspectRatio(videoAspectRatio)
                .canvasHeight(canvasHeight)
                .canvasWidth(canvasWidth)
                .videoCodec(videoCodec)
                .videoBitRate(videoBitRate)
                .audioCodec(audioCodec)
                .audioBitDepth(audioBitDepth)
                .videoNotes(videoNotes)
                .audioChannel1Config(audioChannel1Config)
                .audioChannel1Language(audioChannel1Language)
                .audioChannel1Format(audioChannel1Format)
                .audioChannel1DynamicRange(audioChannel1DynamicRange)
                .audioChannel2Config(audioChannel2Config)
                .audioChannel2Language(audioChannel2Language)
                .audioChannel2Format(audioChannel2Format)
                .isReplaced(isReplaced)
                .isReplacementExpired(isReplacementExpired)
                .view(view)
                .download(download)
                .stream(stream)
                .bQDownload(bQDownload)
                .productType(productType)
                .createdBy(createdBy)
                .modifiedBy(modifiedBy)
                .deliveryType(deliveryType)
                .inCart(inCart)
                .thumbnailCanAnimate(thumbnailCanAnimate)
                .isPlayable(isPlayable)
                .isZoomSupported(isZoomSupported)
                .actions(actions)
                .snipes(snipes).build();
    }

}
