package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.AssetInfoResponse;
import com.disney.dmdc.qa.model.AssetInfoResult;

public class AssetInfoResponseFactory {

    public static AssetInfoResponse createAssetInfoResponse(
            AssetInfoResult result, Integer httpStatusCode, Boolean hasError) {

        return AssetInfoResponse.builder()
                .result(result)
                .httpStatusCode(httpStatusCode)
                .hasError(hasError)
                .build();
    }

    public static AssetInfoResponse createDefaultAssetInfoResponse(AssetInfoResult result) {

        return createAssetInfoResponse(
                result,
                0,
                false
        );
    }

}
