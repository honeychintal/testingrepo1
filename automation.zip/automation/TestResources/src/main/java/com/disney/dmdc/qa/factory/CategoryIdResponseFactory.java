package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.entities.ApplicationTitle;
import com.disney.dmdc.qa.entities.Categories;
import com.disney.dmdc.qa.entities.CategoriesSortOptions;
import com.disney.dmdc.qa.entities.Category;
import com.disney.dmdc.qa.exceptions.DbException;
import com.disney.dmdc.qa.model.CategoryIdResponse;
import com.disney.dmdc.qa.model.CategoryIdResult;
import com.disney.dmdc.qa.model.CategorySortOptions;
import com.disney.dmdc.qa.util.db.DmdCentralDbUtils;
import lombok.experimental.UtilityClass;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@UtilityClass
public class CategoryIdResponseFactory {

    public static CategoryIdResponse CreateCategoryIdResponse (
            CategoryIdResult result, Integer statusCode, boolean error) {

        return CategoryIdResponse.builder()
                .result(result)
                .httpStatusCode(statusCode)
                .hasError(error)
                .build();
    }

    public static CategoryIdResponse createDefaultCategoryIdResponseFromDB(String appTitleGuid, int userId, String queryType, String category) {

        try {

            ApplicationTitle appTitle = DmdCentralDbUtils.selectApplicationTitle(appTitleGuid);

            Categories categoriesList = DmdCentralDbUtils.callCategoriesGetCategoryList(appTitle.getApplicationId(), userId, queryType, category);

            List<CategorySortOptions> categorySortOptions = new ArrayList<>();

            String categoryId = null;
            String categoryName = null;

            for (Category categoryDB : categoriesList.getCategories()) {

                categoryId = categoryDB.getCategoryId();
                categoryName = categoryDB.getCategoryName();

                for (CategoriesSortOptions sortOptionsDB : categoriesList.getSortOptions()) {
                    if (categoryDB.getCategoryId().equals(sortOptionsDB.getCategoryId())) {
                        categorySortOptions.add(CategorySortOptions.builder()
                                .id(sortOptionsDB.getOptionId())
                                .name(sortOptionsDB.getOptionName())
                                .selected(sortOptionsDB.getIsSelected())
                                .build());
                    }
                }
            }
            return CreateCategoryIdResponse(CategoryIdResult.builder()
                            .id(categoryId.toLowerCase())
                            .name(categoryName)
                            .totalNumberOfRows(0)
                            .sortOptions(categorySortOptions)
                            .build(),
                    0,
                    false);

        } catch (SQLException e) {
            throw new DbException("SQL Exception occurred", e);
        }
    }
}
