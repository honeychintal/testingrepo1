package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.entities.ApplicationTitle;
import com.disney.dmdc.qa.entities.Categories;
import com.disney.dmdc.qa.entities.CategoriesSortOptions;
import com.disney.dmdc.qa.entities.Category;
import com.disney.dmdc.qa.exceptions.DbException;
import com.disney.dmdc.qa.model.CategorySortOptions;
import com.disney.dmdc.qa.model.CategoryUserItem;
import com.disney.dmdc.qa.model.CategoryResponse;
import com.disney.dmdc.qa.util.db.DmdCentralDbUtils;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CategoryResponseFactory {

    public static CategoryResponse createCategoryResponse (
            List<CategoryUserItem> userCategories, Integer pageIndex, Integer statusCode, boolean errorFlag) {

        return CategoryResponse.builder()
                .items(userCategories)
                .pageIndex(pageIndex)
                .httpStatusCode(statusCode)
                .hasError(errorFlag)
                .build();
    }

    public static CategoryResponse createDefaultCategoryResponseFromDB(String appTitleGuid, int userId, String queryType, String category) {

        try {

            ApplicationTitle appTitle = DmdCentralDbUtils.selectApplicationTitle(appTitleGuid);

            Categories categoriesList = DmdCentralDbUtils.callCategoriesGetCategoryList(appTitle.getApplicationId(), userId, queryType, category);

            List<CategorySortOptions> categorySortOptions = null;

            List<CategoryUserItem> categoryUserItems = new ArrayList<>();

            for (Category categoryDB : categoriesList.getCategories()) {

                categorySortOptions = new ArrayList<>();

                for (CategoriesSortOptions sortOptionsDB : categoriesList.getSortOptions()) {
                    if (categoryDB.getCategoryId().equals(sortOptionsDB.getCategoryId())) {

                        categorySortOptions.add(CategorySortOptions.builder()
                                .id(sortOptionsDB.getOptionId())
                                .name(sortOptionsDB.getOptionName())
                                .selected(sortOptionsDB.getIsSelected())
                                .build());
                    }
                }

                categoryUserItems.add(CategoryUserItem.builder()
                        .id(categoryDB.getCategoryId().toLowerCase())
                        .name(categoryDB.getCategoryName())
                        .previewId(categoryDB.getPreviewId() == null ? null : categoryDB.getPreviewId().toLowerCase())
                        .totalNumberOfRows(categoryDB.getTotalNumberOfRows())
                        .sortOptions(categorySortOptions)
                        .build());
            }
            return createCategoryResponse(categoryUserItems,
                    0,
                    0,
                    false);

        } catch (SQLException e) {
            throw new DbException("SQL Exception occurred", e);
        }
    }
}