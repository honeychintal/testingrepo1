package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.FacetKey;
import com.disney.dmdc.qa.model.FacetValue;
import com.disney.dmdc.qa.model.Item;
import com.disney.dmdc.qa.type.FacetKeyNames;
import com.disney.dmdc.qa.type.FacetTypes;
import com.disney.dmdc.qa.type.Language;
import com.disney.dmdc.qa.type.Territory;
import lombok.experimental.UtilityClass;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

@UtilityClass
public class FacetKeyFactory {

    public static FacetKey CreateLanguageFacetKey(Map<Language,Integer> languageCount) {

        List<FacetValue> facetValues = languageCount
                .entrySet()
                .stream()
                .map(
                        (entry) -> FacetValueFactory.CreateLanguageFacet(entry.getKey(), entry.getValue())
                )
                .collect(Collectors.toList());

        return FacetKey.builder()
                .type(FacetTypes.VALUE.getValue())
                .id(FacetKeyNames.LANGUAGE.getId())
                .name(FacetKeyNames.LANGUAGE.getId())
                .facets(facetValues)
                .selected(false)
                .build();
    }

    public static FacetKey CreateTerritoryFacetKey(Map<Territory,Integer> territoryCounts) {

        List<FacetValue> facetValues = territoryCounts
                .entrySet()
                .stream()
                .map(
                        (entry) -> FacetValueFactory.CreateTerritoryFacet(entry.getKey(), entry.getValue())
                )
                .collect(Collectors.toList());

        return FacetKey.builder()
                .type(FacetTypes.VALUE.getValue())
                .id(FacetKeyNames.TERRITORY.getId())
                .name(FacetKeyNames.TERRITORY.getId())
                .facets(facetValues)
                .selected(false)
                .build();
    }

    public static List<FacetKey> CreateFacetsFromItems(List<Item> items) {

        Map<Territory,Integer> territoryCount = new TreeMap<Territory, Integer>();
        Map<Language,Integer> languageCount = new TreeMap<Language, Integer>();

        for (Item item:items) {
            Territory territory = Territory.valueByName(item.getTerritory());
            Language language = Language.valueByName(item.getLanguage());
            territoryCount.compute(territory, (k, v) -> (v == null) ? 1 : v+1);
            languageCount.compute(language, (k, v) -> (v == null) ? 1 : v+1);

        }

        List<FacetKey> result = new ArrayList<FacetKey>(2);

        if(territoryCount.size() > 0) {
            result.add(CreateTerritoryFacetKey(territoryCount));
        }
        if(languageCount.size() > 0) {
            result.add(CreateLanguageFacetKey(languageCount));
        }

        return(result);
    }
}
