package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.FacetValue;
import com.disney.dmdc.qa.type.FacetKeyNames;
import com.disney.dmdc.qa.type.FacetTypes;
import com.disney.dmdc.qa.type.Language;
import com.disney.dmdc.qa.type.Territory;
import lombok.experimental.UtilityClass;

@UtilityClass
public class FacetValueFactory {

    public static FacetValue CreateLanguageFacet(Language language, Integer totalCount) {
        return FacetValue.builder()
                .totalCount(totalCount)
                .type(FacetTypes.VALUE.getValue())
                .id(FacetKeyNames.LANGUAGE.getId())
                .name(language.getName())
                .value(language.getName())
                .selected(false)
                .build();
    }

    public static FacetValue CreateTerritoryFacet(Territory territory, Integer totalCount) {
        return FacetValue.builder()
                .totalCount(totalCount)
                .type(FacetTypes.VALUE.getValue())
                .id(FacetKeyNames.TERRITORY.getId())
                .name(territory.getName())
                .value(territory.getName())
                .selected(false)
                .build();
    }
}
