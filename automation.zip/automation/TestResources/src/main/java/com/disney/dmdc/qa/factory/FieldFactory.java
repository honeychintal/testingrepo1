package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.Field;
import com.disney.dmdc.qa.model.FieldGetResponse;
import com.disney.dmdc.qa.type.FieldType;
import lombok.experimental.UtilityClass;

import java.util.Arrays;

@UtilityClass
public class FieldFactory {

    public static Field CreateField(FieldType fieldType, String... values) {
        return Field.builder()
                .id(fieldType.getId())
                .name(fieldType.getName())
                .value(Arrays.asList(values))
                .build();
    }

    public static FieldGetResponse createField(String id, String name, Boolean value) {
        return  FieldGetResponse.builder()
                .id(id)
                .name(name)
                .value(value)
                .build();
    }
}
