package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.FooterSetting;
import lombok.experimental.UtilityClass;

@UtilityClass
public class FooterSettingsFactory {

    public static FooterSetting createFooterSettingsFactory( String description, Integer id, String name ){
        return FooterSetting.builder()
                .description(description)
                .id(id)
                .name(name)
                .build();
    }
}
