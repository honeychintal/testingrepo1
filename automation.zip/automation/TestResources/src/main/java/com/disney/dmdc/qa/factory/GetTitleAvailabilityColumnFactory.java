package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.Column;

public class GetTitleAvailabilityColumnFactory {

    public static Column createGetTitleAvailabilityColumnData(
            String field, String header, Boolean sortable, Boolean hidden, Integer sortOrder, String type ){

        return Column.builder()
                .field(field)
                .header(header)
                .sortable(sortable)
                .hidden(hidden)
                .sortOrder(sortOrder)
                .type(type)
                .build();
    }
}
