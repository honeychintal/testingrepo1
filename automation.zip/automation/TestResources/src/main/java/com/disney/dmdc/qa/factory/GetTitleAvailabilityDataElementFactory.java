package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.GetTitleAvailabilityDataElement;

public class GetTitleAvailabilityDataElementFactory {

    public static GetTitleAvailabilityDataElement createGetTitleAvailabilityDataElements(
            String applicationTitleGuid, String episodeNumber, String wprId, String titleName,
            String rating, String releaseDate, String previewId, String synopsisText, String synopsis,
            String episodicPhotos, String eventPhotos, String galleryPhotos, String logosArtwork,
            String heLogosArtwork, String musicCues, String productionStills, String heProductionStills,
            String scripts, String specialShootPhotos, String hdrMetadata, String bqFullProgram,
            String closedCaptions, String dubCards, String localizationReports, String subtitles,
            String titleRep, String screenersFullProgram, String promosTrailers, String cpmProductId,
            String domesticEpisodeNumber,String foreignEpisodeNumber){

        return GetTitleAvailabilityDataElement.builder()
                .applicationTitleGuid(applicationTitleGuid)
                .episodeNumber(episodeNumber)
                .wprId(wprId)
                .titleName(titleName)
                .rating(rating)
                .releaseDate(releaseDate)
                .previewId(previewId)
                .synopsisText(synopsisText)
                .synopsis(synopsis)
                .episodicPhotos(episodicPhotos)
                .eventPhotos(eventPhotos)
                .galleryPhotos(galleryPhotos)
                .logosArtwork(logosArtwork)
                .heLogosArtwork(heLogosArtwork)
                .musicCues(musicCues)
                .productionStills(productionStills)
                .heProductionStills(heProductionStills)
                .scripts(scripts)
                .specialShootPhotos(specialShootPhotos)
                .hdrMetadata(hdrMetadata)
                .bqFullProgram(bqFullProgram)
                .closedCaptions(closedCaptions)
                .dubCards(dubCards)
                .localizationReports(localizationReports)
                .subtitles(subtitles)
                .titleRep(titleRep)
                .screenersFullProgram(screenersFullProgram)
                .promosTrailers(promosTrailers)
                .cpmProductId(cpmProductId)
                .domesticEpisodeNumber(domesticEpisodeNumber)
                .foreignEpisodeNumber(foreignEpisodeNumber)
                .build();
    }
}