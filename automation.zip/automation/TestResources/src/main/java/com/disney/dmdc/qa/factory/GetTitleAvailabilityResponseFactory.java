package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.data.GetTitleAvailabilitySections;
import com.disney.dmdc.qa.model.GetTitleAvailabilityResponse;
import com.disney.dmdc.qa.model.GetTitleAvailabilityResult;

public class GetTitleAvailabilityResponseFactory {

    public static GetTitleAvailabilityResponse createGetTitleAvailabiltyResponse(
            GetTitleAvailabilityResult result, Integer httpStatusCode, Boolean hasError) {
        return GetTitleAvailabilityResponse.builder()
                .result(result)
                .httpStatusCode(httpStatusCode)
                .hasError(hasError)
                .build();
    }

    public static GetTitleAvailabilityResponse  createDefaultGetTitleAvailabiltyResponse() {
        return createGetTitleAvailabiltyResponse(
                GetTitleAvailabilityResult.builder()
                        .data(GetTitleAvailabilitySections.getTitleAvailabilityDataItems())
                        .columns(GetTitleAvailabilitySections.getTitleAvailabilityColumnItems())
                        .build(),
                0,
                false
        );
    }

    public static GetTitleAvailabilityResponse createDefaultGetTitleAvailabiltyResponseSeason() {
        return createGetTitleAvailabiltyResponse(
                GetTitleAvailabilityResult.builder()
                        .data(GetTitleAvailabilitySections.getTitleAvailabilityDataItemsSeason())
                        .columns(GetTitleAvailabilitySections.getTitleAvailabilityColumnItemsSeason())
                        .build(),
                0,
                false
        );
    }
}