package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.Item;
import com.disney.dmdc.qa.type.Language;
import com.disney.dmdc.qa.type.Territory;
import lombok.experimental.UtilityClass;

@UtilityClass
public class ItemFactory {

    public static Item CreateItem(Territory territory, Language language, String alias) {
        return Item.builder()
                .id(territory.getName() + "_" + language.getName() + "_" + alias)
                .territory(territory.getName())
                .language(language.getName())
                .alias(alias)
                .build();
    }
}
