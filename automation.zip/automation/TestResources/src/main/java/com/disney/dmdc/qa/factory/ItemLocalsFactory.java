package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.entities.ApplicationTitle;
import com.disney.dmdc.qa.entities.Locale;
import com.disney.dmdc.qa.exceptions.DbException;
import com.disney.dmdc.qa.model.ItemLocals;
import com.disney.dmdc.qa.type.Locals;
import com.disney.dmdc.qa.util.db.DmdCentralDbUtils;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ItemLocalsFactory {
    public static ItemLocals createLocalItemsResponse(Boolean active, Integer id, String name ){

        return ItemLocals.builder()
                .active(active)
                .id(id)
                .name(name)
                .build();
    }

    public static ItemLocals createEnglishLocalItems() {

        return createLocalItemsResponse(
                true,
                Locals.ENG_USA.getId(),
                Locals.ENG_USA.getLocals()
        );
    }

    public static List<ItemLocals> createTitleLocals(String appTitleGuid, Integer userId, Integer distId) {

        List<ItemLocals> itemLocalsList = new ArrayList<ItemLocals>();

        try {
            ApplicationTitle appTitle = DmdCentralDbUtils.selectApplicationTitle(appTitleGuid);
            List<Locale> localeList = DmdCentralDbUtils
                    .callTitleLocalToList(appTitle.getApplicationId(), userId, distId, appTitleGuid);

            for (Locale locale : localeList) {
                itemLocalsList.add(
                        createLocalItemsResponse(
                                locale.getIsDefault(),
                                locale.getLocaleId(),
                                locale.getDisplayLocale()
                        )
                );
            }

            return itemLocalsList;

        } catch (SQLException e) {
            throw new DbException("SQL Exception occurred", e);
        }
    }
}
