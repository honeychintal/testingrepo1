package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.client.DmdcMarketingClient;
import com.disney.dmdc.qa.data.SampleTitle;
import com.disney.dmdc.qa.model.FacetQuery;
import com.disney.dmdc.qa.model.Field;
import com.disney.dmdc.qa.model.LocalNamesRequest;
import com.disney.dmdc.qa.type.FieldType;
import com.google.common.collect.ImmutableList;
import lombok.experimental.UtilityClass;

import javax.ws.rs.core.UriBuilder;
import java.util.List;

@UtilityClass
public class LocalNamesRequestFactory {

    public static LocalNamesRequest CreateLocalNamesRequest(
            String keyword, List<Field> fields, List<FacetQuery> facets, Integer pageSize,
            Boolean includeFacets, String apiPath, List<String> sortDescriptors) {

        return LocalNamesRequest.builder()
                .keyword(keyword)
                .fields(fields)
                .facets(facets)
                .pageSize(pageSize)
                .includeFacets(includeFacets)
                .apiPath(apiPath)
                .sortDescriptors(sortDescriptors)
                .build();
    }

    public static LocalNamesRequest CreateDefaultLocalizedDetailsRequest(SampleTitle title) {

        String apiPath = UriBuilder.fromPath(DmdcMarketingClient.TITLE_LOCAL_NAMES_PATH).build(title.getTitleId()).toString();

        return CreateLocalNamesRequest(
                "",
                ImmutableList.of(FieldFactory.CreateField(FieldType.WPRIDS, title.getWprids())),
                ImmutableList.of(),
                100000,
                true,
                apiPath,
                ImmutableList.of()
        );
    }
}
