package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.FacetKey;
import com.disney.dmdc.qa.model.Item;
import com.disney.dmdc.qa.model.LocalNamesResponse;
import lombok.experimental.UtilityClass;

import java.util.List;

@UtilityClass
public class LocalNamesResponseFactory {

    public static LocalNamesResponse CreateLocalNamesResponse(
            List<FacetKey> facets, List<Item> items, Integer pageIndex, Integer pageSize,
            Integer totalCount, Integer httpStatusCode, Boolean hasError
    ) {

        return LocalNamesResponse.builder()
                .facets(facets)
                .items(items)
                .pageIndex(pageIndex)
                .pageSize(pageSize)
                .totalCount(totalCount)
                .httpStatusCode(httpStatusCode)
                .hasError(hasError)
                .build();
    }

    public static LocalNamesResponse CreateDefaultLocalNamesResponse(List<Item> items) {

        return CreateLocalNamesResponse(
                FacetKeyFactory.CreateFacetsFromItems(items), items, 0, 100000, items.size(), 0, false
        );
    }

}
