package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.data.TestLookupGroupItemsData;
import com.disney.dmdc.qa.model.LookupGroupGetResponse;
import com.disney.dmdc.qa.model.LookupGroupItems;

import java.util.List;

public class LookupGroupResponseFactory {
    public static LookupGroupGetResponse createGroupResponse(List<LookupGroupItems> items,
                                                                         Integer pageIndex, Integer httpStatusCode, Boolean hasError) {
        return LookupGroupGetResponse.builder()
                .items(items)
                .pageIndex(pageIndex)
                .httpStatusCode(httpStatusCode)
                .hasError(hasError)
                .build();
    }

    public static LookupGroupGetResponse createDefaultDistributionGroupResponse() {
        return createGroupResponse(
                TestLookupGroupItemsData.getDistributionItems(),
                0,
                0,
                false
        );
    }

    public static LookupGroupGetResponse createDefaultGroupStatusResponse() {
        return createGroupResponse(
                TestLookupGroupItemsData.getGroupStatus(),
                0,
                0,
                false
        );
    }
}
