package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.data.TestMembershipTerritoryItemsData;
import com.disney.dmdc.qa.model.MembershipTerritoriesGetResponse;
import com.disney.dmdc.qa.model.MembershipTerritoryItems;

import java.util.List;

public class MembershipTerritoriesResponseFactory {

    public static MembershipTerritoriesGetResponse createTerritoryResponse(List<MembershipTerritoryItems> territoryItems,
                              Integer pageIndex, Integer httpStatusCode, Boolean hasError){
        return MembershipTerritoriesGetResponse.builder()
                .items(territoryItems)
                .pageIndex(pageIndex)
                .httpStatusCode(httpStatusCode)
                .hasError(hasError)
                .build();
    }

    public static MembershipTerritoriesGetResponse createDefaultTerritoryResponse() {
        return createTerritoryResponse(
                TestMembershipTerritoryItemsData.getTerritories(),
                0,
                0,
                false
        );
    }
}
