package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.MembershipTerritoryItems;

public class MembershipTerritoryItemsFactory {

    public static MembershipTerritoryItems createTerritoryItems(Integer id, String name){
        return MembershipTerritoryItems.builder()
                .id(id)
                .name(name)
                .build();
    }
}
