package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.MembershipUserIdResponse;
import com.disney.dmdc.qa.model.MembershipUserIdResult;

public class MembershipUserIdResponseFactory {

    public static MembershipUserIdResponse createUserIdResponse(
            MembershipUserIdResult result, Integer httpStatusCode, boolean hasError) {

        return MembershipUserIdResponse.builder()
                .result(result)
                .httpStatusCode(httpStatusCode)
                .hasError(hasError)
                .build();
    }

    public static MembershipUserIdResponse testUserIdResponse(MembershipUserIdResult result) {

        return createUserIdResponse(
                result,
                0,
                false
        );
    }

}
