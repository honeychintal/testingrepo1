package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.NavGetDataElement;
import com.disney.dmdc.qa.model.PortalNavMenuDataElement;

public class NavGetDataElementFactory {

    public static NavGetDataElement createNavGet(String url, String path, Boolean internalUrl, String icon, String name) {
        return NavGetDataElement.builder()
                .icon(icon)
                .internalUrl(internalUrl)
                .name(name)
                .path(path)
                .url(url)
                .build();
    }
}
