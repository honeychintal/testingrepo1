package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.data.TestNavGetSectionsData;
import com.disney.dmdc.qa.model.NavGetDataElement;
import com.disney.dmdc.qa.model.NavGetResponse;
import com.disney.dmdc.qa.model.NavGetSections;
import com.disney.dmdc.qa.model.UserDetails;

import java.util.List;


public class NavGetResponsefactory {

    public static NavGetResponse createNavGetInfo(int userId, String email, String firstName, String lastName, List<NavGetSections> navMenuUrls, NavGetDataElement defaultObject) {

        return NavGetResponse.builder()
                .userId(userId)
                .email(email)
                .firstName(firstName)
                .lastName(lastName)
                .sections(navMenuUrls)
                .defaultObject(defaultObject)
                .build();
    }

    public static NavGetResponse createNavGetResponse(UserDetails user) {
        List<NavGetSections> navSectionsData = null;
        NavGetDataElement navDefaultData = null;
        String userType = user.getUserType();

        if(userType.equalsIgnoreCase("admin")){
            navSectionsData = TestNavGetSectionsData.getAdminNavSectionData();
            navDefaultData = TestNavGetSectionsData.getAdminNavDefaultData();
        }
        else if(userType.equalsIgnoreCase("TvdHe")){
            navSectionsData = TestNavGetSectionsData.getMarketingNavSectionData();
            navDefaultData = TestNavGetSectionsData.getMarketingNavDefaultData();
        }

        return createNavGetInfo(
                user.getId(),
                user.getEmail(),
                user.getFirstName(),
                user.getLastName(),
                navSectionsData,
                navDefaultData);
    }
}
