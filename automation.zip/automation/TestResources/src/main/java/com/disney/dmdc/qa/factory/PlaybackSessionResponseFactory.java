package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.PlaybackSessionGetResponse;
import lombok.experimental.UtilityClass;

@UtilityClass
public class PlaybackSessionResponseFactory {

    public static PlaybackSessionGetResponse createPlaybackSessionResponse(
            String result, Integer httpStatusCode, Boolean hasError
    ) {

        return PlaybackSessionGetResponse.builder()
                .result(result)
                .httpStatusCode(httpStatusCode)
                .hasError(hasError)
                .build();
    }

    public static PlaybackSessionGetResponse createSuccessfulPlaybackSessionResponse() {
        return createPlaybackSessionResponse(
                "0576C91E-D10C-0ADC-7810-5DB3312561D6-38137CF7;xapi8-rdancestg-034094249077.g.idviu.net",
                0,
                false
        );
    }


}
