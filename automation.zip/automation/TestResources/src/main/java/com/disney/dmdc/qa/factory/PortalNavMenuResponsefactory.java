package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.data.TestPortalNavMenuSectionsData;
import com.disney.dmdc.qa.model.PortalNavMenuGetResponse;
import com.disney.dmdc.qa.model.PortalNavMenuDataElement;
import com.disney.dmdc.qa.model.PortalNavMenuSections;
import com.disney.dmdc.qa.model.UserDetails;

import java.util.List;


public class PortalNavMenuResponsefactory {

    public static PortalNavMenuGetResponse createPortalNavMenuInfo(int userId, String email, String firstName, String lastName, List<PortalNavMenuSections> navMenuUrls, PortalNavMenuDataElement defaultObject) {

        return PortalNavMenuGetResponse.builder()
                .userId(userId)
                .email(email)
                .firstName(firstName)
                .lastName(lastName)
                .sections(navMenuUrls)
                .defaultObject(defaultObject)
                .build();
    }

    public static PortalNavMenuGetResponse createPortalNavMenuResponse(UserDetails user) {
        List<PortalNavMenuSections> navSectionsData;
        PortalNavMenuDataElement navDefaultData;

        if(user.getUserType().toLowerCase().equals("admin")){
            navSectionsData = TestPortalNavMenuSectionsData.getAdminNavSectionData();
            navDefaultData = TestPortalNavMenuSectionsData.getAdminNavDefaultData();
        }
        else{
            navSectionsData = TestPortalNavMenuSectionsData.getMarketingNavSectionData();
            navDefaultData = TestPortalNavMenuSectionsData.getMarketingNavDefaultData();
        }

        return createPortalNavMenuInfo(
                user.getId(),
                user.getEmail(),
                user.getFirstName(),
                user.getLastName(),
                navSectionsData,
                navDefaultData);
    }
}
