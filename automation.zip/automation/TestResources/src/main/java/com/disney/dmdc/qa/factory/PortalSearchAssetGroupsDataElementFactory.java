package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.AssetGroupsDataElement;

public class PortalSearchAssetGroupsDataElementFactory {

    public static AssetGroupsDataElement createAssetGroupDataElements(
            Integer tabId, Integer assetTypeId, String assetType, Integer totalCount, Integer sortOrder) {

        return AssetGroupsDataElement.builder()
                .tabId(tabId)
                .assetTypeId(assetTypeId)
                .assetType(assetType)
                .totalCount(totalCount)
                .sortOrder(sortOrder)
                .build();
    }
}
