package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.entities.ApplicationTitle;
import com.disney.dmdc.qa.entities.AssetGroup;
import com.disney.dmdc.qa.entities.SearchTab;
import com.disney.dmdc.qa.exceptions.DbException;
import com.disney.dmdc.qa.model.AssetGroupsDataElement;
import com.disney.dmdc.qa.model.PortalSearchTabsItems;
import com.disney.dmdc.qa.util.db.DmdCentralDbUtils;
import java.sql.SQLException;
import java.util.List;
import java.util.stream.Collectors;

public class PortalSearchTabsItemsFactory {

    public static List<PortalSearchTabsItems> createPortalSearchTabItemsResponse(Integer userId, String appTitleGuid, String searchMode) {

        try {
            ApplicationTitle appTitle = DmdCentralDbUtils.selectApplicationTitle(appTitleGuid);
            SearchTab searchTab = DmdCentralDbUtils.callTitleProductPageTabsGetInfo(
                    appTitle.getApplicationId(), userId, null, null, searchMode);

            return createSearchTabResponseItems(searchTab);
        } catch (SQLException e) {
            throw new DbException("SQL Exception occurred", e);
        }

    }

    public static List<AssetGroupsDataElement> createAssetGroups(Integer tabId, List<AssetGroup> assetGroups) {

        List<AssetGroup> assetGroupList = assetGroups.stream().filter(item ->
                item.getTabId().equals(tabId)).collect(Collectors.toList());

        return assetGroupList.stream().map(item -> AssetGroupsDataElement
                .builder()
                .tabId(item.getTabId())
                .assetTypeId(item.getAssetTypeId())
                .assetType(item.getAssetType())
                .totalCount(item.getTotal())
                .sortOrder(item.getSortOrder())
                .build()
        )
                .collect(Collectors.toList());
    }

    public static List<PortalSearchTabsItems> createSearchTabResponseItems(SearchTab searchTab) {

        return searchTab.getItems().stream().map(item -> PortalSearchTabsItems
                .builder()
                .tabId(item.getTabId())
                .tabName(item.getTabName())
                .totalCount(item.getTotal())
                .sortOrder(item.getSortOrder())
                .assetGroups(createAssetGroups(item.getTabId(), searchTab.getAssetGroups()))
                .path(item.getPath())
                .build()
        )
                .collect(Collectors.toList());
    }
}
