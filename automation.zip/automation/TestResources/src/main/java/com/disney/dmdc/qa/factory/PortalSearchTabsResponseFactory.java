package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.PortalSearchTabsGetResponse;
import com.disney.dmdc.qa.model.PortalSearchTabsItems;
import java.util.List;
import lombok.experimental.UtilityClass;

@UtilityClass
public class PortalSearchTabsResponseFactory {

    public static PortalSearchTabsGetResponse createPortalSearchTabsResponse(
            List<PortalSearchTabsItems> items, Integer pageIndex, Integer httpStatusCode, Boolean hasError) {

        return PortalSearchTabsGetResponse.builder()
                .items(items)
                .pageIndex(pageIndex)
                .httpStatusCode(httpStatusCode)
                .hasError(hasError)
                .build();
    }

    public static PortalSearchTabsGetResponse createExpectedPortalSearchTabsResponse(
            List<PortalSearchTabsItems> searchTabItems) {

        return createPortalSearchTabsResponse(
                searchTabItems,
                0,
                0,
                false
        );
    }
}
