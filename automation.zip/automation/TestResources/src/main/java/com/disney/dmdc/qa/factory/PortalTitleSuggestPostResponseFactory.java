package com.disney.dmdc.qa.factory;


import com.disney.dmdc.qa.model.PortalTitleSuggestPostResponse;
import com.disney.dmdc.qa.model.PortalTitleSuggestion;

import java.sql.SQLException;
import java.util.List;

public class PortalTitleSuggestPostResponseFactory {

    public static PortalTitleSuggestPostResponse createPortalTitleSuggestPostResponse(
            List<PortalTitleSuggestion> items, Integer pageIndex, Integer pageSize,
            Integer httpStatusCode, Boolean hasError){

        return PortalTitleSuggestPostResponse.builder()
                .items(items)
                .pageIndex(pageIndex)
                .pageSize(pageSize)
                .httpStatusCode(httpStatusCode)
                .hasError(hasError)
                .build();

    }

    public static PortalTitleSuggestPostResponse createDefaultPortalTitleSuggestPostResponse(String appTitleGuid, Integer userId,
                                                                                             String keyWord) throws SQLException {

        return createPortalTitleSuggestPostResponse(
                PortalTitleSuggestionFactory.createPortalTitleSuggestions(appTitleGuid,userId,keyWord),
                0,
                10,
                0,
                false

        );
    }
}