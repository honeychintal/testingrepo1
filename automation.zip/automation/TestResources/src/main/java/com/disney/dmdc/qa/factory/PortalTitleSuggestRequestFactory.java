package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.PortalTitleSuggestRequest;
import com.disney.dmdc.qa.model.PortalTitleSuggestRequestField;
import com.google.common.collect.ImmutableList;

import java.util.List;

public class PortalTitleSuggestRequestFactory {

    public static PortalTitleSuggestRequest createPortalTitleSuggestRequest(String keyword,
                                                                            List<PortalTitleSuggestRequestField> fields,
                                                                            List<String> facets,
                                                                            Integer pageSize) {
        return PortalTitleSuggestRequest.builder()
                .keyword(keyword)
                .fields(fields)
                .facets(facets)
                .pageSize(pageSize)
                .build();
    }

    public static PortalTitleSuggestRequest createEpisodesPortalTitleSuggestRequest(String keyword, Boolean includeFacetValue) {

        return createPortalTitleSuggestRequest(
                keyword,
                ImmutableList.of(
                        PortalTitleSuggestRequestFieldFactory.createPortalTitleSuggestRequestField
                                (
                                        "IncludeEpisodesFlag",
                                        "IncludeEpisodesFlag",
                                        includeFacetValue
                                )
                ),
                ImmutableList.of(),
                10
        );
    }
}