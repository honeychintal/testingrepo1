package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.PortalTitleSuggestRequestField;

public class PortalTitleSuggestRequestFieldFactory {

    public static PortalTitleSuggestRequestField createPortalTitleSuggestRequestField(
            String id,String name,Object value )
    {
        return PortalTitleSuggestRequestField.builder()
                .id(id)
                .name(name)
                .value(value)
                .build();
    }
}