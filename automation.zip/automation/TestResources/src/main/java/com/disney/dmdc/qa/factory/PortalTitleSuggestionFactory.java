package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.entities.ApplicationTitle;
import com.disney.dmdc.qa.entities.TitleSuggestItem;
import com.disney.dmdc.qa.exceptions.DbException;
import com.disney.dmdc.qa.model.PortalTitleSuggestion;
import com.disney.dmdc.qa.util.DateTime;
import com.disney.dmdc.qa.util.db.DmdCentralDbUtils;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

public class PortalTitleSuggestionFactory {

    public static PortalTitleSuggestion createPortalTitleSuggestion(
            String id, String name, String label, String releaseDate, Boolean titleHoldback, String wprId,
            Integer CpmProductId,String episodeDomesticForeignNumber,Integer applicationTitleId) {

        return PortalTitleSuggestion.builder()
                .id(id)
                .name(name)
                .label(label)
                .releaseDate(releaseDate)
                .titleHoldback(titleHoldback)
                .wprId(wprId)
                .CpmProductId(CpmProductId)
                .episodeDomesticForeignNumber(episodeDomesticForeignNumber)
                .applicationTitleId(applicationTitleId)
                .build();
    }


    public static List<PortalTitleSuggestion> createPortalTitleSuggestions(
            String appTitleGuid, Integer userID, String keyword) throws SQLException {

        List<PortalTitleSuggestion> itemSuggest = new ArrayList<PortalTitleSuggestion>();

        try {
            ApplicationTitle appTitle = DmdCentralDbUtils.selectApplicationTitle(appTitleGuid);
            List<TitleSuggestItem> suggestItems = DmdCentralDbUtils
                    .titleSuggestItem(appTitle.getApplicationId(), userID, keyword);

            for (TitleSuggestItem suggest : suggestItems) {
                itemSuggest.add(

                        createPortalTitleSuggestion(
                                suggest.getApplicationTitleGuid().toLowerCase(),
                                suggest.getTitleName_Main(),
                                suggest.getTitleName_Secondary(),
                                DateTime.convertDateToDateTime(suggest.getReleaseDate()),
                                false,
                                suggest.getWprid(),
                                suggest.getCpmProductId(),
                                "",
                                suggest.getApplicationTitleId()
                        )
                );

            }
            return itemSuggest;
        } catch (SQLException | ParseException e) {
            throw new DbException("SQL Exception occurred", e);
        }
    }
}