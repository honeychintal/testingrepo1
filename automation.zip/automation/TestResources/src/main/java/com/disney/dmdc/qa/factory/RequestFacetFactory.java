package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.FacetQuery;

public class RequestFacetFactory {
    public static FacetQuery createRequestFacet(String id, String value, Integer type, Integer totalCount,
                                                  Boolean selected){
        return FacetQuery.builder()
                .id(id)
                .value(value)
                .type(type)
                .totalCount(totalCount)
                .selected(selected)
                .build();
    }
}
