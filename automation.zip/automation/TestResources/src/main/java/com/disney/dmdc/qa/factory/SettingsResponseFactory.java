package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.FooterSetting;
import com.disney.dmdc.qa.model.HomeSettings;
import com.disney.dmdc.qa.model.MediaPlayerSettings;
import com.disney.dmdc.qa.model.SettingsResponse;
import com.disney.dmdc.qa.model.TitleDetailsSettings;
import lombok.experimental.UtilityClass;

import java.util.List;

@UtilityClass
public class SettingsResponseFactory {

public static SettingsResponse createSettingsResponse(
        String appName, Integer appId, String theme, String cdnBaseUrl, String adminBaseUrl, String imageToken,
        String timezone, List<FooterSetting> footer, HomeSettings home, TitleDetailsSettings titleDetails,
        Integer userActions, List<Integer> assetEditActions, String legacyPortalBaseUrl, String authAppUrl,
        Boolean internal, MediaPlayerSettings mediaPlayer, String signalRBaseUrl, String appInsightsInstrumentationKey){

        return SettingsResponse.builder()
                .appName(appName)
                .appId(appId)
                .theme(theme)
                .cdnBaseUrl(cdnBaseUrl)
                .adminBaseUrl(adminBaseUrl)
                .imageToken(imageToken)
                .timezone(timezone)
                .footer(footer)
                .home(home)
                .titleDetails(titleDetails)
                .userActions(userActions)
                .assetEditActions(assetEditActions)
                .legacyPortalBaseUrl(legacyPortalBaseUrl)
                .authAppUrl(authAppUrl)
                .internal(internal)
                .mediaPlayer(mediaPlayer)
                .signalRBaseUrl(signalRBaseUrl)
                .appInsightsInstrumentationKey(appInsightsInstrumentationKey)
                .build();
        }
}
