package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.entities.AdditionalCrewAndCast;
import com.disney.dmdc.qa.entities.CreditType;
import com.disney.dmdc.qa.exceptions.DbException;
import com.disney.dmdc.qa.model.TitleAdditionalCastItems;
import com.disney.dmdc.qa.util.DbJsonHelper;
import com.disney.dmdc.qa.util.db.DmdCentralDbUtils;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TitleAdditionalCastItemsFactory {

    public static TitleAdditionalCastItems createTitleAdditionalCastItem(String talentName,String roleName)
    {
        return TitleAdditionalCastItems.builder()
                .talentName(talentName)
                .roleName(roleName)
                .build();
    }

    public static List<TitleAdditionalCastItems> createTitleAdditionalCast(String appTitleGuid, int localId, String creditType) {
        List<TitleAdditionalCastItems> itemAdditionalCastList = new ArrayList<TitleAdditionalCastItems>();
        try {
            CreditType credit = DmdCentralDbUtils.selectCreditTypeId(creditType);
            List<AdditionalCrewAndCast> itemsList = DmdCentralDbUtils
                    .callTitleAdditionalCrewAndCast(appTitleGuid, localId, credit.getCreditTypeId());
            for (AdditionalCrewAndCast item : itemsList) {

                String roleName = DbJsonHelper.replaceCarriageReturn(item.getRoleName());
                String talentName = DbJsonHelper.replaceCarriageReturn(item.getTalentName());

                itemAdditionalCastList.add(
                        createTitleAdditionalCastItem(
                                talentName,
                                roleName
                        )
                );
            }
            return itemAdditionalCastList;
        } catch (SQLException e) {
            throw new DbException("SQL Exception occurred", e);
        }
    }
}
