package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.PortalNavMenuDataElement;
import com.disney.dmdc.qa.model.TitleAdditionalCastItemsMahender;

public class TitleAdditionalCastItemsFactoryMahender {
    public static TitleAdditionalCastItemsMahender CreateTitleAdditionalCast(String talentname,String rolename)
    {
        return TitleAdditionalCastItemsMahender.builder()
                .talentName(talentname)
                .roleName(rolename)
                .build();
    }
}

