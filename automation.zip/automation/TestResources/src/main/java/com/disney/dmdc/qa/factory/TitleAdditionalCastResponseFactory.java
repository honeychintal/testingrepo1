package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.TitleAdditionalCastItems;
import com.disney.dmdc.qa.model.TitleAdditionalCastResponse;

import java.util.List;

public class TitleAdditionalCastResponseFactory {

    public static TitleAdditionalCastResponse createAdditionalItems(List<TitleAdditionalCastItems> items, Integer pageIndex, Integer statusCode, boolean error){
        return TitleAdditionalCastResponse.builder()
                .items(items)
                .pageIndex(pageIndex)
                .HttpStatusCode(statusCode)
                .hasError(error)
                .build();
    }

    public static TitleAdditionalCastResponse createExpectedAdditionalCastResponse(String appTitleGuid, int localId, String creditType) {

        return createAdditionalItems(
                TitleAdditionalCastItemsFactory.createTitleAdditionalCast(appTitleGuid, localId, creditType),
                0,
                0,
                false
        );
    }
}