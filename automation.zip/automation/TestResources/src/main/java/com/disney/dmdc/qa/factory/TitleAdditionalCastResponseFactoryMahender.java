package com.disney.dmdc.qa.factory;
import com.disney.dmdc.qa.data.TestPortalNavMenuSectionsData;
import com.disney.dmdc.qa.data.TestTitleAdditionalCastItemsData_Mahender;
import com.disney.dmdc.qa.data.TestTitleAdditionalCastItemsMahender;
import com.disney.dmdc.qa.model.*;
import java.util.List;

public class TitleAdditionalCastResponseFactoryMahender {
    public static TitleAdditionalCastResponseMahender createAdditionalItems(List<TitleAdditionalCastItemsMahender>items,Integer PageIndex, Integer StatusCode, boolean error) {
        return TitleAdditionalCastResponseMahender.builder()
                .items(items)
                .PageIndex(PageIndex)
                .HttpStatusCode(StatusCode)
                .HasError(error)
                .build();
    }
    public static TitleAdditionalCastResponseMahender createExpectedAdditionalCastResponse() {
        List<TitleAdditionalCastItemsMahender> titleAdditionalCastItemData;
        titleAdditionalCastItemData = TestTitleAdditionalCastItemsData_Mahender.getAdminAdditionalItemsData();
        return createAdditionalItems(
                titleAdditionalCastItemData,
                0,
                0,
                false);
    }
}










    /*public static PortalNavMenuGetResponse createPortalNavMenuResponse(UserDetails user) {
        List<PortalNavMenuSections> navSectionsData;
        PortalNavMenuDataElement navDefaultData;

        if(user.getUserType().toLowerCase().equals("admin")){
            navSectionsData = TestPortalNavMenuSectionsData.getAdminNavSectionData();
            navDefaultData = TestPortalNavMenuSectionsData.getAdminNavDefaultData();
        }
        else{
            navSectionsData = TestPortalNavMenuSectionsData.getMarketingNavSectionData();
            navDefaultData = TestPortalNavMenuSectionsData.getMarketingNavDefaultData();
        }

        return createPortalNavMenuInfo(
                user.getId(),
                user.getEmail(),
                user.getFirstName(),
                user.getLastName(),
                navSectionsData,
                navDefaultData);
    }
    public static TitleAdditionalCastResponseMahender createExpectedAdditionalCastResponse(String appTitleGuid, int localId, String creditType) {

        return createAdditionalItems(
                TitleAdditionalCastItemsFactoryMahender.createTitleAdditionalCast(appTitleGuid, localId, creditType),
                0,
                0,
                false
        );
    }*/

