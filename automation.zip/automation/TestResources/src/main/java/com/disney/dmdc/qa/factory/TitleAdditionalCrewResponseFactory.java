package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.TitleAdditionalCrewItem;
import com.disney.dmdc.qa.model.TitleAdditionalCrewResponse;

import java.util.List;

public class TitleAdditionalCrewResponseFactory {

    public static TitleAdditionalCrewResponse createAdditionalCrewItems(List<TitleAdditionalCrewItem> items,
                                               Integer pageIndex, Integer statusCode, boolean error) {

        return TitleAdditionalCrewResponse.builder()
                .items(items)
                .pageIndex(pageIndex)
                .HttpStatusCode(statusCode)
                .hasError(error)
                .build();
    }

    public static TitleAdditionalCrewResponse createDefaultAdditionalCrewResponse(String appTitleGuid, int localId, String creditType){

       return createAdditionalCrewItems(
               TitleAdditionalCrewFactoryItems.createTitleAdditionalCrewItems(appTitleGuid, localId, creditType),
               0,
               0,
               false
       );
    }
}
