package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.entities.AdditionalData;
import com.disney.dmdc.qa.entities.ReleaseDate;
import com.disney.dmdc.qa.entities.Rights;
import com.disney.dmdc.qa.entities.RunTime;
import com.disney.dmdc.qa.exceptions.DbException;
import com.disney.dmdc.qa.model.TitleAdditionalDataGetResponse;
import com.disney.dmdc.qa.model.TitleAdditionalDataReleaseDates;
import com.disney.dmdc.qa.model.TitleAdditionalDataResult;
import com.disney.dmdc.qa.model.TitleAdditionalDataRights;
import com.disney.dmdc.qa.model.TitleAdditionalDataRuntime;
import com.disney.dmdc.qa.util.DateTime;
import com.disney.dmdc.qa.util.db.DmdCentralDbUtils;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

public class TitleAdditionalDataGetResponseFactory {

    public static TitleAdditionalDataGetResponse createAdditionalDataResponseData(TitleAdditionalDataResult titleAdditionalDataResult,
                                                                  Integer httpStatusCode, Boolean hasError) {
        return TitleAdditionalDataGetResponse.builder()
                .Result(titleAdditionalDataResult)
                .httpStatusCode(httpStatusCode)
                .hasError(hasError)
                .build();
    }

    public static TitleAdditionalDataGetResponse createAdditionalDataResponse(String appTitleGuid) {
        return createAdditionalDataResponseData(additionalDataDBResponse(appTitleGuid),
                0,
                false);
    }

    public static TitleAdditionalDataResult additionalDataDBResponse (String appTitleGuid) {

        try {
            AdditionalData additionalDataList = DmdCentralDbUtils.callTitleAdditionalDataToList(appTitleGuid);
            List<TitleAdditionalDataReleaseDates> titleAdditionalDataReleaseDates = new ArrayList<>();
            List<TitleAdditionalDataRuntime> titleAdditionalDataRuntimes = new ArrayList<>();
            List<TitleAdditionalDataRights> titleAdditionalDataRights = new ArrayList<>();

            for(ReleaseDate releaseDate : additionalDataList.getReleaseDates()) {

                titleAdditionalDataReleaseDates.add(TitleAdditionalDataReleaseDates.builder()
                        .type(releaseDate.getReleaseDateType())
                        .date(releaseDate.getReleaseDate() == null ? null : DateTime.convertDateTimeFormat("EEE MMM d HH:mm:ss zzz yyyy", "yyyy-MM-dd'T'HH:mm:ss", releaseDate.getReleaseDate().toString()))
                        .statusCode(releaseDate.getReleaseStatusCode())
                        .preliminary(releaseDate.getReleaseStatusCode() != null)
                        .formattedDate(releaseDate.getReleaseDate() == null ? "N/A" : DateTime.convertDateTimeFormat("EEE MMM d HH:mm:ss zzz yyyy", "dd-MMM-yyyy", releaseDate.getReleaseDate().toString()))
                        .build());
            }

            for(RunTime runTime : additionalDataList.getRunTimes()) {
                titleAdditionalDataRuntimes.add(TitleAdditionalDataRuntime.builder()
                        .versionType(runTime.getVersionType())
                        .actualRunTime(runTime.getRunTime())
                        .formattedRuntime(runTime.getRunTime()/60 + " min")
                        .build());
            }

            for(Rights rights : additionalDataList.getRights()) {
                titleAdditionalDataRights.add(TitleAdditionalDataRights.builder()
                        .mediaDescription(rights.getMediaDescription())
                        .rightDescription(rights.getRightDescription())
                        .build());
            }

            return TitleAdditionalDataResult.builder()
                    .releaseDates(titleAdditionalDataReleaseDates)
                    .runTimes(titleAdditionalDataRuntimes)
                    .rights(titleAdditionalDataRights)
                    .build();

        } catch (SQLException | ParseException e) {
            throw new DbException("SQL Exception occurred", e);
        }
    }
}
