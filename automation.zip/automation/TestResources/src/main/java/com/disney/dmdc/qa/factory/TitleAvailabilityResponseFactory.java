package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.TitleAvailabilityPostResponse;
import lombok.experimental.UtilityClass;

@UtilityClass
public class TitleAvailabilityResponseFactory {

    public static TitleAvailabilityPostResponse CreateSuccessTitleAvailabilityResponse() {

        return TitleAvailabilityPostResponse.builder()
                .result(true)
                .httpStatusCode(0)
                .hasError(false)
                .build();
    }
}
