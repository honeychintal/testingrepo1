package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.entities.Award;
import com.disney.dmdc.qa.exceptions.DbException;

import com.disney.dmdc.qa.model.TitleAwardItems;
import com.disney.dmdc.qa.model.TitleAwardTalents;
import com.disney.dmdc.qa.model.TitleAwards;
import com.disney.dmdc.qa.model.TitleAwardsCategory;
import com.disney.dmdc.qa.model.TitleAwardsGetResponse;

import com.disney.dmdc.qa.util.DbJsonHelper;
import com.disney.dmdc.qa.util.db.DmdCentralDbUtils;
import lombok.experimental.UtilityClass;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@UtilityClass
public class TitleAwardsResponseFactory {

    public static TitleAwardsGetResponse createAwardsResponse(String appTitleGuid, int distId) {

        return createAwardsResponseData(
                createAwardsDbResponse(appTitleGuid, distId),
                0,
                0,
                false
        );
    }

    public static TitleAwardsGetResponse createAwardsResponseData(List<TitleAwardItems> items, Integer pageIndex,
                                                                  Integer httpStatusCode, Boolean hasError) {
        return TitleAwardsGetResponse.builder()
                .items(items)
                .pageIndex(pageIndex)
                .httpStatusCode(httpStatusCode)
                .hasError(hasError)
                .build();
    }

    public static List<TitleAwardItems> createAwardsDbResponse(String appTitleGuid, int distId) {

        try {
            // retrieving the data from DB
            List<Award> awardsData = DmdCentralDbUtils.callTitleAwards(appTitleGuid, distId);
            return createAwardsItems(awardsData);
        } catch (SQLException e) {
            throw new DbException("SQL Exception occurred", e);
        }
    }

    public static List<TitleAwardItems> createAwardsItems(List<Award> awardsData) {

        List<TitleAwards> titleAwards = new ArrayList<>();
        Map<Integer, List<Award>> awardsMapByYear = awardsData.stream().collect(Collectors.groupingBy(Award::getAwardYear));
        awardsMapByYear.forEach((year, awardsByYear) -> titleAwards.addAll(createAwards(year, awardsByYear)));

        return awardsMapByYear.keySet().stream().map(year -> TitleAwardItems.builder()
                .year(year)
                .awards(titleAwards.stream().filter(award -> award.getAwardYear().equals(year)).collect(Collectors.toList()))
                .build()).collect(Collectors.toList());
    }

    public static List<TitleAwards> createAwards(Integer year, List<Award> awardsByYear) {

        List<TitleAwards> titleAwards = new ArrayList<>();
        Map<Integer, List<Award>> categoriesMapByAwardId = awardsByYear.stream().collect(Collectors.groupingBy(Award::getAwardId));

        categoriesMapByAwardId.values().forEach(value -> {
            Optional<Award> award = value.stream().findAny();
            if (award.isPresent()) {
                List<TitleAwardsCategory> titleAwardsCategories = new ArrayList<>();
                Map<Integer, List<Award>> awardListByCategory = value.stream().collect(
                        Collectors.groupingBy(Award::getTitleVersionAwardAwardCategoryId));
                awardListByCategory.values().forEach(awardsList -> titleAwardsCategories.add(createCategoryFromAwardList(awardsList)));
                titleAwards.add(TitleAwards.builder()
                        .awardYear(year)
                        .awardName(award.get().getAwardName())
                        .awardAlias(award.get().getAwardAlias())
                        .categories(titleAwardsCategories)
                        .build());
            }
        });
        return titleAwards;
    }

    public static TitleAwardsCategory createCategoryFromAwardList(List<Award> awardList) {

        Optional<Award> anyAward = awardList.stream().findAny();

        return anyAward.map(award -> TitleAwardsCategory.builder()
                .titleVersionAwardAwardCategoryId(award.getTitleVersionAwardAwardCategoryId())
                .awardCategoryId(award.getAwardCategoryId())
                .awardCategoryName(DbJsonHelper.stringReplacement(award.getAwardCategoryName(), "\r", ""))
                .awardCategoryText(DbJsonHelper.stringReplacement(
                        DbJsonHelper.stringReplacement(award.getAwardCategoryText(), "&quot;", "\""),"\r", ""))
                .talents(createTalentsFromAwardList(awardList))
                .isWin(award.getTalentId() == null ? anyAward.get().getIsWin() : null)
                .build()).orElse(null);
    }

    public static List<TitleAwardTalents> createTalentsFromAwardList(List<Award> awardList) {

        List<TitleAwardTalents> titleAwardTalents = new ArrayList<>();
        awardList.forEach(award -> {
            if (award.getTalentId() != null) {
                titleAwardTalents.add(TitleAwardTalents.builder()
                        .talentId(award.getTalentId())
                        .talentName(award.getTalentName())
                        .isWin(award.getIsWin())
                        .build());
            }
        });
        return titleAwardTalents;
    }

}
