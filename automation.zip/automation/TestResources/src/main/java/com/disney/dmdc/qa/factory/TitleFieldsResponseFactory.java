package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.data.TestFieldsData;
import com.disney.dmdc.qa.model.FieldGetResponse;

import java.util.List;

public class TitleFieldsResponseFactory {
    public static List<FieldGetResponse> createUserFieldsGetResponse() {
        return TestFieldsData.getAdminTitleFieldsResponse();
    }
}
