package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.TitleHeaderResponse;
import com.disney.dmdc.qa.model.TitleHeaderResult;

public class TitleHeaderResponseFactory {

    public static TitleHeaderResponse createTitleHeaderResponse(
            TitleHeaderResult result, Integer statusCode, boolean error) {

        return TitleHeaderResponse.builder()
                .result(result)
                .httpStatusCode(statusCode)
                .hasError(error)
                .build();
    }

    public static TitleHeaderResponse createExpectedTitleHeaderResponse(String appTitleGuid, Integer userId,
                                                                        Integer distId, Integer localId) {

        return createTitleHeaderResponse(
                TitleHeaderResultFactory.createTitleHeader(appTitleGuid, userId, distId, localId),
                0,
                false
        );
    }

}
