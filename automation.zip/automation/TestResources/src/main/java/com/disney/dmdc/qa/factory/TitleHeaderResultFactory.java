package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.entities.ApplicationTitle;
import com.disney.dmdc.qa.entities.Header;
import com.disney.dmdc.qa.entities.ProductType;
import com.disney.dmdc.qa.entities.Synopsis;
import com.disney.dmdc.qa.exceptions.DbException;
import com.disney.dmdc.qa.model.TitleHeaderResult;
import com.disney.dmdc.qa.util.DateTime;
import com.disney.dmdc.qa.util.db.DmdCentralDbUtils;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.Arrays;
import java.util.List;

public class TitleHeaderResultFactory {

    public static TitleHeaderResult createTitleHeaderResult (
            Integer applicationTitleId, Integer distributionUnitId, String wprId, Integer cpmProductId,
            String episodeDomesticForeignNumber, Integer titleId, Integer titleVersionId, String titleName,
            String seasonName, Integer episodeNumber, String episodeName, String concept, String releaseDate,
            Integer runTime, String usBroadcast, Integer productTypeId, String productType,
            Boolean isHoldBack, Integer statusId, String division, String rating, List<String> genres,
            List<String> themes, String synopsis, List<String> overview, String titleRepImage_PreviewId,
            Integer titleRepImage_ApplicationAssetId, String backgroundImage_PreviewId, Integer actions) {

        return TitleHeaderResult.builder()
                .applicationTitleId(applicationTitleId)
                .distributionUnitId(distributionUnitId)
                .wprId(wprId)
                .cpmProductId(cpmProductId)
                .episodeDomesticForeignNumber(episodeDomesticForeignNumber)
                .titleId(titleId)
                .titleVersionId(titleVersionId)
                .titleName(titleName)
                .seasonName(seasonName)
                .episodeNumber(episodeNumber)
                .episodeName(episodeName)
                .concept(concept)
                .releaseDate(releaseDate)
                .runTime(runTime)
                .usBroadcast(usBroadcast)
                .productTypeId(productTypeId)
                .productType(productType)
                .isHoldBack(isHoldBack)
                .statusId(statusId)
                .division(division)
                .rating(rating)
                .genres(genres)
                .themes(themes)
                .synopsis(synopsis)
                .overview(overview)
                .titleRepImage_PreviewId(titleRepImage_PreviewId)
                .titleRepImage_ApplicationAssetId(titleRepImage_ApplicationAssetId)
                .backgroundImage_PreviewId(backgroundImage_PreviewId)
                .actions(actions)
                .build();
    }

    public static TitleHeaderResult createTitleHeader(String appTitleGuid, Integer userId, Integer distId, Integer localId) {

        List<String> genres=null;
        List<String> themes=null;
        List<String> overview=null;

        try {
            ApplicationTitle appTitle = DmdCentralDbUtils.selectApplicationTitle(appTitleGuid);
            Header header = DmdCentralDbUtils
                    .callTitleHeader(appTitle.getApplicationId(), userId, distId, appTitleGuid, localId);
            Synopsis synopsis = DmdCentralDbUtils.callTitleSynopsis(appTitleGuid, localId);
            ProductType productType = DmdCentralDbUtils.selectProductType(header.getProductTypeId());

            Boolean isHoldBackValue = header.getIsHoldBack() == 1;

            if (header.getGenres() != null) {
                genres = Arrays.asList(header.getGenres().split(","));
            }

            if (header.getThemes() != null) {
                themes = Arrays.asList(header.getThemes().split(";"));
            }

            if (header.getOverview() != null) {
                overview = Arrays.asList(header.getOverview().split("\n\n"));
            }

            String formattedDate = DateTime.convertDateTimeDbToJson(
                    header.getReleaseDate());

            return createTitleHeaderResult(
                    header.getApplicationTitleId(),
                    header.getDistributionUnitId(),
                    header.getWprId(),
                    header.getCpmProductId(),
                    "",
                    header.getTitleId(),
                    header.getTitleVersionId(),
                    header.getTitleName(),
                    header.getSeasonName(),
                    header.getEpisodeNumber(),
                    header.getEpisodeName(),
                    synopsis.getMedium(),
                    formattedDate,
                    header.getRunTime(),
                    header.getUsBroadcast(),
                    header.getProductTypeId(),
                    productType.getProductTypeName(),
                    isHoldBackValue,
                    header.getStatusId(),
                    header.getDivision(),
                    header.getRating(),
                    genres,
                    themes,
                    synopsis.getLong(),
                    overview,
                    header.getTitleRepImage_PreviewId().toLowerCase(),
                    header.getTitleRepImage_ApplicationAssetId(),
                    header.getBackgroundImage_PreviewId().toLowerCase(),
                    0
            );
        } catch (SQLException | ParseException e) {
            throw new DbException("SQL or Parse Exception occurred", e);
        }
    }
}
