package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.TitleIdHierarchyResponse;
import com.disney.dmdc.qa.model.TitleIdHierarchyResult;

public class TitleIdHierarchyResponseFactory {

    public static TitleIdHierarchyResponse createTitleHierarchyResponse(
            TitleIdHierarchyResult result, Integer httpStatusCode, Boolean hasError) {

        return TitleIdHierarchyResponse.builder().result(result)
                .httpStatusCode(httpStatusCode)
                .hasError(hasError)
                .build();
    }

    public static TitleIdHierarchyResponse createDefaultTitleHierarchyResponse(
            TitleIdHierarchyResult titleIdHierarchy) {

        return createTitleHierarchyResponse(
                titleIdHierarchy,
                0,
                false
        );
    }

}
