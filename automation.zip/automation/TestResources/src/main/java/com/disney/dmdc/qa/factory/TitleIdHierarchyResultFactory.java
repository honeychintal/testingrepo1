package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.entities.ApplicationTitle;
import com.disney.dmdc.qa.entities.TitleHierarchy;
import com.disney.dmdc.qa.exceptions.DbException;
import com.disney.dmdc.qa.model.TitleIdHierarchyResult;
import com.disney.dmdc.qa.util.db.DmdCentralDbUtils;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import lombok.experimental.UtilityClass;
import org.apache.commons.lang3.ObjectUtils;

import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.Objects;
import java.util.stream.Collectors;

@UtilityClass
public class TitleIdHierarchyResultFactory {

    public static TitleIdHierarchyResult createTitleHierarchyResult(
            String appTitleGuid, Integer userId, Integer distId) {

        try {
            ApplicationTitle appTitle = DmdCentralDbUtils.selectApplicationTitle(appTitleGuid);
            List<TitleHierarchy> hierarchyList = DmdCentralDbUtils
                    .callTitleHierarchyToList(appTitle.getApplicationId(), userId, distId, appTitleGuid);

            if (hierarchyList.isEmpty())
                return null;
            return mapSPDataToModel(hierarchyList);

        } catch (SQLException e) {
            throw new DbException("SQL exception occurred", e);
        }

    }

    public static TitleIdHierarchyResult mapSPDataToModel(List<TitleHierarchy> hierarchyList) {

        List<TitleHierarchy> seasonsList = createSeasonsList(hierarchyList);
        Map<Integer, List<TitleHierarchy>> episodesSeasonMap = createEpisodeSeasonMap(hierarchyList);

        List<TitleIdHierarchyResult> seasonWithEpisodeList = createSeasonWithEpisodes(seasonsList, episodesSeasonMap);
        return createTitleWithSeasonEpisode(seasonWithEpisodeList, hierarchyList.get(0));
    }

    /**
     * create Map of seasons with its episodes list
     * seasonNumber as key and episode details list as value
     * @param hierarchyList - list of result from SP(series,seasons,episodes)
     * @return
     */
    public static Map<Integer, List<TitleHierarchy>> createEpisodeSeasonMap(
            List<TitleHierarchy> hierarchyList) {

        if (hierarchyList.size() < 3) {
            return ImmutableMap.of(hierarchyList.get(hierarchyList.size() - 1).getSeasonNumber(), ImmutableList.of());
        }
        int season = 0;
        for (TitleHierarchy titleHierarchy : hierarchyList) {
            if (titleHierarchy.getSeasonNumber() != null && titleHierarchy.getEpisodeNumber() != null){
                season = titleHierarchy.getSeasonNumber();
                break;
            }
        }
        List<TitleHierarchy> subList = new ArrayList<>();
        Map<Integer, List<TitleHierarchy>> seasonsMap = new HashMap<>();
        for (int i = 2; i < hierarchyList.size(); i++) {
            if (hierarchyList.get(i).getSeasonNumber() == season &&
                    hierarchyList.get(i).getEpisodeNumber() != null) {
                subList.add(hierarchyList.get(i));
            } else {
                seasonsMap.put(season, new ArrayList<>(subList));
                season = hierarchyList.get(i).getSeasonNumber();
                subList.clear();
            }
        }
        seasonsMap.put(season, subList);
        return seasonsMap;

    }

    public static List<TitleHierarchy> createSeasonsList(List<TitleHierarchy> hierarchyList) {

        return hierarchyList
                .stream()
                .filter(item -> item.getEpisodeNumber() == null && item.getSeasonNumber() != null)
                .collect(Collectors.toList());
    }

    public static List<TitleIdHierarchyResult> createSeasonWithEpisodes(
            List<TitleHierarchy> seasonsList, Map<Integer, List<TitleHierarchy>> episodesSeasonMap) {

        if (episodesSeasonMap == null || episodesSeasonMap.isEmpty())
            return ImmutableList.of();

        return seasonsList.stream().map(season -> TitleIdHierarchyResult.builder()
                .id(season.getApplicationTitleGuid().toLowerCase())
                .name(season.getTitleName_Series() + " - " +
                        season.getTitleName_Season())
                .children(createEpisodesList(episodesSeasonMap
                        .get(season.getSeasonNumber())))
                .cpmProductIdEpisode(0)
                .cpmProductIdSeason(0)
                .cpmProductIdSeries(0)
                .episodeDomesticForeignNumber(Objects.toString(season.getDomesticEpisodeNumber(), "") +
                        Objects.toString(season.getForeignEpisodeNumber(), ""))
                .build()
        )
                .collect(Collectors.toList());
    }

    public static List<TitleIdHierarchyResult> createEpisodesList(List<TitleHierarchy> titleHierarchy) {

        if (titleHierarchy.isEmpty())
            return null;
        return titleHierarchy.stream().map(item -> TitleIdHierarchyResult
                .builder()
                .id(item.getApplicationTitleGuid().toLowerCase())
                .name("EP " + item.getEpisodeNumber() + " - " + item.getTitleName_Episode())
                .cpmProductIdEpisode(0)
                .cpmProductIdSeason(0)
                .cpmProductIdSeries(0)
                .episodeDomesticForeignNumber(Objects.toString(item.getDomesticEpisodeNumber(), "") +
                        Objects.toString(item.getForeignEpisodeNumber(), ""))
                .build()
        )
                .collect(Collectors.toList());
    }

    public static TitleIdHierarchyResult createTitleWithSeasonEpisode(
            List<TitleIdHierarchyResult> children, TitleHierarchy titleHierarchy) {

        return TitleIdHierarchyResult.builder()
                .id(titleHierarchy.getApplicationTitleGuid().toLowerCase())
                .name(titleHierarchy.getTitleName_Series())
                .children(children)
                .cpmProductIdEpisode(0)
                .cpmProductIdSeason(0)
                .cpmProductIdSeries(0)
                .episodeDomesticForeignNumber(Objects.toString(titleHierarchy.getDomesticEpisodeNumber(), "") +
                        Objects.toString(titleHierarchy.getForeignEpisodeNumber(), ""))

                .build();
    }

}
