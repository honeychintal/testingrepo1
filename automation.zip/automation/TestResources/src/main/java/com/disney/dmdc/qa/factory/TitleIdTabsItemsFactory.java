package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.entities.ApplicationTitle;
import com.disney.dmdc.qa.entities.TabAssets;
import com.disney.dmdc.qa.entities.TitleTabs;
import com.disney.dmdc.qa.exceptions.DbException;
import com.disney.dmdc.qa.model.AssetGroups;
import com.disney.dmdc.qa.model.TitleIdTabsItems;
import com.disney.dmdc.qa.util.db.DmdCentralDbUtils;

import java.sql.SQLException;
import java.util.List;
import java.util.stream.Collectors;

public class TitleIdTabsItemsFactory {

    public static List<TitleIdTabsItems> createTitleIdTabsItems(Integer userId, Integer distId, String appTitleGuid, String searchMode) {

        try {
            ApplicationTitle appTitle = DmdCentralDbUtils.selectApplicationTitle(appTitleGuid);
            TitleTabs titleTabs = DmdCentralDbUtils.callTitleIdTabs(
                    appTitle.getApplicationId(), userId, distId, appTitleGuid, searchMode);

            return createTitleIdResponseItems(titleTabs);

        } catch (SQLException e) {
            throw new DbException("SQL Exception occurred", e);
        }

    }

    public static List<AssetGroups> createAssetGroups(Integer tabId, List<TabAssets> tabAssets) {

        List<TabAssets> assetGroupList = tabAssets.stream().filter(item ->
                item.getTabId().equals(tabId)).collect(Collectors.toList());

        return assetGroupList.stream().map(item -> AssetGroups
                .builder()
                .tabId(item.getTabId())
                .assetTypeId(item.getAssetTypeId())
                .assetType(item.getAssetType())
                .totalCount(item.getTotal())
                .sortOrder(item.getSortOrder())
                .newCount(item.getNewCount())
                .build()
        )
                .collect(Collectors.toList());
    }

    public static List<TitleIdTabsItems> createTitleIdResponseItems(TitleTabs titleTabs) {

        return titleTabs.getTabNames().stream().map(item -> TitleIdTabsItems
                .builder()
                .tabId(item.getTabId())
                .tabName(item.getTabName())
                .totalCount(item.getTotal())
                .sortOrder(item.getSortOrder())
                .assetGroups(createAssetGroups(item.getTabId(), titleTabs.getTabAssets()))
                .path(item.getPath())
                .newCount(item.getNewCount())
                .build()
        )
                .collect(Collectors.toList());
    }

}
