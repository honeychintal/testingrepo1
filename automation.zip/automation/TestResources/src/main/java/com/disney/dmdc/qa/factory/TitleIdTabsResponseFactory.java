package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.TitleIdTabsItems;
import com.disney.dmdc.qa.model.TitleIdTabsResponse;

import java.util.List;

public class TitleIdTabsResponseFactory {

    public static TitleIdTabsResponse createTitleIdTabsResponse(
            List<TitleIdTabsItems> items, Integer pageIndex, Integer httpStatusCode, boolean hasError) {

        return TitleIdTabsResponse.builder().items(items)
                .pageIndex(pageIndex)
                .httpStatusCode(httpStatusCode)
                .hasError(hasError)
                .build();
    }

    public static TitleIdTabsResponse createDefaultTitleIdTabsResponse(List<TitleIdTabsItems> titleIdTabs) {

        return createTitleIdTabsResponse(
                titleIdTabs,
                0,
                0,
                false);
    }

}
