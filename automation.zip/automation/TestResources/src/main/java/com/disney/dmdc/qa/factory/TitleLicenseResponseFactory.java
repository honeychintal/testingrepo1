package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.entities.ApplicationTitle;
import com.disney.dmdc.qa.entities.License;
import com.disney.dmdc.qa.entities.Locale;
import com.disney.dmdc.qa.exceptions.DbException;
import com.disney.dmdc.qa.model.ItemLocals;
import com.disney.dmdc.qa.model.LicenseItems;
import com.disney.dmdc.qa.model.TitleLicenseGetResponse;
import com.disney.dmdc.qa.util.db.DmdCentralDbUtils;
import com.google.common.collect.ImmutableList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TitleLicenseResponseFactory {

    private static final Logger log = LoggerFactory.getLogger(TitleLicenseResponseFactory.class);

    public static TitleLicenseGetResponse createLicenseData(List<LicenseItems> items, Integer pageIndex, Integer httpStatusCode, Boolean hasError) {
        return TitleLicenseGetResponse.builder()
                .items(items)
                .pageIndex(pageIndex)
                .httpStatusCode(httpStatusCode)
                .hasError(hasError)
                .build();
    }

    public static TitleLicenseGetResponse createLicenseResponse(int userId, int distId, String appTitleGuid) {
        return createLicenseData(
                createResponseFromDb(userId, distId, appTitleGuid),
                0,
                0,
                false);
    }

    public static List<LicenseItems> createResponseFromDb(int userId, int distId, String appTitleGuid) {

        List<LicenseItems> licenseItems = new ArrayList<LicenseItems>();

        try {
            ApplicationTitle appTitle = DmdCentralDbUtils.selectApplicationTitle(appTitleGuid);

            log.info(String.format("Get License details from DB based on userId %s and title guid %s", userId, appTitleGuid));
            List<License> licenses = DmdCentralDbUtils
                    .callTitleLicenseToList(appTitle.getApplicationId(), userId, appTitleGuid);

            log.info(String.format("Get Local details from DB based on userId %s, title guid %s and DU %s",
                    userId, appTitleGuid, distId));
            List<Locale> localeList = DmdCentralDbUtils
                    .callTitleLocalToList(appTitle.getApplicationId(), userId, distId, appTitleGuid);

            for (License license : licenses) {

                LicenseItems licenseItem = LicenseItems.builder()
                        .distributionUnitId(license.getDistributionUnitId())
                        .distributionUnitAbbr(license.getDistributionUnitName())
                        .productTypeId(license.getProductType())
                        .active(license.getIsDefault())
                        .licenseType(0)
                        .build();

                if(license.getIsDefault())
                    for (Locale locale : localeList) {
                        licenseItem.setLocals(ImmutableList.of(ItemLocals.builder()
                                .active(locale.getIsDefault())
                                .id(locale.getLocaleId())
                                .name(locale.getDisplayLocale())
                                .build()));
                    }
                else
                    licenseItem.setLocals(null);
                licenseItems.add(licenseItem);
            }
            return licenseItems;
        }
        catch (SQLException e) {
            throw new DbException("SQL Exception occurred", e);
        }
    }
}
