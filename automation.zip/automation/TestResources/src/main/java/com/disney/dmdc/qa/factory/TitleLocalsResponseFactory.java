package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.ItemLocals;
import com.disney.dmdc.qa.model.TitleLocalsGetResponse;

import java.util.List;

public class TitleLocalsResponseFactory {
    public static TitleLocalsGetResponse createLocalsResponse(List<ItemLocals> items, Integer pageIndex, Integer statusCode, boolean hasError ){

        return TitleLocalsGetResponse.builder()
                .items(items)
                .pageIndex(pageIndex)
                .httpStatusCode(statusCode)
                .hasError(hasError)
                .build();
    }

    public static TitleLocalsGetResponse createExpectedLocalsResponse(String appTitleGuid, Integer userId, Integer distId) {

        return createLocalsResponse(
                ItemLocalsFactory.createTitleLocals(appTitleGuid, userId, distId),
                0,
                0,
                false
        );
    }
}
