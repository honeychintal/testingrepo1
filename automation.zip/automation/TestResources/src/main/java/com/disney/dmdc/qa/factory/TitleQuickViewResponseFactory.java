package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.TitleQuickViewResponse;
import com.disney.dmdc.qa.model.TitleQuickViewResult;

public class TitleQuickViewResponseFactory {

    public static TitleQuickViewResponse createTitleQuickViewResponse (
            TitleQuickViewResult result, Integer httpStatusCode, Boolean hasError) {

        return TitleQuickViewResponse.builder()
                .result(result)
                .httpStatusCode(httpStatusCode)
                .hasError(hasError)
                .build();
    }

    public static TitleQuickViewResponse createExpectedTitleQuickViewResponse(String appTitleGuid, Integer userId, Integer localId) {

        return createTitleQuickViewResponse (
                TitleQuickViewResultFactory.titleQuickViewResult(appTitleGuid, userId, localId),
                0,
                false);
    }
}