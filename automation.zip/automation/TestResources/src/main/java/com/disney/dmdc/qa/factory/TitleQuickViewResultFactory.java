package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.entities.ApplicationTitle;
import com.disney.dmdc.qa.entities.ProductType;
import com.disney.dmdc.qa.entities.QuickView;
import com.disney.dmdc.qa.entities.Synopsis;
import com.disney.dmdc.qa.entities.Talent;
import com.disney.dmdc.qa.exceptions.DbException;
import com.disney.dmdc.qa.model.TalentsItem;
import com.disney.dmdc.qa.model.TitleQuickViewResult;
import com.disney.dmdc.qa.util.db.DmdCentralDbUtils;
import com.disney.qa.constants.JsonUnit;
import com.google.common.collect.ImmutableList;
import lombok.experimental.UtilityClass;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@UtilityClass
public class TitleQuickViewResultFactory {

    public static TitleQuickViewResult createTitleQuickViewResult(
            Integer applicationTitleId, Integer distributionUnitId, String wprId, Integer cpmProductId, Integer titleId,
            Integer titleVersionId, String titleName, String seasonName, Integer episodeNumber, String episodeName,
            String concept, String releaseDate, Integer runTime, String usBroadcast, Integer productTypeId,
            String productType, Boolean isHoldback, Integer statusId, String division, String rating, String genres,
            String themes, String synopsis, String overview, String titleRepImagePreviewId,
            String backgroudImagePreviewId, List<TalentsItem> talents, List<String> releases, List<Integer> runTimes,
            List<String> rights, List<String> comments
    ) {

        return TitleQuickViewResult.builder()
                .applicationTitleId(applicationTitleId)
                .distributionUnitId(distributionUnitId)
                .wprId(wprId)
                .cpmProductId(cpmProductId)
                .titleId(titleId)
                .titleVersionId(titleVersionId)
                .titleName(titleName)
                .seasonName(seasonName)
                .episodeNumber(episodeNumber)
                .episodeName(episodeName)
                .concept(concept)
                .releaseDate(releaseDate)
                .runTime(runTime)
                .usBroadcast(usBroadcast)
                .productTypeId(productTypeId)
                .productType(productType)
                .isHoldback(isHoldback)
                .statusId(statusId)
                .division(division)
                .rating(rating)
                .genres(genres)
                .themes(themes)
                .synopsis(synopsis)
                .overview(overview)
                .titleRepImagePreviewId(titleRepImagePreviewId)
                .backgroudImagePreviewId(backgroudImagePreviewId)
                .talents(talents)
                .releases(releases)
                .runTimes(runTimes)
                .rights(rights)
                .comments(comments)
                .build();
    }

    public static TitleQuickViewResult titleQuickViewResult(String appTitleGuid, Integer userId, Integer localId) {

        try {
            ApplicationTitle appTitle = DmdCentralDbUtils.selectApplicationTitle(appTitleGuid);
            QuickView quickView = DmdCentralDbUtils.callTitleQuickViewGetInfo(appTitle.getApplicationId(), userId, appTitleGuid);
            Synopsis synopsis = DmdCentralDbUtils.callTitleSynopsis(appTitleGuid, localId);
            ProductType productType = DmdCentralDbUtils.selectProductType(quickView.getTitles().get(0).getProductTypeId());

            List<TalentsItem> talents = new ArrayList<TalentsItem>();

            for (int i = 0; i < quickView.getTalents().size(); i++) {
                Talent talent = quickView.getTalents().get(i);

                if (talent.getCreditTypeDescription().equals("Cast")) {
                    talents.add(
                            TalentsItem.builder()
                                    .talentId(talent.getTalentId())
                                    .creditTypeId(talent.getCreditTypeId())
                                    .creditTypeDescription(talent.getCreditTypeDescription())
                                    .talentName(talent.getTalentName())
                                    .roleName(talent.getRoleName())
                                    .castTypeId(talent.getCastTypeId())
                                    .castType(talent.getCastType())
                                    .hasBio(talent.getHasBio())
                                    .sortOrder(talent.getSortOrder())
                                    .build()
                    );
                }
            }

            return createTitleQuickViewResult(
                    quickView.getTitles().get(0).getApplicationTitleId(),
                    quickView.getTitles().get(0).getDistributionUnitId(),
                    quickView.getTitles().get(0).getWprId(),
                    quickView.getTitles().get(0).getCpmProductId(),
                    quickView.getTitles().get(0).getTitleId(),
                    quickView.getTitles().get(0).getTitleVersionId(),
                    quickView.getTitles().get(0).getTitleName(),
                    quickView.getTitles().get(0).getSeasonName(),
                    quickView.getTitles().get(0).getEpisodeNumber(),
                    quickView.getTitles().get(0).getEpisodeName(),
                    synopsis.getMedium(),
                    JsonUnit.ANY_STRING_VALUE,
                    quickView.getTitles().get(0).getRunTime(),
                    quickView.getTitles().get(0).getUsBroadcast(),
                    //PPBPE-2659 - Always getting 0 in api response though SP is giving correct info. Once fixed, need to update test
                    0,
                    productType.getProductTypeName(),
                    quickView.getTitles().get(0).getIsHoldBack(),
                    quickView.getTitles().get(0).getStatusId(),
                    quickView.getTitles().get(0).getDivision(),
                    quickView.getTitles().get(0).getRating(),
                    quickView.getTitles().get(0).getGenres(),
                    quickView.getTitles().get(0).getThemes(),
                    synopsis.getLong(),
                    quickView.getTitles().get(0).getOverview(),
                    quickView.getTitles().get(0).getTitleRepImage_PreviewId().toLowerCase(),
                    quickView.getTitles().get(0).getBackgroundImage_PreviewId().toLowerCase(),
                    talents,
                    //PPBPE-2659- SP is giving data but API response is empty array. Need to update test once fixed
                    ImmutableList.of(),
                    //PPBPE-2659- SP is giving data but API response is empty array. Need to update test once fixed
                    ImmutableList.of(),
                    ImmutableList.of(),
                    ImmutableList.of()
            );

        } catch (SQLException e) {
            throw new DbException("SQL Exception occurred", e);
        }
    }
}