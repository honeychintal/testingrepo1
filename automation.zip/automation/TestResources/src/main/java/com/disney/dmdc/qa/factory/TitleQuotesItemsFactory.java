package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.entities.ApplicationTitle;
import com.disney.dmdc.qa.entities.Quotes;
import com.disney.dmdc.qa.exceptions.DbException;
import com.disney.dmdc.qa.model.TitleQuotesItems;
import com.disney.dmdc.qa.util.db.DmdCentralDbUtils;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TitleQuotesItemsFactory {

    public static TitleQuotesItems createTitleQuotesItem(String journalist, String agency, String postDate, String text, Integer sortOrder)
    {
        return TitleQuotesItems.builder()
                .journalist(journalist)
                .agency(agency)
                .postDate(postDate)
                .text(text)
                .sortOrder(sortOrder)
                .build();
    }

    public static List<TitleQuotesItems> createTitleQuotesItemDb(String appTitleGuid, Integer distId, Integer localId){

        List<TitleQuotesItems> titleQuotesList = new ArrayList<TitleQuotesItems>();

        try{
            List<Quotes> quotesFromDBList = DmdCentralDbUtils.callTitleQuotesToList(appTitleGuid, distId, localId);

            for (Quotes quoteEntity : quotesFromDBList) {
                titleQuotesList.add(createTitleQuotesItem(quoteEntity.getJournalist(),
                                    quoteEntity.getAgency(),
                                    quoteEntity.getPostDate(),
                                    quoteEntity.getText(),
                                    quoteEntity.getSortOrder()
                        ));
            }
            return titleQuotesList;

        } catch (SQLException e) {
            throw new DbException("SQL Exception occurred", e);
        }

    }
}
