package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.TitleQuotesItems;
import com.disney.dmdc.qa.model.TitleQuotesResponse;

import java.util.List;

public class TitleQuotesResponseFactory {

    public static TitleQuotesResponse createTitleQuotesItems(List<TitleQuotesItems> items, Integer pageIndex, Integer httpStatusCode, boolean hasError){
        return TitleQuotesResponse.builder()
                .items(items)
                .pageIndex(pageIndex)
                .httpStatusCode(httpStatusCode)
                .hasError(hasError)
                .build();

    }

    public static TitleQuotesResponse createTitleQuotesResponse(String applicationTitleGuid, Integer distId, Integer localId){

        return createTitleQuotesItems(TitleQuotesItemsFactory.createTitleQuotesItemDb(applicationTitleGuid, distId, localId),
                0,
                0,
                false
        );

    }

}
