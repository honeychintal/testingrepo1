package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.FacetQuery;
import com.disney.dmdc.qa.model.FieldGetResponse;
import com.disney.dmdc.qa.model.TitleSearchRequest;
import com.google.common.collect.ImmutableList;
import java.util.List;

public class TitleSearchRequestFactory {

    public static TitleSearchRequest createTitleSearchRequest(
            String keyword, List<FieldGetResponse> fields, List<FacetQuery> facets, Integer pageSize,
            Boolean includeFacets, String apiPath, List<Object> sortDescriptors){

        return TitleSearchRequest.builder()
                .keyword(keyword)
                .fields(fields)
                .facets(facets)
                .pageSize(pageSize)
                .includeFacets(includeFacets)
                .apiPath(apiPath)
                .sortDescriptors(sortDescriptors)
                .build();
    }

    public static TitleSearchRequest createRequestWithKeyword(String keyword){

        return createTitleSearchRequest(
                keyword,
                ImmutableList.of(
                        FieldFactory.createField(
                                "titlename",
                                "Title Name",
                                true
                        ),
                        FieldFactory.createField(
                                "titlefinancialid",
                                "Title ID",
                                true
                        ),
                        FieldFactory.createField(
                                "cast",
                                "Cast and Crew",
                                true
                        ),
                        FieldFactory.createField(
                                "producercredits",
                                "Production Credits",
                                true
                        )
                ),
                ImmutableList.of(),
                50,
                true,
                "api/portal/title/search",
                ImmutableList.of()
        );
    }

    public static TitleSearchRequest createRequestWithAllTvSeasons(){

        return createTitleSearchRequest(
                "",
                ImmutableList.of(
                        FieldFactory.createField(
                                "titlename",
                                "Title Name",
                                true
                        ),
                        FieldFactory.createField(
                                "wprid",
                                "Title ID",
                                true
                        ),
                        FieldFactory.createField(
                                "genre",
                                "Genre",
                                true
                        ),
                        FieldFactory.createField(
                                "cast",
                                "Cast",
                                true
                        ),
                        FieldFactory.createField(
                                "producercredits",
                                "Production Credits",
                                true
                        )
                ),
                ImmutableList.of(
                        RequestFacetFactory.createRequestFacet(
                                "producttype",
                                "Series",
                                0,
                                10,
                                true
                        )
                ),
                50,
                true,
                "api/portal/title/search",
                ImmutableList.of()
        );
    }

    public static TitleSearchRequest createRequestWithTitleID(String keyword){

        return createTitleSearchRequest(
                keyword,
                ImmutableList.of(
                        FieldFactory.createField(
                                "titlefinancialid",
                                "Title ID",
                                true
                        ),
                        FieldFactory.createField(
                                "titlename",
                                "Title Name",
                                true
                        )
                ),
                ImmutableList.of(),
                null,
                false,
                null,
                ImmutableList.of()
        );
    }
}
