package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.FacetKey;
import com.disney.dmdc.qa.model.TitleSearchResponse;
import com.disney.dmdc.qa.model.TitleSearchResponseItem;
import java.util.List;
import lombok.experimental.UtilityClass;

@UtilityClass
public class TitleSearchResponseFactory {

    public static TitleSearchResponse createSearchResponse(
            String searchId, List<FacetKey> facets, List<TitleSearchResponseItem> items, Integer pageIndex,
            String totalCount, Integer httpStatusCode, Boolean hasError, Integer pageSize
    ) {
        return TitleSearchResponse.builder()
                .searchId(searchId)
                .facets(facets)
                .items(items)
                .pageIndex(pageIndex)
                .totalCount(totalCount)
                .httpStatusCode(httpStatusCode)
                .hasError(hasError)
                .pageSize(pageSize)
                .build();
    }
}
