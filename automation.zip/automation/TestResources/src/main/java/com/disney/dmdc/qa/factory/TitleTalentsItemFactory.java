package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.entities.Talent;
import com.disney.dmdc.qa.exceptions.DbException;
import com.disney.dmdc.qa.model.TalentsItem;
import com.disney.dmdc.qa.util.db.DmdCentralDbUtils;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TitleTalentsItemFactory {

    public static List<TalentsItem> createTalentItemsList(String titleGuidId, int localId) {

        List<TalentsItem> talentsItems = new ArrayList<>();
        try {
            List<Talent> titleTalents = DmdCentralDbUtils.callTitleTalentsToList(titleGuidId, localId);
            for (Talent talent : titleTalents) {
                talentsItems.add(
                        TalentsItem.builder()
                                .talentId(talent.getTalentId())
                                .creditTypeId(talent.getCreditTypeId())
                                .creditTypeDescription(talent.getCreditTypeDescription())
                                .talentName(talent.getTalentName())
                                .roleName(talent.getRoleName().replace("</I>", "</i>"))
                                .castTypeId(talent.getCastTypeId())
                                .castType(talent.getCastType())
                                .hasBio(talent.getHasBio())
                                .sortOrder(talent.getSortOrder())
                                .build()
                );
            }
            return talentsItems;
        } catch (SQLException e) {
            throw new DbException("SQL Exception occurred", e);
        }
    }
}