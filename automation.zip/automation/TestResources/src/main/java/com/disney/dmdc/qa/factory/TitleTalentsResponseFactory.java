package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.TalentsItem;
import com.disney.dmdc.qa.model.TitleTalentsGetResponse;

import java.util.List;

public class TitleTalentsResponseFactory {

    public static TitleTalentsGetResponse createTitleTalentsResponse(
            List<TalentsItem> items, Integer pageIndex, Integer httpStatusCode, Boolean hasError
    ) {
        return TitleTalentsGetResponse.builder()
                .items(items)
                .pageIndex(pageIndex)
                .httpStatusCode(httpStatusCode)
                .hasError(hasError)
                .build();
    }

    public static TitleTalentsGetResponse createTitleTalentsDefaultResponse(String titleGuidId, int localId) {
        return createTitleTalentsResponse(
                TitleTalentsItemFactory.createTalentItemsList(titleGuidId, localId),
                0,
                0,
                false
        );
    }
}
