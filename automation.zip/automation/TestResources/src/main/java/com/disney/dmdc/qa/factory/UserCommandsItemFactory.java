package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.UserCommandsItem;
import com.disney.dmdc.qa.model.UserCommandsItemProperties;

public class UserCommandsItemFactory {

    public static UserCommandsItem createUserCommandsItem (
            UserCommandsItemProperties properties, String text, String description, Integer id, String name) {

        return UserCommandsItem.builder()
                .properties(properties)
                .text(text)
                .description(description)
                .id(id)
                .name(name)
                .build();
    }
}