package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.UserCommandsItem;
import com.disney.dmdc.qa.model.UserCommandsResponse;

import java.util.List;

public class UserCommandsResponseFactory {

    public static UserCommandsResponse createUserCommandsResponse (
            List<UserCommandsItem> commandsItems, Integer pageIndex, Integer httpStatusCode, boolean hasError) {

        return UserCommandsResponse.builder()
                .items(commandsItems)
                .pageIndex(pageIndex)
                .httpStatusCode(httpStatusCode)
                .hasError(hasError)
                .build();
    }

    public static UserCommandsResponse createDefaultUserCommandsResponse (List<UserCommandsItem> commandsItems) {

        return createUserCommandsResponse(
                commandsItems,
                0,
                0,
                false
        );
    }
}