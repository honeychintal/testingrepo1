package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.UserCommentsResponse;
import com.disney.dmdc.qa.model.UserCommentsResult;

public class UserCommentsFactory {

    public static UserCommentsResponse createUserCommentsResponse(
            UserCommentsResult result, Integer httpStatus, Boolean hasError) {

        return UserCommentsResponse.builder()
                .result(result)
                .httpStatusCode(httpStatus)
                .hasError(hasError)
                .build();
    }

    public static UserCommentsResponse testUserCommentsResponse(
            UserCommentsResult result) {

        return createUserCommentsResponse(
                result,
                0,
                false
        );
    }

}
