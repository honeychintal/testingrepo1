package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.UserGroupsResponse;
import com.disney.dmdc.qa.model.UserGroupsResult;

public class UserGroupsResponseFactory {

    public static UserGroupsResponse createUserGroupsResponse(
            UserGroupsResult result, Integer httpStatusCode, Boolean hasError) {

        return UserGroupsResponse.builder()
                .result(result)
                .httpStatusCode(httpStatusCode)
                .hasError(hasError)
                .build();
    }

    public static UserGroupsResponse testUserGroupsResponse(
            UserGroupsResult result) {

        return createUserGroupsResponse(
                result,
                0,
                false
        );
    }

}
