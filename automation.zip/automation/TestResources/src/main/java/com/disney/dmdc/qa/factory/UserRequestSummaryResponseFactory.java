package com.disney.dmdc.qa.factory;

import com.disney.dmdc.qa.model.UserRequestSummaryResponse;
import com.disney.dmdc.qa.model.UserRequestSummaryResult;

public class UserRequestSummaryResponseFactory {

    public static UserRequestSummaryResponse createUserRequestSummaryResponse(
            UserRequestSummaryResult result, Integer httpStatus, Boolean hasError) {

        return UserRequestSummaryResponse.builder()
                .result(result)
                .httpStatusCode(httpStatus)
                .hasError(hasError)
                .build();
    }

    public static UserRequestSummaryResponse testUserRequestSummaryResponse(
            UserRequestSummaryResult result) {

        return createUserRequestSummaryResponse(
                result,
                0,
                false
        );
    }

}
