package com.disney.dmdc.qa.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
@JsonInclude(JsonInclude.Include.ALWAYS)
public class AssetAudioChannels {

    private Integer channelNumber;
    private String audioChannelLanguage;
    private String audioChannelConfig;
    private String audioChannelFormat;
    private String audioChannelUsage;
    private String audioChannelDynamicRange;
}