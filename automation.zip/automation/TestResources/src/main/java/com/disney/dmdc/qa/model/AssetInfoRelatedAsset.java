package com.disney.dmdc.qa.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class AssetInfoRelatedAsset {

    Integer id;
    Integer parentId;
    Integer orderNo;
    String titleName;
    String wprId;
    Integer cpmProductId;
    String episodeDomesticForeignNumber;
    String firstReleaseDate;
    Integer titleHoldback;
    Integer assetHoldback;
    String assetStatus;
    String assetName;
    String espritNumId;
    Integer assetTypeId;
    Integer productTypeId;
    String createdDate;
    String assetGroup;
    String groupParent;
    Boolean isMain;
    Integer sortOrder;
    Boolean isExclusive;
    Integer isIntl;
    Integer isTVDOnly;
    Boolean isLimitedUse;
    String audioChannel2Usage;
    @JsonProperty("Public")
    Integer isPublic;
    String modifiedDate;
    Integer repositoryId;
    String assetType;
    String subAssetType;
    String versionName;
    String versionDescription;
    Integer versionId;
    String techSpec;
    String dubbedLanguage;
    String subtitleLanguage;
    String textedLanguage;
    String conformedLanguage;
    String territory;
    String aperture;
    String runTime;
    String fileName;
    Long fileSize;
    String division;
    String department;
    String profileType;
    String frameRate;
    String resolution;
    String canvasAspectRatio;
    String videoAspectRatio;
    String canvasHeight;
    String canvasWidth;
    String videoCodec;
    String videoBitRate;
    String audioCodec;
    String audioBitDepth;
    String dimension;
    String assetDimension;
    String audioChannel1Config;
    String audioChannel1Language;
    String audioChannel1Format;
    String audioChannel1DynamicRange;
    String audioChannel2Config;
    String audioChannel2Language;
    String audioChannel2Format;
    String embeddedCCType;
    @JsonProperty("CCSubtitleFileFormat")
    String ccSubtitleFileFormat;
    String closedCaptionTextPresentation;
    String replacementDate;
    String replacementReason;
    @JsonProperty("CCLang")
    String ccLang;
    String audioChannel1Usage;
    String videoNotes;
    @JsonProperty("QCType")
    String qcType;
    Boolean isReplaced;
    Boolean isReplacementExpired;
    Integer view;
    Integer download;
    Integer stream;
    @JsonProperty("BQDownload")
    Integer bqDownload;
    @JsonProperty("Thumbnail_PreviewId")
    String thumbnailPreviewId;
    @JsonProperty("Thumbnail_DomainNumber")
    String thumbnailDomainNumber;
    String productType;
    String createdBy;
    String modifiedBy;
    String deliveryType;
    String colorSpace;
    String videoDynamicRange;
    String videoDynamicRangeFormat;
    String hdrMetadata;
    Boolean inCart;
    @JsonProperty("Thumbnail_CanAnimate")
    Boolean thumbnailCanAnimate;
    Boolean isPlayable;
    Boolean isZoomSupported;
    Integer actions;
    List<Snipe> snipes;
}
