package com.disney.dmdc.qa.model;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class FacetValue {

	private Integer totalCount;
	private Integer type;
	private String id;
	private String name;
	private String value;
	private Boolean selected;
	private Integer from;
	private Integer to;
}
