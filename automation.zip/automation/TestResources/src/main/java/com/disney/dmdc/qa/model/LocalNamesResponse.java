package com.disney.dmdc.qa.model;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class LocalNamesResponse {

	private List<FacetKey> facets;
	private List<Item> items;
	private Integer pageIndex;
	private Integer pageSize;
	private Integer totalCount;
	private Integer httpStatusCode;
	private Boolean hasError;
}
