package com.disney.dmdc.qa.model;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class MembershipUserIdResult {

    private Integer id;
    private Boolean isEditable;
    private Boolean isUserOwnRequest;
    private MembershipUserDetails firstName;
    private MembershipUserDetails lastName;
    private MembershipUserDetails email;
    private MembershipUserDetails telephoneNumber;
    private MembershipUserDetails company;
    private MembershipUserDetails department;
    private MembershipUserDetails title;
    private Country country;
    private String oktaUserId;
    private String oktaUsername;
    private String oktaUserStatus;
    private OktaProviderStatusValue oktaProvider;
    private MembershipUserDates oktaUserLogsUrl;
    private MembershipUserStatus status;
    private String changePasswordDate;
    private MembershipUserDates effectiveDate;
    private MembershipUserDates expirationDate;
    private String lastLoginDate;
    private String createdDate;
    private List<UserGroupsIdProviders> idPProviders;
}
