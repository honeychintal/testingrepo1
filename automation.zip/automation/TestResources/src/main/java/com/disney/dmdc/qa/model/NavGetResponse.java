package com.disney.dmdc.qa.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class NavGetResponse {

    private Integer userId;
    private String email;
    private String firstName;
    private String lastName;
    private List<NavGetSections> sections;

    @JsonProperty("Default")
    private NavGetDataElement defaultObject;
}
