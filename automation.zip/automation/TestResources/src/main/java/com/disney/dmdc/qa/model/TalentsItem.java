package com.disney.dmdc.qa.model;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class TalentsItem {

    private Integer talentId;
    private Integer creditTypeId;
    private String creditTypeDescription;
    private String talentName;
    private String roleName;
    private Integer castTypeId;
    private String castType;
    private Boolean hasBio;
    private Integer sortOrder;

}
