package com.disney.dmdc.qa.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
@JsonInclude(JsonInclude.Include.ALWAYS)
public class TitleAvailabilityDataElement {
	private String applicationTitleGuid;
	private Integer episodeNumber;
	private String wprId;
	private String titleName;
	private String rating;
	private String releaseDate;
	private String previewId;
	private String synopsisText;
	private String synopsis;
	private String episodicPhotos;
	private String eventPhotos;
	private String galleryPhotos;
	private String logosArtwork;
	private String hELogosArtwork;
	private String musicCues;
	private String productionStills;
	private String hEProductionStills;
	private String scripts;
	private String specialShootPhotos;
	private String hDRMetadata;
	private String bQFullProgram;
	private String closedCaptions;
	private String dubCards;
	private String localizationReports;
	private String subtitles;
	private String titleRep;
	private String screenersFullProgram;
	private String promosTrailers;
	private String cpmProductId;
	private String domesticEpisodeNumber;
	private String foreignEpisodeNumber;
}
