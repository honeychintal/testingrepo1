package com.disney.dmdc.qa.model;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class TitleHeaderResult {

    Integer applicationTitleId;
    Integer distributionUnitId;
    String wprId;
    Integer cpmProductId;
    String episodeDomesticForeignNumber;
    Integer titleId;
    Integer titleVersionId;
    String titleName;
    String seasonName;
    Integer episodeNumber;
    String episodeName;
    String concept;
    String releaseDate;
    Integer runTime;
    String usBroadcast;
    Integer productTypeId;
    String productType;
    Boolean isHoldBack;
    Integer statusId;
    String division;
    String rating;
    List<String> genres;
    List<String> themes;
    String synopsis;
    List<String> overview;
    String titleRepImage_PreviewId;
    Integer titleRepImage_ApplicationAssetId;
    String backgroundImage_PreviewId;
    Integer actions;
}
