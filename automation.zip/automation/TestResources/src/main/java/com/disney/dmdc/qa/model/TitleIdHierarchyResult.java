package com.disney.dmdc.qa.model;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class TitleIdHierarchyResult {

    private String id;
    private String name;
    private List<TitleIdHierarchyResult> children;
    private Integer cpmProductIdSeries;
    private Integer cpmProductIdSeason;
    private Integer cpmProductIdEpisode;
    private String episodeDomesticForeignNumber;
}
