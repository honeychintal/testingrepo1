package com.disney.dmdc.qa.model;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class TitleQuickViewResult {

    private Integer applicationTitleId;
    private Integer distributionUnitId;
    private String wprId;
    private Integer cpmProductId;
    private Integer titleId;
    private Integer titleVersionId;
    private String titleName;
    private String seasonName;
    private Integer episodeNumber;
    private String episodeName;
    private String concept;
    private String releaseDate;
    private Integer runTime;
    private String usBroadcast;
    private Integer productTypeId;
    private String productType;
    private Boolean isHoldback;
    private Integer statusId;
    private String division;
    private String rating;
    private String genres;
    private String themes;
    private String synopsis;
    private String overview;
    private String titleRepImagePreviewId;
    private String backgroudImagePreviewId;
    private List<TalentsItem> talents;
    private List<String> releases;
    private List<Integer> runTimes;
    private List<String> rights;
    private List<String> comments;
}