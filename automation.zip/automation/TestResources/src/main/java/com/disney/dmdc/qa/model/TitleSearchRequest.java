package com.disney.dmdc.qa.model;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class TitleSearchRequest {
    private String keyword;
    private List<FieldGetResponse> fields;
    private List<FacetQuery> facets;
    private Integer pageSize;
    private Boolean includeFacets;
    private String apiPath;
    private List<Object> sortDescriptors;
}
