package com.disney.dmdc.qa.model;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class TitleSearchResponseItem {
    private String id;
    private String name;
    private String label;
    private String releaseDate;
    private String previewId;
    private String synopsis;
    private List<Snipe> snipes;
    private String productType;
    private Boolean titleHoldback;
    private Integer holdbackToAirdate;
    private String wprId;
    private Integer cpmProductId;
    private String episodeDomesticForeignNumber;
    private Integer applicationTitleId;
}
