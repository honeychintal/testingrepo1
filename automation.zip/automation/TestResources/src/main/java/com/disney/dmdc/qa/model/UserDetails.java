package com.disney.dmdc.qa.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@AllArgsConstructor
@Builder
public class UserDetails {

    private Integer id;
    private String email;
    private String firstName;
    private String lastName;
    private String userType;
}
