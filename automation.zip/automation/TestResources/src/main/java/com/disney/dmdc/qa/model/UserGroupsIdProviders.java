package com.disney.dmdc.qa.model;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class UserGroupsIdProviders {

    private Integer identityProviderId;
    private String identityProviderName;
    private String idpUserId;
    private String idpUsername;
    private String idpUserType;
    private String idpUserStatus;
    private Boolean canViewDetails;
    private String idpEmail;
}
