package com.disney.dmdc.qa.model;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class UserRequestSummaryDistributionGroups {

    UserRequestSummaryPersona persona;
    List<Object> actionCategories;
    BqDownloader bqDownloader;
    IsAutoDownloader isAutoDownloader;
    UserRequestSummary requestSummary;
    Boolean isBqDownloader;
    String snipe;
    List<Object> distributionUnits;
    Integer id;
    String name;
}
