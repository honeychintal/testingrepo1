package com.disney.dmdc.qa.reportportal;

import java.util.List;

import org.testng.IReporter;
import org.testng.ISuite;
import org.testng.xml.XmlSuite;

import com.disney.dtci.productivity.outrider.consumer.reportportal.ReportPortalConfigurationException;
import com.disney.dtci.productivity.outrider.consumer.reportportal.ReportPortalConsumer;
import com.disney.dtci.productivity.outrider.consumer.reportportal.ReportPortalConsumerConfiguration;
import com.disney.dtci.productivity.outrider.model.TestRun;
import com.disney.dtci.productivity.outrider.model.signature.DefaultCascadingNameStrategy;
import com.disney.dtci.productivity.outrider.model.signature.DefaultClassNameStrategy;
import com.disney.dtci.productivity.outrider.model.signature.SerializedAndHashedParameterStrategy;
import com.disney.dtci.productivity.outrider.provider.TestNGProvider;
import com.disney.dtci.productivity.outrider.provider.TestNGWithTestDocProvider;
import com.disney.qa.config.ConfigLoader;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.common.collect.ImmutableList;
import com.typesafe.config.ConfigBeanFactory;
import com.typesafe.config.ConfigException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ReportPortalListener implements IReporter {

    final String REPORT_PORTAL_CONFIG_KEY = "propertyCollections.environments." + ConfigLoader.TEST_ENVIRONMENT + ".reporting.reportportal";

    @Override
    public void generateReport(List<XmlSuite> xmlSuites, List<ISuite> suites, String outputDirectory) {

        log.info("Starting Report Portal Listener.");

        //Convert from TestNG format to Outrider via our chosen provider class
        TestNGProvider provider = new TestNGWithTestDocProvider();
        provider.setSignatureStrategy(
                ImmutableList.of(
                        new DefaultClassNameStrategy(),
                        new DefaultCascadingNameStrategy(),
                        new SerializedAndHashedParameterStrategy()
                )
        );

        TestRun testRun = provider.convertSuiteToOutriderRun(suites.get(0));
        testRun.getTestContext().setEnvironment(ConfigLoader.TEST_ENVIRONMENT);

        ReportPortalConsumerConfiguration reportPortalConfig;
        try {
            reportPortalConfig = ConfigBeanFactory.create(
                    ConfigLoader.getConfig().getConfig(REPORT_PORTAL_CONFIG_KEY),
                    ReportPortalConsumerConfiguration.class
            );

            log.info(String.format("ReportPortalConsumerConfiguration created from config key \"%s\".", REPORT_PORTAL_CONFIG_KEY));
        } catch (ConfigException e) {
            log.error(String.format("Failed to convert config key \"%s\" into a ReportPortalConsumerConfiguration.", REPORT_PORTAL_CONFIG_KEY), e);
            return;
        }

        ReportPortalConsumer reportPortalConsumer;
        try {
            reportPortalConsumer = new ReportPortalConsumer(reportPortalConfig);
        } catch (ReportPortalConfigurationException e) {
            log.error("Failed to create a ReportPortalConsumer.", e);
            return;
        }

        try {
            reportPortalConsumer.recordLaunch(testRun);

            log.info("Report Portal Listener finished.");
        } catch (JsonProcessingException e) {
            log.error("Failed during Report Portal upload.", e);
        }
    }
}
