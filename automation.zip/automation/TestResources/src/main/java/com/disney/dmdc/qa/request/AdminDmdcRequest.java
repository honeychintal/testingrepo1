package com.disney.dmdc.qa.request;

import com.disney.dmdc.qa.client.DmdcAdminClient;
import com.disney.dmdc.qa.constant.DmdcHeaders;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.qa.contract.ContractHeaders;
import com.disney.qa.contract.ContractJsonSchema;
import com.google.common.net.HttpHeaders;

public class AdminDmdcRequest extends BaseDmdcRequest<AdminDmdcRequest> {
	public AdminDmdcRequest() {
		super("admin");
	}

	public AdminDmdcRequest authenticationWithAntiforgery(TestUser user) {
		return this
				.authenticationDmdStatsOnly(user.getDmdstats())
				.antiForgeryCookies(user.getAntiforgeryCookiesAdmin());
	}

	public AdminDmdcRequest invalidDmdStatsAuthAndContracts(String dmdstats) {
		return this
				.authenticationDmdStatsOnly(dmdstats)
				.dmdstatsContractsAndNoAuth();
	}

	public AdminDmdcRequest dmdstatsContractsAndNoAuth() {
		return this
				.contract(DmdcAdminClient.UNAUTHORIZED_STATUS_CODE)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_NO_DMDSTATS)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON_ADMIN)
						.build()
				)
				.removeContract(ContractJsonSchema.class);
	}

	public AdminDmdcRequest forbiddenDmdStatsContract(String dmdstats) {

		return this
				.authenticationDmdStatsOnly(dmdstats)
				.contract(DmdcAdminClient.FORBIDDEN_STATUS_CODE)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_NO_DMDSTATS)
						.ignoredHeaders(DmdcHeaders.IGNORED_COMMON_ADMIN)
						.ignoredHeader(HttpHeaders.CACHE_CONTROL)
						.ignoredHeader(HttpHeaders.EXPIRES)
						.build()
				)
				.removeContract(ContractJsonSchema.class);
	}

}
