package com.disney.dmdc.qa.request;

import com.disney.dmdc.qa.constant.DmdcHeaders;
import com.disney.dmdc.qa.exceptions.UnexpectedCookieException;
import com.disney.qa.contract.parentinterface.BaseContract;
import com.disney.qa.request.http.MaraJadeHttpRequest;
import com.google.common.net.HttpHeaders;

import java.net.HttpCookie;
import java.util.List;

public class BaseDmdcRequest<T extends BaseDmdcRequest<?>> extends MaraJadeHttpRequest<T> {

	public BaseDmdcRequest(String knownService) {
		super(knownService);
	}

	public T dmdstats(String ffauthToken) {
		return this.cookie(DmdcHeaders.DMDSTATS_COOKIE_NAME, ffauthToken);
	}

	public T xsrf(String xsrf) {
		this.header(DmdcHeaders.X_XSRF_TOKEN, xsrf);
		return this.cookie(DmdcHeaders.XSRF_COOKIE_NAME, xsrf);
	}

	public T antiforgery(String antiforgeryValue) {
		return this.cookie(DmdcHeaders.ANTIFORGERY_COOKIE_NAME, antiforgeryValue);
	}

	public T antiForgeryCookies(List<HttpCookie> cookies) {

		for (HttpCookie cookie:cookies) {

			if(cookie.getName().equals(DmdcHeaders.XSRF_COOKIE_NAME)) {
				this.xsrf(cookie.getValue());
			}
			else if(cookie.getName().equals(DmdcHeaders.ANTIFORGERY_COOKIE_NAME)) {
				this.antiforgery(cookie.getValue());
			}
			else {
				throw new UnexpectedCookieException(
						String.format("Did not expect non-antiforgery cookie named \"%s\".", cookie.getName())
				);
			}
		}

		return((T) this);
	}

	public T cookie(String key, String value) {

		String replacementCookieString = null;
		String existingCookieString = this.getHeaders().get(HttpHeaders.COOKIE);

		String newKeyValuePairString = key + "=" + value;

		//Cookie header doesn't exist
		if (existingCookieString == null) {
			replacementCookieString = newKeyValuePairString;
		} else {
			String[] existingCookiePairs = existingCookieString.split("; ");
			String keyEquals = key + "=";

			for (int i = 0; i < existingCookiePairs.length; i++) {
				if (existingCookiePairs[i].startsWith(keyEquals)) {
					//Cookie already exists, so set it's value and rejoin
					existingCookiePairs[i] = newKeyValuePairString;
					replacementCookieString = String.join("; ", existingCookiePairs);
					return (this.header(HttpHeaders.COOKIE, replacementCookieString));
				}
			}

			//Cookies header exists, but not the current cookie
			replacementCookieString = existingCookieString + "; " + newKeyValuePairString;
		}

		return (this.header(HttpHeaders.COOKIE, replacementCookieString));
	}

	public T authenticationDmdStatsOnly(String dmdstats) {
		return this.dmdstats(dmdstats);
	}

	public T removeContract(Class<? extends BaseContract> classType) {

		contracts.getContracts().remove(classType);
		return((T) this);
	}
}
