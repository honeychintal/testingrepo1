package com.disney.dmdc.qa.request;

import com.disney.dmdc.qa.client.DifMarketingClient;
import com.disney.dmdc.qa.constant.DmdcHeaders;
import com.disney.dmdc.qa.constant.ResponseData;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.contract.ContractHeaders;
import com.disney.qa.contract.ContractJsonSchema;
import com.google.common.net.HttpHeaders;

public class MarketingDifRequest extends BaseDmdcRequest<MarketingDifRequest> {

    public MarketingDifRequest() {
        super("marketingDif");
    }

    public MarketingDifRequest invalidDmdStatsAuthAndContracts(String dmdstats) {
        return this
                .authenticationDmdStatsOnly(dmdstats)
                .dmdstatsContractsAndNoAuth();
    }

    public MarketingDifRequest dmdstatsContractsAndNoAuth(){
        return this
                .contract(DifMarketingClient.UNAUTHORIZED_STATUS_CODE)
                .contract(ContractHeaders.builder()
                        .expectedHeaders(DmdcHeaders.EXPECTED_NO_DMDSTATS)
                        .ignoredHeaders(DmdcHeaders.IGNORED_COMMON)
                        .ignoredHeader(HttpHeaders.CONTENT_LENGTH)
                        .build())
                .contract(ContractBody.builder()
                        .equalTo(ResponseData.INVALID_DMDSTATS_RESPONSE)
                        .build())
                .removeContract(ContractJsonSchema.class);
    }
}
