package com.disney.dmdc.qa.request;

import com.disney.dmdc.qa.client.DmdcMarketingClient;
import com.disney.dmdc.qa.constant.DmdcHeaders;
import com.disney.dmdc.qa.constant.ResponseData;
import com.disney.dmdc.qa.data.TestUser;
import com.disney.qa.contract.ContractBody;
import com.disney.qa.contract.ContractHeaders;
import com.disney.qa.contract.ContractJsonSchema;
import com.google.common.net.HttpHeaders;


public class MarketingDmdcRequest extends BaseDmdcRequest<MarketingDmdcRequest> {
	public MarketingDmdcRequest() {
		super("marketing");
	}

	public MarketingDmdcRequest authenticationWithAntiforgery(TestUser user) {
		return this
				.authenticationDmdStatsOnly(user.getDmdstats())
				.antiForgeryCookies(user.getAntiforgeryCookiesMarketing());
	}

	public MarketingDmdcRequest invalidDmdStatsAuthAndContracts(String dmdstats) {
		return this
				.authenticationDmdStatsOnly(dmdstats)
				.dmdstatsContractsAndNoAuth();
	}

	public MarketingDmdcRequest dmdstatsContractsAndNoAuth(){
		return this
				.contract(DmdcMarketingClient.UNAUTHORIZED_STATUS_CODE)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_NO_DMDSTATS)
						.ignoredHeaders(DmdcHeaders.IGNORED_ANTIFORGERY)
						.build())
				.contract(ContractBody.builder()
						.equalTo(ResponseData.INVALID_DMDSTATS_RESPONSE)
						.build())
				.removeContract(ContractJsonSchema.class);
	}

	//This method is for passing only Antiforgery cookie with out Xsrf header
	public MarketingDmdcRequest antiforgeryAuthAndNoXsrfContracts(TestUser user) {
		return this
				.authenticationDmdStatsOnly(user.getDmdstats())
				.antiforgery(user.getAntiforgeryCookieMarketing())
				.contractsForSingleAntiforgeryfCookie();
	}

	//This method is for passing only Xsrf header with out Antiforgery cookie
	public MarketingDmdcRequest xsrfAuthAndNoAntiforgeryContracts(TestUser user) {
		return this
				.authenticationDmdStatsOnly(user.getDmdstats())
				.xsrf(user.getXSRFCookieMarketing())
				.contractsForSingleAntiforgeryfCookie();
	}

	//This method is for updating header/body/status/schema contracts specifically for verifying the return when either
    //the xsrf or the antiforgery cookie is missing.
	private MarketingDmdcRequest contractsForSingleAntiforgeryfCookie(){
		return this
				.contract(DmdcMarketingClient.BAD_REQUEST_STATUS_CODE)
				.contract(ContractHeaders.builder()
						.expectedHeaders(DmdcHeaders.EXPECTED_NO_ANTIFORGERY_OR_XSRF)
						.ignoredHeaders(DmdcHeaders.IGNORED_ANTIFORGERY)
						.ignoredHeader(HttpHeaders.CONTENT_LENGTH)
						.build())
				.contract(ContractBody.builder()
						.equalTo(ResponseData.BAD_REQUEST_RESPONSE)
						.build())
				//For Cookie related scenarios we do not get any Json response, so removing JsonSchema Contract
				.removeContract(ContractJsonSchema.class);
	}
}