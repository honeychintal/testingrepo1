package com.disney.dmdc.qa.trs;

import com.disney.dtci.productivity.outrider.consumer.trs.TRSConsumer;
import com.disney.dtci.productivity.outrider.consumer.trs.TRSConsumerConfiguration;
import com.disney.dtci.productivity.outrider.consumer.trs.client.TRSClient;
import com.disney.dtci.productivity.outrider.consumer.trs.model.TRSTestResult;
import com.disney.dtci.productivity.outrider.model.TestRun;
import com.disney.dtci.productivity.outrider.model.signature.DefaultCascadingNameStrategy;
import com.disney.dtci.productivity.outrider.model.signature.SerializedAndHashedParameterStrategy;
import com.disney.dtci.productivity.outrider.provider.TestNGProvider;
import com.disney.dtci.productivity.outrider.provider.TestNGWithTestDocProvider;
import com.disney.qa.config.ConfigLoader;
import com.google.common.collect.ImmutableList;
import com.typesafe.config.ConfigBeanFactory;
import lombok.extern.slf4j.Slf4j;
import org.testng.IReporter;
import org.testng.ISuite;
import org.testng.xml.XmlSuite;
import java.util.List;

@Slf4j
public class OutriderListener implements IReporter {
    private static final List SIGNATURE_STRATEGY = ImmutableList.of(new DefaultCascadingNameStrategy(), new SerializedAndHashedParameterStrategy());
    final String TRS_CONFIG_KEY = "propertyCollections.environments." + ConfigLoader.TEST_ENVIRONMENT + ".reporting.trs";

    @Override
    public void generateReport(List<XmlSuite> xmlSuites, List<ISuite> suites, String outputDirectory){
        TestNGProvider provider = new TestNGWithTestDocProvider();
        provider.setSignatureStrategy(SIGNATURE_STRATEGY);

        TestRun testRun = provider.convertSuiteToOutriderRun(suites.get(0));
        testRun.getTestContext().setEnvironment(ConfigLoader.TEST_ENVIRONMENT);

        TRSConsumerConfiguration trsConfig = ConfigBeanFactory.create(ConfigLoader.getConfig().getConfig(TRS_CONFIG_KEY), TRSConsumerConfiguration.class);
        TRSConsumer trsConsumer = new TRSConsumer(trsConfig);
        List<TRSTestResult> trsTestResults = trsConsumer.convertResultsFromOutrider(testRun);
        TRSClient client = new TRSClient(trsConfig);
        client.recordTests(trsTestResults);
    }

}
