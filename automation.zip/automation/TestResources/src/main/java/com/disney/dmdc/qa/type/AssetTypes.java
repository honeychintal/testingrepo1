package com.disney.dmdc.qa.type;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum AssetTypes {

    LOGOS_ARTWORK(
            "Logos & Artwork",
            6
    ),

    GALLERY_PHOTOS(
            "Gallery Photos",
            5
    ),

    EPISODIC_PHOTOS(
            "Episodic Photos",
            1
    ),

    SPECIAL_SHOOT_PHOTOS(
            "Special Shoot Photos",
            34
    ),

    EVENT_PHOTOS(
            "Event Photos",
            4
    ),

    PRODUCTION_STILLS(
            "Production Stills",
            12
    ),

    INSIGHTS(
            "Insights",
            58
    ),

    HE_LOGOS_ARTWORK(
            "HE Logos & Artwork",
            60
    ),

    HE_PRODUCTION_STILLS(
            "HE Production Stills",
            61
    ),

    RATINGS(
            "Ratings",
            13
    ),

    STOCK_PHOTOS(
            "Stock Photos",
            39
    ),

    PUBLICITY(
            "Publicity",
            42
    ),

    TRAILERS(
            "Trailers",
            48
    ),

    PROMOS(
            "Promos",
            50
    ),

    TV_SPORTS(
            "TV Spots",
            53
    ),

    FEATURETTES(
            "Featurettes",
            47
    ),

    MOTION_GRAPHIC_PACKAGES(
            "Motion Graphic Packages",
            51
    ),

    INTERVIEW_SOUNDBITES(
            "Interview Soundbites",
            49
    ),

    TAGS(
            "Tags",
            52
    ),

    CLIPS(
            "Clips",
            46
    ),

    B_ROLL(
            "B-roll",
            54
    ),

    WEB_SOCIAL_CONTENT(
            "Web & Social Content",
            10
    ),

    BQ_FULL_PROGRAM(
            "BQ - Full Program",
            8
    ),

    SUBTITLES(
            "Subtitles",
            36
    ),

    CLOSED_CAPTIONS(
            "Closed - Captions",
            35
    ),

    DUB_CARDS(
            "Dub Cards",
            43
    ),

    HRD_METADATA(
            "HDR Metadata",
            59
    ),

    LOCALIZATION_REPORTS(
            "Localization Reports",
            44
    ),

    MUSIC_CUES(
            "Music Cues",
            11
    ),

    SCRIPTS(
            "Scripts",
            14
    ),

    SCREENERS_FULL_PROGRAM(
            "Screeners - Full Program",
            7
    )
    ;

    private String assetType;
    private int assetTypeId;

}
