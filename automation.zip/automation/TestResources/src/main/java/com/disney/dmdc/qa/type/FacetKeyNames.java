package com.disney.dmdc.qa.type;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum FacetKeyNames {
    LANGUAGE("Language"),
    TERRITORY("Territory")
    ;

    private String id;
}
