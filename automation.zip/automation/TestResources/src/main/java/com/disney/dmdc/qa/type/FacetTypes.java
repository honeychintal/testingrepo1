package com.disney.dmdc.qa.type;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum FacetTypes {
    VALUE(0),
    RANGE(1)
    ;

    private int value;
}
