package com.disney.dmdc.qa.type;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum FieldType {
    WPRIDS("wprids", "wprids")
    ;

    private String id;
    private String name;
}
