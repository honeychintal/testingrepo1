package com.disney.dmdc.qa.type;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.HashMap;
import java.util.Map;

@AllArgsConstructor
@Getter
public enum Language {

    ARABIC("Arabic"),
    ARGENTINIAN_SPANISH("Argentinian Spanish"),
    BRAZILIAN_PORTUGUESE("Brazilian Portuguese"),
    BULGARIAN("Bulgarian"),
    CASTILIAN_SPANISH("Castilian Spanish"),
    CZECH("Czech"),
    DANISH("Danish"),
    DUTCH("Dutch"),
    ENGLISH("English"),
    ESTONIAN("Estonian"),
    FINNISH("Finnish"),
    FRENCH("French"),
    GERMAN("German"),
    GREEK_MODERN("Greek, Modern"),
    HEBREW("Hebrew"),
    HUNGARIAN("Hungarian"),
    ITALIAN("Italian"),
    JAPANESE("Japanese"),
    KOREAN("Korean"),
    LATIN_SPANISH("Latin Spanish"),
    LATVIAN("Latvian"),
    LITHUANIAN("Lithuanian"),
    MANDARIN_PRC("Mandarin, PRC"),
    MANDARIN_TAIWAN("Mandarin, Taiwan"),
    NORWEGIAN("Norwegian"),
    POLISH("Polish"),
    PORTUGUESE("Portuguese"),
    QUEBECOIS_CANADIAN_FRENCH("Quebecois (Canadian French)"),
    ROMANIAN_MOLDAVIAN_MOLDOVAN("Romanian, Moldavian, Moldovan"),
    RUSSIAN("Russian"),
    SERBIAN("Serbian"),
    SLOVAK("Slovak"),
    SWEDISH("Swedish"),
    THAI_FKA_SIAMESE("Thai (FKA: Siamese)"),
    TURKISH("Turkish"),
    UKRAINIAN("Ukrainian")
    ;

    public static Map<String, Language> valuesByName = new HashMap<String, Language>();

    private String Name;

    static
    {
        for(Language language:values()) {

            valuesByName.put(language.Name, language);
        }
    }

    static public Language valueByName(String name) {
        return valuesByName.get(name);
    }
}
