package com.disney.dmdc.qa.type;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum Locals {

    ENG_CANADA("English/Canada", 1),
    ENG_USA("English/USA", 3),
    ENG_AUSTRALIA("English/Australia", 8);

    private String locals;
    private int id;

}
