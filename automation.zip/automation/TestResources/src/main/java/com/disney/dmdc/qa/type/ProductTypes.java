package com.disney.dmdc.qa.type;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum  ProductTypes {

    EPISODE("episode", 4),
    FEATURE("feature", 5),
    SEASON("season", 12),
    SERIES("series", 13),
    SPECIAL("special", 15);

    private String productType;
    private Integer productId;
}
