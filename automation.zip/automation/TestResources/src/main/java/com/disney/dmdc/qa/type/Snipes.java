package com.disney.dmdc.qa.type;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum Snipes {

    RELATED_ASSETS(
            "related-assets",
            "Related Assets"
    )
    ;

    private String name;
    private String text;
}
