package com.disney.dmdc.qa.type;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.HashMap;
import java.util.Map;

@AllArgsConstructor
@Getter
public enum Territory {

    ARGENTINA("Argentina", null),
    AUSTRALIA("Australia", null),
    AUSTRIA("Austria", null),
    BELGIUM("Belgium", null),
    BOLIVIA("Bolivia", null),
    BRAZIL("Brazil", null),
    BULGARIA("Bulgaria", null),
    CANADA("Canada", 1),
    CHILE("Chile", null),
    CHINA("China", null),
    COLOMBIA("Colombia", null),
    CZECH_REPUBLIC("Czech Republic", null),
    DENMARK("Denmark", null),
    ECUADOR("Ecuador", null),
    EGYPT("Egypt", null),
    ESTONIA("Estonia", null),
    FINLAND("Finland", null),
    FRANCE("France", null),
    GERMANY("Germany", null),
    GREECE("Greece", null),
    HUNGARY("Hungary", null),
    INDIA("India", null),
    INDONESIA("Indonesia", null),
    ISRAEL("Israel", null),
    ITALY("Italy", null),
    JAPAN("Japan", null),
    KOREA_SOUTH("Korea, South", null),
    LATVIA("Latvia", null),
    LITHUANIA("Lithuania", null),
    MEXICO("Mexico", null),
    NETHERLANDS("Netherlands", null),
    NORWAY("Norway", null),
    PANAMA("Panama", null),
    PERU("Peru", null),
    POLAND("Poland", null),
    PORTUGAL("Portugal", null),
    ROMANIA("Romania", null),
    RUSSIAN_FEDERATION("Russian Federation", null),
    SERBIA("Serbia", null),
    SLOVAKIA("Slovakia", null),
    SPAIN("Spain", null),
    SWEDEN("Sweden", null),
    TAIWAN("Taiwan", null),
    THAILAND("Thailand", null),
    TURKEY("Turkey", null),
    UKRAINE("Ukraine", null),
    UNITED_KINGDOM_OF_GREAT_BRITAIN_AND_NORTHERN_IRELAND("United Kingdom Of Great Britain And Northern Ireland", null),
    VENEZUELA("Venezuela", null),
    USA("USA", 2),
    AFGHANISTAN("Afghanistan", 3),
    ALBANIA("Albania", 4),
    ANGOLA("Angola", 5)
    ;

    public static Map<String, Territory> valuesByName = new HashMap<String, Territory>();

    private String Name;
    private Integer id;

    static
    {
        for(Territory territory:values()) {

            valuesByName.put(territory.Name, territory);
        }
    }

    static public Territory valueByName(String name) {
        return valuesByName.get(name);
    }
}
