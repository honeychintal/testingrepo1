package com.disney.dmdc.qa.util;

import com.disney.dmdc.qa.client.DmdcAdminClient;
import com.disney.dmdc.qa.client.DmdcMarketingClient;
import com.disney.dmdc.qa.constant.DmdcHeaders;
import com.disney.dmdc.qa.request.AdminDmdcRequest;
import com.disney.dmdc.qa.request.MarketingDmdcRequest;
import com.disney.qa.response.http.MaraJadeHttpResponse;
import com.google.common.collect.ImmutableList;
import lombok.experimental.UtilityClass;
import org.testng.Assert;

import java.net.HttpCookie;
import java.util.List;
import java.util.Map;

@UtilityClass
public class AntiforgeryUtils {

    public static List<HttpCookie> getAntiforgeryCookiesAdmin(String dmdstats) {
        MaraJadeHttpResponse<AdminDmdcRequest> response = DmdcAdminClient.getTopLevelHtml()
                .authenticationDmdStatsOnly(dmdstats)
                .cookie(DmdcHeaders.TACA_COOKIE_NAME, "true")
                .execute();

        return(extractAntiforgeryCookies(response));
    }

    public static List<HttpCookie> getAntiforgeryCookiesMarketing(String dmdstats) {
        MaraJadeHttpResponse<MarketingDmdcRequest> response = DmdcMarketingClient.getTopLevelHtml()
                .authenticationDmdStatsOnly(dmdstats)
                .cookie(DmdcHeaders.TACA_COOKIE_NAME, "true")
                .execute();

        return(extractAntiforgeryCookies(response));
    }

    private List<HttpCookie> extractAntiforgeryCookies(MaraJadeHttpResponse<?> response) {

        Map<String, List<HttpCookie>> allCookies = response.getCookies();

        HttpCookie xsrfCookie = getNonExpiredCookie(allCookies.get(DmdcHeaders.XSRF_COOKIE_NAME));
        HttpCookie antiforgeryCookie = getNonExpiredCookie(allCookies.get(DmdcHeaders.ANTIFORGERY_COOKIE_NAME));
        return(ImmutableList.of(xsrfCookie, antiforgeryCookie));
    }

    //Removes expired cookies from the list, and returns the single non-expired cookie.  Asserts that there
    //is only 1 cookie left.
    private HttpCookie getNonExpiredCookie(List<HttpCookie> cookies) {
        cookies.removeIf(HttpCookie::hasExpired);
        Assert.assertEquals(cookies.size(), 1,
                String.format(
                        "Expected exactly 1 non-expired cookie. Actual: %s",
                        cookies.toString()
                )
        );
        return(cookies.get(0));
    }
}
