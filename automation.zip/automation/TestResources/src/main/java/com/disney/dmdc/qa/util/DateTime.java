package com.disney.dmdc.qa.util;

import lombok.experimental.UtilityClass;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@UtilityClass
public class DateTime {

    public static String convertDateTimeFormat (String inputFormat, String outputFormat, String value) throws ParseException {

        SimpleDateFormat inFormat = new SimpleDateFormat(inputFormat);
        SimpleDateFormat outFormat = new SimpleDateFormat(outputFormat);
        Date date = inFormat.parse(value);
        return outFormat.format(date);
    }

    public static String convertDateTimeDbToJson (String dateTime) throws ParseException {

        return convertDateTimeFormat("yyyy-MM-dd HH:mm:ss.SSSSSSS +HH:mm","yyyy-MM-dd'T'HH:mm:ss+HH:mm",dateTime);
    }

    public static String convertDateToDateTime(String dateTime) throws ParseException {

        return convertDateTimeFormat("yyyy-MM-dd","yyyy-MM-dd'T'HH:mm:ss",dateTime);
    }
}