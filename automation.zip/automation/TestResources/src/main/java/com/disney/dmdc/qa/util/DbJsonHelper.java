package com.disney.dmdc.qa.util;

import lombok.experimental.UtilityClass;

@UtilityClass
public class DbJsonHelper {

    public static String stringReplacement(String value,String target,String replacement){

        return value == null ? null : value.replace(target,replacement);
    }

    public static String replaceCarriageReturn(String value){

        return stringReplacement(value,"\r","\n");
    }
}
