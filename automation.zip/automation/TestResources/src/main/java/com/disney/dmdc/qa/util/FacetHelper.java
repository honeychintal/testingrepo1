package com.disney.dmdc.qa.util;

import com.disney.dmdc.qa.model.FacetKey;
import com.disney.dmdc.qa.model.FacetQuery;
import com.disney.dmdc.qa.model.FacetValue;
import com.google.common.collect.ImmutableList;
import lombok.experimental.UtilityClass;

@UtilityClass
public class FacetHelper {

	//Returns a key Facet with nested value Facet.  This is the form expected in the output from localnames.
	//Input is of the form of a Facet in a request.
	public static FacetKey responseFacetFromRequestFacet(FacetQuery requestFacet)
	{
		return FacetKey.builder()
				.facets(
						ImmutableList.of(
								FacetValue.builder()
										.totalCount(requestFacet.getTotalCount())
										.type(requestFacet.getType())
										.id(requestFacet.getId())
										.name(requestFacet.getValue())
										.value(requestFacet.getValue())
										.selected(requestFacet.getSelected())
										.build()
						)
				)
				.type(requestFacet.getType())
				.id(requestFacet.getId())
				.name(requestFacet.getId())
				.selected(false)
				.build();
	}
}
