package com.disney.dmdc.qa.util;

import com.disney.qa.config.ConfigLoader;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigException;

public class TestServicesConfig {

    private static final String SERVICE_CONFIG_KEY = "services";
    private static final String ENVIRONMENTS_CONFIG_KEY = "environments";
    private static final String HOST_CONFIG_KEY = "host";
    private static final String COMPARE_RESPONSES_TO_BACKEND_DATABASE_CONFIG_KEY = "compareResponsesToBackendDatabase";
    private static final String COMPARE_RESPONSES_TO_BACKEND_DATABASE_CONFIG_PATH = "propertyCollections.environments." + ConfigLoader.TEST_ENVIRONMENT;

    public static String getServiceUrls(String serviceName){

        Config serviceEnvironmentConfig = null;

        try {
            if (serviceEnvironmentConfig == null) {
                serviceEnvironmentConfig = ConfigLoader.getServiceEnvironmentConfiguration(serviceName);
            }

            String serviceUrl = serviceEnvironmentConfig.getString(HOST_CONFIG_KEY);
            return serviceUrl;

        }catch (Exception e) {
            throw new ConfigException.Generic(
                    String.format(
                            "Failed to load test urls \"%s\" from config path: \"%s.%s.%s.%s\"",
                            HOST_CONFIG_KEY,
                            SERVICE_CONFIG_KEY,
                            serviceName,
                            ENVIRONMENTS_CONFIG_KEY,
                            ConfigLoader.TEST_ENVIRONMENT
                    ),
                    e);
        }
    }

    public static boolean shouldCompareResponseToBackendDatabase () {

        Config environmentConfig = null;

        try {

            environmentConfig = ConfigLoader.getConfig().getConfig(COMPARE_RESPONSES_TO_BACKEND_DATABASE_CONFIG_PATH);

            return environmentConfig.getBoolean(COMPARE_RESPONSES_TO_BACKEND_DATABASE_CONFIG_KEY);

        }catch (Exception e) {
            throw new ConfigException.Generic(
                    String.format(
                            "Failed to get \"%s\" value from config path: \"%s\"",
                            COMPARE_RESPONSES_TO_BACKEND_DATABASE_CONFIG_KEY,
                            COMPARE_RESPONSES_TO_BACKEND_DATABASE_CONFIG_PATH
                    ),
                    e);
        }

    }
}
