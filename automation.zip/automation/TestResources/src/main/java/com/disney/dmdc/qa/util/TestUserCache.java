package com.disney.dmdc.qa.util;

import com.disney.dmdc.qa.data.TestUser;
import com.disney.qa.config.ConfigLoader;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigException;

import java.util.HashMap;
import java.util.Map;

public class TestUserCache {

    public static final String ADMIN_USER_KEY = "admin";
    public static final String ADMIN_DMDC_API_AUTOMATION_USER_KEY = "adminDmdcApiAutomation";
    public static final String MARKETING_TVD_HE_USER_KEY = "marketingTvdHeUser";
    public static final String MARKETING_DIF_USER_KEY = "marketingDifUser";
    public static final String MARKETING_TVD_USER_KEY = "marketingTvdUser";
    public static final String MARKETING_HE_USER_KEY = "marketingHeUser";

    private static final String USERS_CONFIG_KEY = "users";
    private static final String ENVIRONMENTS_CONFIG_KEY = "environments";
    private static final String USERNAME_CONFIG_KEY = "username";
    private static final String PASSWORD_CONFIG_KEY = "password";
    private static final String DMDSTATS_CONFIG_KEY = "dmdstats";
    private static final String USERS_SOURCE_PATH = "propertyCollections.environments." + ConfigLoader.TEST_ENVIRONMENT + ".users";

    //Caching
    private Config userEnvironmentConfig = null;
    private Map<String, TestUser> knownUsers = new HashMap<String, TestUser>();

    public TestUser getTestUserFromConfig(String userConfigKey) {

        return knownUsers.computeIfAbsent(
                userConfigKey,
                this::getTestUserFromConfigNoUserCache
        );
    }

    private TestUser getTestUserFromConfigNoUserCache(String userConfigKey) {

        try {
            if (userEnvironmentConfig == null) {
                userEnvironmentConfig = ConfigLoader
                        .getConfig()
                        .getConfig(USERS_SOURCE_PATH);
            }

            Config userConfig = userEnvironmentConfig.getConfig(userConfigKey);

            String username = userConfig.getString(USERNAME_CONFIG_KEY);
            String password = userConfig.getString(PASSWORD_CONFIG_KEY);
            String dmdstats = userConfig.getString(DMDSTATS_CONFIG_KEY);

            return new TestUser(username, password, dmdstats);

        } catch (Exception e) {
            throw new ConfigException.Generic(
                    String.format(
                            "Failed to load test user \"%s\" and \"%s\" from config path: \"%s.%s\"",
                            USERNAME_CONFIG_KEY,
                            PASSWORD_CONFIG_KEY,
                            USERS_SOURCE_PATH,
                            userConfigKey
                    ),
                    e);
        }
    }
}