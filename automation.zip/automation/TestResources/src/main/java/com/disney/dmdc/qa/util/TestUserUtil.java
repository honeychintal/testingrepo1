package com.disney.dmdc.qa.util;

import com.disney.dmdc.qa.constant.TestAccounts;
import com.disney.dmdc.qa.model.UserDetails;
import lombok.experimental.UtilityClass;

@UtilityClass
public class TestUserUtil {

    public UserDetails getTestAccountDmdcApiAutomationAdminUser() {
        return TestAccounts.DMDC_API_AUTOMATION;
    }

    public UserDetails getTestAccountTvdHeMarketingUser() {
        return TestAccounts.TEST_TVD_HE_USER;
    }

    public UserDetails getTestAccountTvdMarketingUser() {

        return TestAccounts.TEST_TVD_USER;
    }

    public UserDetails getTestAccountHeMarketingUser() {
        return TestAccounts.TEST_HE_USER;
    }

}
