package com.disney.dmdc.qa.util.data;

import com.disney.qa.config.ConfigLoader;
import com.typesafe.config.Config;
import lombok.experimental.UtilityClass;

@UtilityClass
public class AssetsData {
    private static final String ASSET_IDS_SOURCE = "propertyCollections.environments." + ConfigLoader.TEST_ENVIRONMENT + ".testData.assetIds";
    private static final Config ASSET_IDS = ConfigLoader.getConfig().getConfig(ASSET_IDS_SOURCE);
    private static final String ASSET_ID = "assetId";

    public static int getAssetId() {
        return ASSET_IDS.getInt(ASSET_ID);
    }
}