package com.disney.dmdc.qa.util.data;

import com.disney.qa.config.ConfigLoader;
import com.typesafe.config.Config;
import lombok.experimental.UtilityClass;

@UtilityClass
public class CategoryData {

    private final String SOURCE_KEY = "propertyCollections.environments." + ConfigLoader.TEST_ENVIRONMENT + ".testData.categoryIds";
    private final String CATEGORY_ID = "categoryId";
    private final Config CATEGORY_IDS = ConfigLoader.getConfig().getConfig(SOURCE_KEY);

    public String getCategoryId() {
        return CATEGORY_IDS.getString(CATEGORY_ID);
    }
}
