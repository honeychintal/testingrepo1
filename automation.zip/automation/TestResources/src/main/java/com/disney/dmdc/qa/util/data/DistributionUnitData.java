package com.disney.dmdc.qa.util.data;

import com.disney.dmdc.qa.constant.DistributionUnitIds;
import lombok.experimental.UtilityClass;

@UtilityClass
public class DistributionUnitData {

    public static int getTvd() {
        return DistributionUnitIds.TELEVISION_DISTRIBUTION;
    }

    public static int getHe() {
        return DistributionUnitIds.HOME_ENTERTAINMENT;
    }

    public static int getDif() {
        return DistributionUnitIds.DISNEY_INFLIGHT;
    }
}
