package com.disney.dmdc.qa.util.data;

import com.disney.qa.config.ConfigLoader;
import com.typesafe.config.Config;
import lombok.experimental.UtilityClass;

@UtilityClass
public class TitleNameData {
    private final String SOURCE_KEY = "propertyCollections.environments." + ConfigLoader.TEST_ENVIRONMENT + ".testData.titleNames";
    private final String TITLE_NAME = "titleName";
    private final String INVALID_TITLE_NAME = "invalidTitleName";
    private final Config TITLE_NAMES = ConfigLoader.getConfig().getConfig(SOURCE_KEY);

    public static String getTitleName() { return TITLE_NAMES.getString(TITLE_NAME); }

    public static String getInvalidTitleName() { return TITLE_NAMES.getString(INVALID_TITLE_NAME); }
}