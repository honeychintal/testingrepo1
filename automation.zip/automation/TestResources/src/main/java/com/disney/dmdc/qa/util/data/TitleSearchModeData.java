package com.disney.dmdc.qa.util.data;

import lombok.experimental.UtilityClass;

@UtilityClass
public class TitleSearchModeData {

    private static final String PRODUCT_PAGE = "Product Page";
    private static final String ASSET_SEARCH = "Asset Search";

    public static String getProductPage() {
        return PRODUCT_PAGE;
    }

    public static String getAssetSearch() {
        return ASSET_SEARCH;
    }
}
