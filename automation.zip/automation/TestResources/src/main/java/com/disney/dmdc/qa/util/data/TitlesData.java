package com.disney.dmdc.qa.util.data;

import com.disney.qa.config.ConfigLoader;
import com.typesafe.config.Config;
import lombok.experimental.UtilityClass;

@UtilityClass
public class TitlesData {
    private final String SOURCE_KEY = "propertyCollections.environments." + ConfigLoader.TEST_ENVIRONMENT + ".testData.titleIds";
    private final String TVD_AND_HE = "tvdAndHe";
    private final String TVD = "tvd";
    private final String HE = "he";
    private final String INACTIVE = "inactive";
    private final String SEASON = "season";
    private final String SEASON_FEW_TABS = "seasonWithFewTabs";
    private final String TVD_HE_AWARDS = "tvdAndHeAwards";
    private final String DIF_TVD_AND_HE = "difTvdAndHe";
    private final String ADDITIONALCAST_HE = "additionalCastHE";
    private final String ADDITIONALCAST_TVD = "additionalCastTVD";

    private final Config GUIDS = ConfigLoader.getConfig().getConfig(SOURCE_KEY);

    public String getTvdHeGuid() {
        return GUIDS.getString(TVD_AND_HE);
    }

    public String getTvdTitleGuid() {
        return GUIDS.getString(TVD);
    }

    public String getHeTitleGuid() {
        return GUIDS.getString(HE);
    }

    public String getInactiveTitleGuid() {
        return GUIDS.getString(INACTIVE);
    }

    public String getSeasonTitleGuid(){ return GUIDS.getString(SEASON); }

    public String getFewTabsTitleGuid() { return GUIDS.getString(SEASON_FEW_TABS); }

    public String getTvdHeAwardGuid() {
        return GUIDS.getString(TVD_HE_AWARDS);
    }

    public String getDifTvdHeTitleGuid() { return GUIDS.getString(DIF_TVD_AND_HE); }

    public String getAdditionalcastHe() { return GUIDS.getString(ADDITIONALCAST_HE); }

    public String getAdditionalcastTvd() { return  GUIDS.getString(ADDITIONALCAST_TVD); }
}
