package com.disney.dmdc.qa.util.data;

import com.disney.qa.config.ConfigLoader;
import com.typesafe.config.Config;
import lombok.experimental.UtilityClass;

@UtilityClass
public class UsersData {
    private static final String USER_IDS_SOURCE = "propertyCollections.environments." + ConfigLoader.TEST_ENVIRONMENT + ".testData.userIds";
    private static final Config USER_IDS = ConfigLoader.getConfig().getConfig(USER_IDS_SOURCE);
    private static final String TVD_HE = "tvdAndHe";
    private static final String TVD = "tvd";
    private static final String HE = "he";
    private static final String ADMIN = "admin";
    private static final String DIF = "dif";
    private static final String IDP_USERID = "idpUserId";

    public static int getTvdHeId() {
        return USER_IDS.getInt(TVD_HE);
    }

    public static int getTvdId() {
        return USER_IDS.getInt(TVD);
    }

    public static  int getHeId() {
        return USER_IDS.getInt(HE);
    }

    public static  int getAdminId() {
        return USER_IDS.getInt(ADMIN);
    }

    public static  int getDifId() {
        return USER_IDS.getInt(DIF);
    }

    public static  String getIdpUserId() {
        return USER_IDS.getString(IDP_USERID);
    }
}
