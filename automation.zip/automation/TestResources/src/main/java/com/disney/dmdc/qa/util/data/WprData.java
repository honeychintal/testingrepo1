package com.disney.dmdc.qa.util.data;

import com.disney.qa.config.ConfigLoader;
import com.typesafe.config.Config;
import lombok.experimental.UtilityClass;

@UtilityClass
public class WprData {
    private final String SOURCE_KEY = "propertyCollections.environments." + ConfigLoader.TEST_ENVIRONMENT + ".testData.wprIds";
    private final String WPR_ID = "wprId";
    private final String INVALID_WPR_ID = "invalidWprId";
    private final Config WPR_IDS = ConfigLoader.getConfig().getConfig(SOURCE_KEY);

    public static String getWprID() { return WPR_IDS.getString(WPR_ID); }

    public static String getInvalidWprID() { return WPR_IDS.getString(INVALID_WPR_ID); }
}