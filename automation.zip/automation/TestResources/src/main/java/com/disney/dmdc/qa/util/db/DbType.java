package com.disney.dmdc.qa.util.db;

public enum DbType {
    AZURE
}
