package com.disney.dmdc.qa.util.db;

import com.amazonaws.util.json.Jackson;
import com.disney.dmdc.qa.constant.StoredProcs;
import com.disney.dmdc.qa.entities.AdditionalCrewAndCast;
import com.disney.dmdc.qa.entities.AdditionalData;
import com.disney.dmdc.qa.entities.ApplicationTitle;
import com.disney.dmdc.qa.entities.ApplicationTitleCategory;
import com.disney.dmdc.qa.entities.AssetGroup;
import com.disney.dmdc.qa.entities.AudioChannel;
import com.disney.dmdc.qa.entities.Award;
import com.disney.dmdc.qa.entities.Categories;
import com.disney.dmdc.qa.entities.CategoriesSortOptions;
import com.disney.dmdc.qa.entities.Category;
import com.disney.dmdc.qa.entities.Comment;
import com.disney.dmdc.qa.entities.CreditType;
import com.disney.dmdc.qa.entities.Description;
import com.disney.dmdc.qa.entities.Header;
import com.disney.dmdc.qa.entities.HomepageTitleSearch;
import com.disney.dmdc.qa.entities.Item;
import com.disney.dmdc.qa.entities.License;
import com.disney.dmdc.qa.entities.Locale;
import com.disney.dmdc.qa.entities.ProductType;
import com.disney.dmdc.qa.entities.QuickView;
import com.disney.dmdc.qa.entities.Quotes;
import com.disney.dmdc.qa.entities.ReleaseDate;
import com.disney.dmdc.qa.entities.Rights;
import com.disney.dmdc.qa.entities.RunTime;
import com.disney.dmdc.qa.entities.SearchTab;
import com.disney.dmdc.qa.entities.Status;
import com.disney.dmdc.qa.entities.Synopsis;
import com.disney.dmdc.qa.entities.TabAssets;
import com.disney.dmdc.qa.entities.TabNames;
import com.disney.dmdc.qa.entities.Talent;
import com.disney.dmdc.qa.entities.Title;
import com.disney.dmdc.qa.entities.TitleHierarchy;
import com.disney.dmdc.qa.entities.TitleSuggestItem;
import com.disney.dmdc.qa.entities.TitleTabs;
import com.disney.qa.SqlDbMgr;
import com.fasterxml.jackson.core.type.TypeReference;
import lombok.experimental.UtilityClass;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

@UtilityClass
public class DmdCentralDbUtils {
    private static final String SELECT_APPLICATION_TITLE = "select top 20 * from [Titles].[ApplicationTitle] where ApplicationTitleGuid=?";
    private static final String SELECT_HOMEPAGE_TITLE_SEARCH = "select top 20 * from [Titles].[HomePage_TitleSearch] where ApplicationTitleId=?";
    private static final String SELECT_CATEGORY_APPLICATION_TITLE = "select top 20 * from [Titles].[ApplicationTitleCategory_ApplicationTitle] where ApplicationTitleId=?";
    private static final String SELECT_STATUS = "select top 20 * from [Titles].[Status] where statusid=?";
    private static final String SELECT_PRODUCT_TYPE = "select top 20 * from [Titles].[ProductType] where ProductTypeId=?";
    private static final String SELECT_CREDIT_TYPE_ID = "select top 20 * from [Titles].[CreditType] where CreditType =?";

    private static final String DMDCENTRAL_CONFIG_KEY = "dmdcentral";
    private static final SqlDbMgr db;

    static {
        db = SqlDbMgrFactory.getMgr(DMDCENTRAL_CONFIG_KEY);
    }

    public static ApplicationTitle selectApplicationTitle(String appTitleGuid) throws SQLException {
        return db.executeToObject(SELECT_APPLICATION_TITLE, ApplicationTitle.class, appTitleGuid);
    }

    public static HomepageTitleSearch selectHomepageTitleSearch(int appTitleId) throws SQLException {
        return db.executeToObject(SELECT_HOMEPAGE_TITLE_SEARCH, HomepageTitleSearch.class, appTitleId);
    }

    public static List<ApplicationTitleCategory> selectApplicationTitleCategory(int appTitleId) throws SQLException {
        return db.executeToList(SELECT_CATEGORY_APPLICATION_TITLE, ApplicationTitleCategory.class, appTitleId);
    }

    public static Status selectStatus(int statusId) throws SQLException {
        return db.executeToObject(SELECT_STATUS, Status.class, statusId);
    }

    public static ProductType selectProductType(int ProductTypeId) throws SQLException {
        return db.executeToObject(SELECT_PRODUCT_TYPE, ProductType.class, ProductTypeId);
    }

    public static CreditType selectCreditTypeId(String creditType) throws SQLException {
        return db.executeToObject(SELECT_CREDIT_TYPE_ID, CreditType.class, creditType);
    }

    public static List<Locale> callTitleLocalToList(Integer appId, Integer userId, Integer distId, String appTitleGuid) throws SQLException {
        return db.executeSpToList(StoredProcs.TITLE_LOCAL, Locale.class, appId, userId, distId, appTitleGuid);
    }

    public static Header callTitleHeader(Integer appId, Integer userId, Integer distId, String appTitleGuid, Integer localeId) throws SQLException {
        return db.executeSpToObject(StoredProcs.TITLE_HEADER, Header.class, appId, userId, distId, appTitleGuid, localeId);
    }

    public static Synopsis callTitleSynopsis(String appTitleGuid, Integer localeId) throws SQLException {
        return db.executeSpToObject(StoredProcs.TITLE_SYNOPSIS, Synopsis.class, appTitleGuid, localeId);
    }

    public static QuickView callTitleQuickViewGetInfo(Integer appId, Integer userId, String appTitleGuid) throws SQLException {
        List<List<Map<String, Object>>> lists = db.executeMultiTableSp(StoredProcs.TITLE_QUICKVIEW, appId, userId, appTitleGuid);
        if (lists.size() != 6)
            throw new SQLException("The Stored Proc execution didn't returned the expected number of tables.");
        List<Title> titles = Jackson.getObjectMapper().convertValue(lists.get(0), new TypeReference<List<Title>>() {
        });
        List<Talent> talents = Jackson.getObjectMapper().convertValue(lists.get(1), new TypeReference<List<Talent>>() {
        });
        List<ReleaseDate> releaseDates = Jackson.getObjectMapper().convertValue(lists.get(2), new TypeReference<List<ReleaseDate>>() {
        });
        List<RunTime> runTimes = Jackson.getObjectMapper().convertValue(lists.get(3), new TypeReference<List<RunTime>>() {
        });
        List<Description> descriptions = Jackson.getObjectMapper().convertValue(lists.get(4), new TypeReference<List<Description>>() {
        });
        List<Comment> comments = Jackson.getObjectMapper().convertValue(lists.get(5), new TypeReference<List<Comment>>() {
        });
        return QuickView.builder()
                .titles(titles)
                .talents(talents)
                .releaseDates(releaseDates)
                .runTimes(runTimes)
                .descriptions(descriptions)
                .comments(comments)
                .build();
    }

    public static void callTitleAssetDetailGetInfo(Integer appId, Integer userId, Integer appAssetId) throws SQLException {
        // Bug ticket: PPBPE-2652 - Fixed. This method can now be worked on as part of DB Validation: PPBPE-2602
        List<List<Map<String, Object>>> lists = db.executeMultiTableSp(StoredProcs.ASSET_DETAIL, appId, userId, appAssetId);

        if (lists.size() != 2)
            throw new SQLException("The Stored Proc execution didn't returned the expected number of tables.");

    }

    public static List<AudioChannel> callAssetAudioChannelToList(Integer assetId) throws SQLException {
        return db.executeSpToList(StoredProcs.ASSET_AUDIO_CHANNEL, AudioChannel.class, assetId);
    }

    public static Categories callCategoriesGetCategoryList(Integer appId, Integer userId, String queryType, String categoryId) throws SQLException {

        List<List<Map<String, Object>>> lists = db.executeMultiTableSp(StoredProcs.CATEGORY, appId, userId, queryType, categoryId);
        if (lists.size() != 2)
            throw new SQLException("The Stored Proc execution didn't returned the expected number of tables.");

        List<Category> category = Jackson.getObjectMapper().convertValue(lists.get(0), new TypeReference<List<Category>>() {
        });
        List<CategoriesSortOptions> categorySortOptions = Jackson.getObjectMapper().convertValue(lists.get(1), new TypeReference<List<CategoriesSortOptions>>() {
        });

        return Categories.builder()
                .categories(category)
                .sortOptions(categorySortOptions)
                .build();
    }

    public static List<Talent> callTitleTalentsToList(String appTitleGuid, int localId) throws SQLException {
        return db.executeSpToList(StoredProcs.TITLE_TALENT, Talent.class, appTitleGuid, localId);
    }

    public static List<TitleHierarchy> callTitleHierarchyToList(Integer appId, Integer userId, Integer distId, String appTitleGuid) throws SQLException {
        return db.executeSpToList(StoredProcs.TITLE_HIERARCHY, TitleHierarchy.class, appId, userId, distId, appTitleGuid);
    }

    public static List<License> callTitleLicenseToList(Integer appId, Integer userId, String appTitleGuid) throws SQLException {
        return db.executeSpToList(StoredProcs.TITLE_LICENSE, License.class, appId, userId, appTitleGuid);
    }

    public static TitleTabs callTitleIdTabs(Integer appId, Integer userId, Integer distId, String appTitleGuid, String searchMode) throws SQLException {

        List<List<Map<String, Object>>> lists = db.executeMultiTableSp(StoredProcs.TITLE_TABS, appId, userId, distId, appTitleGuid, searchMode);
        if (lists.size() != 2)
            throw new SQLException("The Stored Proc execution didn't return the expected number of tables.");
        List<TabNames> tabNames = Jackson.getObjectMapper().convertValue(lists.get(0), new TypeReference<List<TabNames>>() {
        });
        List<TabAssets> tabAssets = Jackson.getObjectMapper().convertValue(lists.get(1), new TypeReference<List<TabAssets>>() {
        });
        return TitleTabs.builder()
                .tabNames(tabNames)
                .tabAssets(tabAssets)
                .build();
    }
    public static List<Award> callTitleAwards(String appTitleGuid, int distId) throws SQLException {
        return db.executeSpToList(StoredProcs.TITLE_AWARDS, Award.class, appTitleGuid, distId);
    }

    public static AdditionalData callTitleAdditionalDataToList(String appTitleGuid) throws SQLException {

        List<List<Map<String, Object>>> lists = db.executeMultiTableSp(StoredProcs.TITLE_ADDITIONAL_DATA, appTitleGuid);

        if (lists.size() != 4)
            throw new SQLException("The Stored Proc execution didn't returned the expected number of tables.");
        List<ReleaseDate> releaseDates = Jackson.getObjectMapper().convertValue(lists.get(0), new TypeReference<List<ReleaseDate>>() {
        });
        List<RunTime> runTimes = Jackson.getObjectMapper().convertValue(lists.get(1), new TypeReference<List<RunTime>>() {
        });
        List<Rights> rights = Jackson.getObjectMapper().convertValue(lists.get(2), new TypeReference<List<Rights>>() {
        });

        return AdditionalData.builder()
                .releaseDates(releaseDates)
                .runTimes(runTimes)
                .rights(rights)
                .build();
    }

    public static List<Quotes> callTitleQuotesToList(String appTitleGuid, Integer distId, Integer localId) throws SQLException {
        return db.executeSpToList(StoredProcs.TITLE_QUOTES, Quotes.class, appTitleGuid, distId, localId);
    }

    public static SearchTab callTitleProductPageTabsGetInfo(Integer appId, Integer userId, Integer distId, String appTitleGuid, String type) throws SQLException {
        List<List<Map<String, Object>>> lists = db.executeMultiTableSp(StoredProcs.SEARCH_TABS, appId, userId, distId, appTitleGuid, type);
        if (lists.size() != 2)
            throw new SQLException("The Stored Proc execution didn't returned the expected number of tables.");
        List<Item> items = Jackson.getObjectMapper().convertValue(lists.get(0), new TypeReference<List<Item>>() {
        });
        List<AssetGroup> assetGroups = Jackson.getObjectMapper().convertValue(lists.get(1), new TypeReference<List<AssetGroup>>() {
        });
        return SearchTab.builder()
                .items(items)
                .assetGroups(assetGroups)
                .build();
    }

    public static List<AdditionalCrewAndCast> callTitleAdditionalCrewAndCast(String appTitleGuid, int localId, int creditId) throws SQLException {
        return db.executeSpToList(StoredProcs.TITLE_ADDITIONAL_CREW_AND_CAST, AdditionalCrewAndCast.class, appTitleGuid, localId, creditId);
    }

    public static List<TitleSuggestItem> titleSuggestItem(int applicationTitleGuid, Integer userId, String keyword) throws SQLException {
        return db.executeSpToList(StoredProcs.TITLE_SUGGEST, TitleSuggestItem.class, applicationTitleGuid, userId, keyword);
    }
}