package com.disney.dmdc.qa.util.db;

import com.disney.qa.AzureMgr;
import com.disney.qa.SqlDbMgr;
import com.disney.qa.config.ConfigLoader;
import com.typesafe.config.Config;

public class SqlDbMgrFactory {
    private static final String DB_SOURCE_PATH = "propertyCollections.environments." + ConfigLoader.TEST_ENVIRONMENT + ".db";
    private static final String DB_MANAGER_TYPE_CONFIG_KEY = "dbManagerType";

    public static SqlDbMgr getMgr(String dbName) {
        Config dbConfig = ConfigLoader.getConfig().getConfig(DB_SOURCE_PATH);
        Config dbNameConfig = dbConfig.getConfig(dbName);
        String dbManagerType = dbNameConfig.getString(DB_MANAGER_TYPE_CONFIG_KEY);

        if (dbManagerType.equals(DbType.AZURE.name().toLowerCase())) {
            return new AzureMgr(dbNameConfig);
        }

        throw new UnsupportedOperationException(
                String.format(
                        "The db type %s is not currently handled by the db manager.",
                        dbManagerType)
        );
    }
}
