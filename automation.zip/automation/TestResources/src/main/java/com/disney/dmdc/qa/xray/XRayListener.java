package com.disney.dmdc.qa.xray;

import com.disney.dtci.productivity.outrider.model.TestRun;
import com.disney.dtci.productivity.outrider.model.signature.DefaultCascadingNameStrategy;
import com.disney.dtci.productivity.outrider.model.signature.DefaultClassNameStrategy;
import com.disney.dtci.productivity.outrider.model.signature.SerializedAndHashedParameterStrategy;
import com.disney.dtci.productivity.outrider.provider.TestNGProvider;
import com.disney.dtci.productivity.outrider.provider.TestNGWithTestDocProvider;
import com.disney.dtci.productivity.outrider.xray.consumer.XRayConsumer;
import com.disney.dtci.productivity.outrider.xray.model.XrayExecutionResponse;
import com.disney.productivity.backend.config.BasicConfigManager;
import com.disney.productivity.backend.exception.AuthenticationException;
import com.disney.qa.config.ConfigLoader;
import com.google.common.collect.ImmutableList;
import com.typesafe.config.ConfigBeanFactory;
import lombok.extern.slf4j.Slf4j;
import org.testng.IReporter;
import org.testng.ISuite;
import org.testng.xml.XmlSuite;

import java.io.IOException;
import java.util.List;

@Slf4j
public class XRayListener implements IReporter {

	final String XRAY_CONFIG_KEY = "propertyCollections.environments." + ConfigLoader.TEST_ENVIRONMENT + ".reporting.xray";

	@Override
	public void generateReport(List<XmlSuite> xmlSuites, List<ISuite> suites, String outputDirectory) {
		//Convert from TestNG format to Outrider via our chosen provider class
		TestNGProvider provider = new TestNGWithTestDocProvider();
		provider.setSignatureStrategy(ImmutableList.of(new DefaultClassNameStrategy(), new DefaultCascadingNameStrategy(), new SerializedAndHashedParameterStrategy()));
		TestRun testRun = provider.convertSuiteToOutriderRun(suites.get(0));
		testRun.getTestContext().setEnvironment(ConfigLoader.TEST_ENVIRONMENT);

		//Set up Gunray (our XRay consumer of Outrider)
		BasicConfigManager config = ConfigBeanFactory.create(ConfigLoader.getConfig().getConfig(XRAY_CONFIG_KEY), BasicConfigManager.class);

		XRayConsumer consumer = new XRayConsumer(config, null);
		//Hand our Outrider data off to our consumer to convert to XRay format and interact with the Jira APIs
		XrayExecutionResponse response = null;
		try {
			response = consumer.generateXrayResults(testRun);
		}catch(IOException | AuthenticationException e) {
			log.error(e.getMessage());
		}
		if(response != null)
			log.info(response.toString());
	}

}
