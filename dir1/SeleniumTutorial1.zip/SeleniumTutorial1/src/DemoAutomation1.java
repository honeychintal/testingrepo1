import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class DemoAutomation1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\honey\\eclipse-workspace\\SeleniumTutorial1\\webdriver\\chromedriver.exe");
		
		ChromeDriver driver = new ChromeDriver();
		
		driver.get("https://artoftesting.com/selenium-webdriver-commands-list");	
		
		driver.findElement(By.linkText("Home")).click(); 
	}
}