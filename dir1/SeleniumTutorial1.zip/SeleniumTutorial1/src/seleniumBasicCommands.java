import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class seleniumBasicCommands {

	public static void main(String Args[]) throws InterruptedException{
		
		//Set system property for driver executable's path
		System.setProperty("webdriver.chrome.driver", "C:\\\\Users\\\\honey\\\\eclipse-workspace\\\\SeleniumTutorial1\\\\webdriver\\\\chromedriver.exe");
		
		//Create Firefox driver's instance
		WebDriver driver = new ChromeDriver();
					
		//Set implicit wait of 10 seconds
		//This is required for managing waits in selenium webdriver
		//WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));	
		//Launch sampleSiteForSelenium
		
		driver.get("https://artoftesting.com/sampleSiteForSelenium");
					
		//Fetch the text "This is sample text!" and print it on the console
		//Use the id of the div to locate it and then fecth text using the getText() method
		String sampleText = driver.findElement(By.tagName("entry-content")).getText();
		System.out.println(sampleText);
			
		//Waiting for 3 seconds just for the user to efficiently check automation
		//Its not mandatory though
		Thread.sleep(3000);
			
		//Using linkText locator to find the link and then using click() to click on it
		driver.findElement(By.linkText("This is a link")).click();
			
		Thread.sleep(3000);
		
		//Finding textbox using id locator and then using send keys to write in it
		driver.findElement(By.id("fname")).sendKeys("Prajjaval Rao chintal");
			
		Thread.sleep(3000);
		
		//Clear the text written in the textbox
		driver.findElement(By.id("fname")).clear();
			
		Thread.sleep(3000);
		
		//Clicking on button using click() command
		driver.findElement(By.id("idOfButton")).click();
			
		Thread.sleep(3000);
			
		//Find radio button by name and check it using click() function
		driver.findElement(By.name("male")).click();
			
		Thread.sleep(3000);
			
		//Find checkbox by cssSelector and check it using click() function
		driver.findElement(By.cssSelector("input.Automation")).click();
				
		Thread.sleep(3000);
			
		//Using Select class for for selecting value from dropdown
		Select dropdown = new Select(driver.findElement(By.id("testingDropdown")));
		dropdown.selectByVisibleText("Database Testing");
			
		Thread.sleep(50000);
		
		//Close the browser
		driver.close();
}
	}
