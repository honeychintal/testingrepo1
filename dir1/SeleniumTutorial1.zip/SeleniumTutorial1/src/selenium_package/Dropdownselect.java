package selenium_package;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Dropdownselect {
	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\honey\\eclipse-workspace\\SeleniumTutorial1\\webdriver\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.sugarcrm.com/au/request-demo/");
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		WebElement drp = driver.findElement(By.name("employees_c"));
		
		Select select = new Select(drp);
		driver.findElement(By.name("q")).sendKeys(Keys.RETURN);
		
		select.selectByVisibleText("1 - 10 employees");
		Thread.sleep(2000);
		
		select.selectByValue("level1");
		Thread.sleep(2000);
		
		select.selectByIndex(2);
	}
}
