package selenium_package;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumScroll {

	 public static void main(String[] args) {  
         
   
		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\honey\\eclipse-workspace\\SeleniumTutorial1\\webdriver\\chromedriver.exe");
		 WebDriver driver = new ChromeDriver();
		 
		 driver.get("https://www.sugarcrm.com/au/request-demo/");  
		 
		 //Scroll down the webpage by 4500 pixels  
	     JavascriptExecutor js = (JavascriptExecutor)driver;  
	     js.executeScript("scrollBy(0, 4500)");  
	  
	    }  
}
